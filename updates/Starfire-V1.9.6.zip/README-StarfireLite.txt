STARFIRE LITE 2.9.20
Chinese -> English overlay for The Hidden Ones. Same engine as Project Starfire 1.6.21. Every label is looked up in
the built-in game dictionaries first; only text that is not in them is sent to the online translators.

START
  Double-click "Starfire Lite.exe": a setup window opens (Install / Update / Reinstall, OCR pack, shortcuts) and installs
  to %LOCALAPPDATA%\StarfireLite\app. Afterwards start it from the desktop or Start menu shortcut, or
  double-click "Starfire Lite.cmd" to run it straight from this folder.
  Hotkeys in game: F8 overlay on / off, End closes the overlay (Ctrl+Shift+Q still works).

WHAT IT KNOWS
  * About 1,400 built-in game terms (the same as Project Starfire), plus
  * starfire-lite-dict.tsv: 3,380 further menu labels, buttons, item, skill, place and character names taken from the
    game's own string table (I18NTranslation_CN.bytes) and translated to English. These are the short labels
    (2-4 characters) that make up most of the menus.
  * On first start it copies the translations Project Starfire has already fetched (translation-cache.json) and your
    glossary.csv, so everything you have seen before works offline too.
  * Text that is in none of these (chat, story dialogue, long descriptions, event text) is translated online as a
    backup: Microsoft -> Google -> Google (2nd address) -> Lingva (2 servers) -> MyMemory, the same chain as Project
    Starfire. Each online translation is saved, so a phrase is only requested once and works offline afterwards.
    Without internet, such text simply gets no label.
  * Short unknown phrases are also listed in %LOCALAPPDATA%\StarfireLite\unknown-short.txt. Add them to glossary.csv
    (cn,en) in that folder and restart Lite to fix a translation for good.

NOTES
  * Lite and Project Starfire are separate programs with separate settings (%LOCALAPPDATA%\StarfireLite).
    Run only one of them at a time, or you get two overlays.
  * Lite does not change the game or any game file.
  * Everything else (window capture without flicker, glass labels, layout, watchdog) works as in Project Starfire 1.6.19.

WHAT'S NEW IN 1.1
  * Online translators as backup for everything not in the game dictionaries (1.0 left such text without a label).

WHAT'S NEW IN 1.2
  * Labels on sparkling / glowing buttons (Duel) no longer blink off for a second. A label that has been read 6 or more times
    in a row now survives up to 4-5 scans in which the OCR misses its text (the glitter on the gold Duel button makes it
    miss a few scans in a row). A real screen change still removes labels at once, and new text in the same spot still
    replaces the label directly.

WHAT'S NEW IN 1.3
  * Established labels (read 6+ times in a row) now survive one more missed scan: up to 5-6 instead of 4-5.

WHAT'S NEW IN 1.4
  * A label counts as established (and survives 5-6 missed scans) after 4 readings in a row instead of 6, so labels on
    sparkling buttons such as Duel lock in sooner.

WHAT'S NEW IN 1.5
  * Calmer labels on panels over moving pictures (the main-menu cards: Beginner's Journey with the driving car, the
    rotating event banner, Daily Quests):
    - the moving picture made every slightly different reading count as "new text" at once, so the label kept changing,
      re-sizing and moving. Now a clearer change is needed, and the same Chinese with only other numbers or brackets
      ("Stage 6 1 3 )" style jitter) has to be read the same way three times before the label changes;
    - a label is no longer switched to a new reading that has no translation yet (it used to vanish while the
      translation was fetched); the old label stays until the new one is ready;
    - a box that is read a little wider or narrower keeps its layout instead of being laid out again.

WHAT'S NEW IN 1.6
  * Window capture really works now. Your log showed it switching on and failing at once ("Cannot find an overload for
    CreateCopyFromSurfaceAsync"), so the overlay was still being hidden for every scan - that is the whole-overlay blink in
    your clip. The picture is now copied in a way PowerShell can call. Look for "window capture: ON" WITHOUT error lines
    after it in starfire.log.
  * No more leftover copies of a label: in your clip a second "Duel" sat above the Duel button and a second
    "Beginner's Journey" sat over the card below it for a few seconds. A copy whose text is read somewhere else in the
    same scan is now removed at once.
  * Icons in front of text (the diamond / shield / "!" symbols on the main-menu cards) are kept apart from the text, so
    "0 daily mission" becomes "Daily Quests" and the icon is not covered.
  * "阶段6（1/3）" style counters keep their numbers: "Stage 6 (1/3)" instead of "Stage 6 1 3 )".
  * Dictionary: Stage, Season 1, Season 1: Rising Wind (the rotating card that showed three different translations).

WHAT'S NEW IN 1.7
  * Duel (and other game words that are hard to read on glittering or glowing buttons) is caught sooner. Text that is in
    the dictionary now stays "in the running" for 4 missed scans instead of 2, so the few times the OCR does read it add
    up quickly, and the label locks in.
  * An established label only moves after its new spot has been read 3 times in a row (was 2), so one odd reading no
    longer makes it shoot off for a moment.
  * Counters: "Stage 6 (1/3)". 1.6 only fixed one of the ways the text reaches the screen; the counter is now corrected at
    the very end, whatever produced the English (dictionary, saved or online translation), and also when the OCR lost
    the slash or a bracket.

WHAT'S NEW IN 1.8
  * No more stray "Duel" floating above the Duel button (and similar stray labels in empty spots): a reading is ignored
    when the area it came from has no sharp detail at all (no letter strokes), which is what the glow around the gold
    button produced. Such readings are logged as "reject [no-detail]".
  * Dictionary: common OCR misreadings of 切磋 / 对决 (so 切磋 never comes out as "Let's discuss"), plus Set Off and Enter.
  * Your 1.6 log confirms window capture now works ("window capture: ON" with no errors after it), so the overlay no
    longer blinks off for scans.

WHAT'S NEW IN 1.9
  * Fixes 1.8: the "no detail" check threw away real text (your log: 仓库 / Storage, 身外身, 异人, 阶段6 1 3,
    今日奖励领取 ...). Soft grey text over a photo has little sharp detail on average. The check now looks only at
    readings from the extra contrast passes, and only drops one when no part of its area has any sharp detail at all.

WHAT'S NEW IN 2.0
  * Counters such as 阶段6（1/3）: the label now covers only the word ("Stage") and the game's own numbers stay visible
    next to it, exactly as the game shows them. The OCR reads this line as "阶段6 1 3" (it loses the brackets and the
    slash), so re-typing the numbers could never be right. The same applies to any known word followed only by numbers,
    e.g. 等级 10 -> "Level" + the game's 10.

WHAT'S NEW IN 2.1
  * Season card: 赛季1·风起 is split like the Stage counter - "Season" over 赛季, "Rising Wind" over 风起, and the game's own
    "1·" stays visible between them. This works for any row made of dictionary words with numbers between or after them.
  * Remembered spots: once a word has settled on a button (read 4 times in a row), Lite remembers that spot for the rest
    of the session. When the word is read there again it gets its label at once (no waiting for a second reading), and
    a remembered label is only taken away when the picture there clearly changes or after ~16 scans without the text -
    the Duel button's flash can no longer make it vanish. A screen change still clears everything at once.

WHAT'S NEW IN 2.2
  * The installer now sets up Windows' Chinese text recognition (OCR) language pack before the program starts. If it is
    missing, it asks once, then installs it from Windows Update (about 30 MB; Windows asks for administrator permission and
    a window shows the progress). If it is already installed, nothing happens. The pack itself cannot be included in the
    download (Microsoft only hands it out through Windows Update), so the PC needs internet for this one step.
    Install-OcrPack.ps1 is also included to run by hand (right-click > Run with PowerShell) if you use the .cmd instead.

WHAT'S NEW IN 2.3
  * You can see which version runs:
    - "Starfire Lite.exe" shows a message after a first install ("installed to ...") and after every update
      ("updated from 2.2 to 2.3"); when nothing changed it starts silently as before;
    - hovering over the tray icon shows the version ("Starfire Lite 2.3 ON ...");
    - a notice "Starfire Lite 2.3 is running" appears when it starts, and starfire.log starts with
      "---- start ---- Starfire Lite 2.3".

WHAT'S NEW IN 2.4
  * A real setup window. "Starfire Lite.exe" now opens Starfire Lite Setup, which shows:
    - whether Starfire Lite is installed and which version ("Installed now: 2.3 -> will be updated to 2.4");
    - the install folder;
    - options: install the Chinese OCR pack (only if missing), desktop shortcut, Start menu entry, start when finished;
    - a progress bar and a log of every step, ending with "installed" / "updated from ... to ...".
    A running Starfire Lite is closed during the update and started again at the end.
  * Desktop / Start menu shortcuts start the installed copy directly (no setup window each time).

WHAT'S NEW IN 2.5
  * Fixes 2.4: "Starfire Lite.exe" did not show the setup window (it started PowerShell with a "keep hidden" flag, and
    Windows applied it to the setup window). The window now opens and comes to the front.
  * The OCR pack is installed straight from the setup window when its box is ticked (Windows asks for permission and a
    progress window opens).

WHAT'S NEW IN 2.6
  * Controller and keyboard button prompts are left alone: A, B, X, Y, LB, RB, LT, RT, LS, RS, Esc, Tab, F1-F12 and
    similar are taken out of the text before it is translated (no more "B Back" or "RB Switch"), even when the OCR glued
    them to the Chinese ("B返回"). Their spots are kept clear, so labels do not cover the button icons, and a prompt on its
    own never gets a label.

WHAT'S NEW IN 2.7
  * New launcher look: a red and purple supernova in a starry sky, with glass panels for status and options, and large
    buttons. When Starfire Lite is installed and up to date the main button is START (with REINSTALL beside it), so
    "Starfire Lite.exe" doubles as a launcher; otherwise it is INSTALL or UPDATE.
  * Chinese text recognition (OCR) is now required before anything else: if it is missing, a message explains it and
    installs it (Windows asks for permission, a progress window opens). Without it the launcher does not continue,
    because Starfire Lite cannot read the game without it.

WHAT'S NEW IN 2.8
  * Faster, lighter scanning:
    - with window capture the screen is still read ~8 times a second while things change, but settles to ~3 times a
      second once the screen has been still for a moment (it used to read ~8 times a second all the time);
    - the checks "is this a known game word?", "is this a remembered spot?" and the text clean-up are remembered
      instead of being worked out again for every label on every scan.

WHAT'S NEW IN 2.9
  * Fewer "ghost" labels: random phrases that popped up now and then where there is no text (over shadows, road
    markings, hair, clothes ...). Those are the OCR misreading a busy picture as a few Chinese characters mixed with junk.
    - readings with junk the game's own text never has (@ # * and other keyboard symbols, half a pair of brackets
      such as a lone 《, a ring read as a lone "0" or a stroke read as a small letter between Chinese characters)
      are dropped, or held back until read again when there is only a little of it;
    - text that is not one of the game's own strings must really be read twice before its label appears - re-used
      earlier readings of dim text no longer count as a second reading;
    - readings only the extra contrast passes found, or with a little junk in them, need three real readings and no
      longer appear at once after a scene change, at the subtitle position, or because they were translated before.
    The game's own words (the built-in dictionary) are shown as quickly as before.
  * The debug overlay is switched off: its tray menu item is gone and F7 no longer does anything.

WHAT'S NEW IN 2.9.1
  * Fix: an earlier 2.9 test copy (with the debug overlay still on F7) was kept instead of being replaced, because it had
    the same version number. The Starfire launcher now compares the files themselves and replaces any copy that differs.

WHAT'S NEW IN 2.9.2
  * Widely spaced titles such as 第 一 章 / 第 二 章 / 第 三 章 in the season menu are read when they are not highlighted.
    The OCR returns them one word per character; the lone 一 (a solid bar) was taken for an icon, the lone 第 in front for
    a leading icon, and what was left was dropped. Now a run of characters that together make one of the game's own
    strings is protected from those checks; a dash read in place of 一, and the round icon glued to the first character
    ("G第"), are corrected when that makes one of the game's own strings.

WHAT'S NEW IN 2.9.3
  * Duel / loading bars: the rank badge (百川2阶, 九曲3阶 ...) and the stage or player name beside it were read as one
    line and translated together ("In the afternoon, the course was visited by Baichuan 2 Terrace"). The rank is now cut
    out and each piece gets its own label: "Afternoon Court" | "Hundred Rivers II". A number left on its own stays visible.
  * Dictionary: all 15 duel ranks with their tiers (First Nook, First Dew, Three Courts, Three Streams, Six Gardens,
    Six Marshes, Nine Bends, Nine Paths, Hundred Rivers, Hundred Nations, Thousand Realms, Thousand Falls,
    Myriad Abysses, Myriad Worlds, Eminence; tiers I-III), plus Afternoon Court, Luotian Ceremony Grounds, Win Streak.

WHAT'S NEW IN 2.9.4
  * Only one overlay at a time: when Starfire Lite starts, it closes every other Starfire overlay that is running - other
    versions, test copies, the full Project Starfire, the old HanScreen - and their watchdogs (so they are not brought back).

WHAT'S NEW IN 2.9.5
  * Game overlay or desktop overlay - right-click the tray icon:
      - "Translate: The Hidden Ones (game window)"  - the normal game overlay (attached to the game, hidden when the game
        is in the background);
      - "Translate: desktop (whole screen, any app)" - translates Chinese anywhere on the screen, game or not (launchers,
        browsers, chat apps ...), and stays up when the game is closed;
      - "Translate: desktop area you choose..."      - the same for one area you drag out (sharper on big / wide screens).
    The choice is remembered. "Close Starfire when the game closes" only applies to the game overlay.
  * Tray menu cleaned up: tick marks now show the real settings (some items used to show "ON" when they were off).
    Removed: the three "Display: ..." items (that setting no longer did anything) and "Capture: active window" (old;
    replaced by the desktop overlay - a saved active-window setting becomes the desktop overlay). The frosted-glass /
    solid label choice is now one tick item.

WHAT'S NEW IN 2.9.6
  * Test builds are kept apart: an overlay installed by a Starfire test build has its own settings, translation cache,
    log and watchdog (%LOCALAPPDATA%\StarfireLite-Test) and shows "TEST" in the tray, so it never overwrites the normal one.
    (Only one overlay runs at a time: starting either closes the other.)
  * Fix: the watchdog that restarts Starfire Lite after a crash was looking in Project Starfire's folder; it now uses
    Starfire Lite's own folder (so it can never restart the wrong program).

WHAT'S NEW IN 2.9.7
  * The overlay keeps itself up to date: shortly after it starts, and every 2 hours, it checks whether a newer Starfire
    has been published. If so it shows "Starfire update ... installing" and starts the Starfire mini loader, which installs
    the update (launcher, mini loader and overlay) and starts the new overlay in its place. (Needs the overlay to have been
    installed by the Starfire launcher; nothing happens offline or when there is no update.)

WHAT'S NEW IN 2.9.8
  * Rows of buttons with icons between them (阵容方案 / 战斗录像 / 切磋排行 / 玩法奖励 ...) are translated again. The OCR
    returned the whole row as one line with the icons read as stray characters, so it looked like junk and was dropped.
    When such a row is made of the game's own words, each word is now cut out and gets its own label, and the icons are
    kept clear. Two words written together (no icon or gap between them) are still translated as one name.
  * Dictionary: Lineup Plans, Battle Replays, Sparring Rankings, Mode Rewards, Doppelganger.

WHAT'S NEW IN 2.9.9 / 2.9.10
  * Light-text pass: white / light-grey text on see-through buttons over a busy, colourful or moving picture (the
    阵容方案 / 战斗录像 / 切磋排行 / 玩法奖励 row) is isolated - only bright, colourless pixels that stand out from their own
    surroundings are kept, as black type on plain white - and read again. It also runs while the picture moves (when the
    other contrast passes pause), about once a second.
  * "第1赛季" is translated as one title ("Season 1") instead of "第1" + "Season"; numbered titles like 第N章 / 第N关 are
    treated as the game's own text.
  * No Chinese left inside English labels: when an online translation keeps a character ("Protection卡 Settings"),
    it is translated from the dictionary or a list of common characters (卡 = Card ...).
  * Dictionary: Protection Card Settings, Protection Card, Point-Loss / Demotion Protection Card and "... Active".

WHAT'S NEW IN 2.9.11
  * Labels stick over moving backgrounds: an established label of the game's own text (the season chapter list, menu
    entries) now stays while its light text is still on screen, even when the moving picture behind it makes the OCR miss
    it now and then. It goes when the whole screen changes, when other text takes its place, or when the text is gone.
  * Stray readings of a moving background no longer count as "the whole screen changed", so they cannot wipe the
    labels that are really there.

WHAT'S NEW IN 2.9.12
  * Check boxes / ticks in front of an option (read by the OCR as "7", "V" or "√") are recognised as the box and left
    visible, not translated ("7 cross-platform matching" -> "Cross-Platform Matching"). Real numbers followed by their
    unit (7天, 7次, 7级 ...) are kept.
  * Adventure / event rows steadier: their texts are now in the dictionary (Adventure Level, Adventure Quests, Daily
    Quests, Today's rewards claimed / ready to claim, First Glimpse of the World, the Feng Baobao skill quest ...), so they
    show at once and stick; level fragments like "3级)" become "Lv. 3)".
  * A game word whose last character is hidden or cut off ("玩法奖" behind a glow) is completed to the one word it can be
    ("Mode Rewards") instead of being half-translated, and a real character is never thrown away as an "icon" any more
    (that is how "Game Mode" covered only part of 玩法奖励).

WHAT'S NEW IN 2.9.13
  * The legal / anti-addiction notice on the login screen is shown as ONE clean panel with a complete, hand-written
    translation (age rating, healthy-gaming advice, the real-name / anti-addiction rules, licence, copyright holder,
    publisher, operator, approval and ISBN numbers) instead of a jumble of piece-by-piece labels. It appears as soon as
    two of its key phrases are read, covers the whole notice and keeps its size while the notice is on screen.

WHAT'S NEW IN 2.9.14
  * Fix: labels lingered in the wrong place after a menu list slid or scrolled (e.g. "Events" / "Top-Up Refund" left over
    the next entries). A label only sticks now while ITS text is still there - the light ink has to sit in the same places
    as when it was read (another entry sliding into the spot has its ink elsewhere) - and never when other text has
    just been read on top of it.
  * Fix: real menu words read by the extra contrast passes over soft backgrounds (主界面, 术法训练, 腾讯客服, 展开 ...) were
    sometimes thrown away as "no detail"; the game's own words are kept now (unless the same word is already shown).

WHAT'S NEW IN 2.9.15
  * No more doubled labels: two labels on top of each other (the same text read twice a few pixels apart, or a shorter
    and a longer reading of it), or the same text shown twice close together (an old copy left where a menu entry used
    to be), are reduced to one - the one read in this scan / of the game's own text / read more often stays.

WHAT'S NEW IN 2.9.16
  * Names, currencies, ranks and numbered season / challenge / event words get labels of their own, apart from whatever
    they are written next to; the numbers beside them stay visible:
      - character names (Zhang Chulan, Feng Baobao, Wang Ye, Zhuge Qing, Zhang Lingyu, Xia He ... 45 names);
      - currencies (Silver Carp Coins, Gold Scale Coins, Gold / Copper Coins, Talisman / Draw / Recruit Tickets, Vouchers,
        Tongbao, Points, Reputation, Stamina ...);
      - duel ranks (as before) and 赛季 / 挑战 / 活动 when a number is attached ("挑战 3/10" -> "Challenge" + 3/10).
    Only on short lines (names, badges, prices, counters, list rows); a sentence that mentions a name is translated whole,
    and numbered titles such as 第1赛季 stay one label ("Season 1").
  * Dictionary: 19 more character names, 21 currencies, Season / Challenge / Events.

WHAT'S NEW IN 2.9.17 / 2.9.18
  * Brackets hold their contents together: words inside 【 】 《 》 （ ） 「 」 are never split apart (even when they are far
    apart on screen) and never cut out of their brackets - a name, currency or game word inside brackets takes the
    brackets with it. A text wholly in brackets keeps them in English: 【X】 -> [X], （X） -> (X), 《X》 / 「X」 -> "X".
  * 天下会武 is now "Martial Tournament" everywhere (it was "Grand Martial Gathering"), also in older saved translations.
  * Labels reach a little further below the text, so the glow / shadow under bright gold text no longer peeks out.

WHAT'S NEW IN 2.9.19
  * Win-streak badges: "3连胜" is translated on the spot as one label, "3 Win Streak" (and N连败 as "N Loss Streak"),
    also when the OCR reads 胜 as a look-alike (牲, 性, 月生 ...) - no more odd online translations of a misread badge.

WHAT'S NEW IN 2.9.20
  * Fix (important): after running for a while the overlay stopped working, and its log filled with
    "Exception calling GetHicon ... A generic error occurred in GDI+". The tray icon was redrawn on every scan and each
    drawing used up a Windows graphics handle that was never given back; once they ran out, every scan failed. The two
    tray icons are now made once and re-used, and everything used to draw them is freed.

WHAT'S NEW IN 2.9.21
  * End key closes the overlay (Ctrl+Shift+Q still works). Ranked screen: pips are no longer read as a rank tier,
    labels follow moving text faster, "第N 赛季" is one phrase, glass covers glow next to a label.
