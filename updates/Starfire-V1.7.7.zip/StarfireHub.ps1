﻿# Starfire - hub for The Hidden Ones: installs / starts the Starfire overlay, starts the game and the VPN, or all three at once
param([string]$LiteVersion = '2.9.3', [string]$HubVersion = '1.7.7', [string]$ExePath = '', [switch]$Quick)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
# borderless windows with an animated, flowing glow around the edge (all Starfire windows use it)
if (-not ('NovaWin' -as [type])) {
Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;

// Borderless Starfire window: no Windows frame, a soft drop shadow, rounded corners (Windows 11), drag anywhere on the
// header, its own minimize / close buttons, and an animated glowing border that flows around the whole edge.
public class NovaWin : Form
{
    [DllImport("user32.dll")] static extern bool ReleaseCapture();
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int val, int size);

    public int DragHeight = 64;
    public int Radius = 8;
    Timer anim;
    PointF[] pts = new PointF[0];
    float[] hueOf = new float[0];
    double t0 = Environment.TickCount;
    bool dwmRound;
    Label btnX, btnMin;

    public NovaWin()
    {
        FormBorderStyle = FormBorderStyle.None;
        DoubleBuffered = true;
        SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
        anim = new Timer();
        anim.Interval = 33;
        anim.Tick += delegate { InvalidateEdge(); };
    }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.Style |= 0x00020000;        // WS_MINIMIZEBOX: the taskbar button can minimize / restore it
            cp.ClassStyle |= 0x00020000;   // CS_DROPSHADOW
            return cp;
        }
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        try { int v = 2; dwmRound = DwmSetWindowAttribute(Handle, 33, ref v, 4) == 0; } catch { dwmRound = false; }   // Windows 11 round corners
        BuildEdge();
    }

    public void AddCaption(bool minimize)
    {
        btnX = MakeCap("✕", 0);
        btnX.Click += delegate { Close(); };
        if (minimize) { btnMin = MakeCap("–", 1); btnMin.Click += delegate { WindowState = FormWindowState.Minimized; }; }
        PlaceCaption();
    }
    Label MakeCap(string t, int slot)
    {
        Label l = new Label();
        l.Text = t; l.AutoSize = false; l.Size = new Size(30, 20); l.TextAlign = ContentAlignment.MiddleCenter;
        l.Font = new Font("Segoe UI", 10f, FontStyle.Bold); l.ForeColor = Color.FromArgb(196, 182, 222);
        l.BackColor = Color.Transparent; l.Cursor = Cursors.Hand; l.Tag = slot;
        bool isClose = slot == 0;
        l.MouseEnter += delegate { l.BackColor = isClose ? Color.FromArgb(214, 40, 90) : Color.FromArgb(70, 50, 110); l.ForeColor = Color.White; };
        l.MouseLeave += delegate { l.BackColor = Color.Transparent; l.ForeColor = Color.FromArgb(196, 182, 222); };
        Controls.Add(l); l.BringToFront();
        return l;
    }
    void PlaceCaption()
    {
        if (btnX != null) btnX.Location = new Point(ClientSize.Width - 38, 6);
        if (btnMin != null) btnMin.Location = new Point(ClientSize.Width - 70, 6);
    }

    // drag the window by any label / empty space in the header
    public void HookDrag(Control c) { c.MouseDown += DragDown; }
    void DragDown(object s, MouseEventArgs e)
    {
        Control c = s as Control;
        if (e.Button != MouseButtons.Left || c == null) return;
        Point p = c == this ? e.Location : PointToClient(c.PointToScreen(e.Location));
        if (p.Y > DragHeight) return;
        ReleaseCapture();
        SendMessage(Handle, 0xA1, (IntPtr)2, IntPtr.Zero);   // WM_NCLBUTTONDOWN, HTCAPTION
    }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e); DragDown(this, e); }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        foreach (Control c in Controls) { if (c is Label && c.Top < DragHeight && c != btnX && c != btnMin) HookDrag(c); }
        anim.Start();
    }
    protected override void OnFormClosed(FormClosedEventArgs e) { anim.Stop(); anim.Dispose(); base.OnFormClosed(e); }
    protected override void OnResize(EventArgs e) { base.OnResize(e); BuildEdge(); PlaceCaption(); }

    GraphicsPath EdgePath(float inset)
    {
        float w = ClientSize.Width, h = ClientSize.Height, r = Radius, d = r * 2;
        GraphicsPath g = new GraphicsPath();
        RectangleF b = new RectangleF(inset, inset, w - 2 * inset - 1, h - 2 * inset - 1);
        g.AddArc(b.X, b.Y, d, d, 180, 90);
        g.AddArc(b.Right - d, b.Y, d, d, 270, 90);
        g.AddArc(b.Right - d, b.Bottom - d, d, d, 0, 90);
        g.AddArc(b.X, b.Bottom - d, d, d, 90, 90);
        g.CloseFigure();
        return g;
    }
    void BuildEdge()
    {
        if (ClientSize.Width < 40 || ClientSize.Height < 40) return;
        GraphicsPath g = EdgePath(1.5f);
        g.Flatten(null, 0.3f);
        PointF[] raw = g.PathPoints;
        // resample evenly (every 3 px) so the flow moves at one speed along straight edges and corners alike
        List<PointF> o = new List<PointF>();
        float step = 3f, carry = 0f;
        for (int i = 0; i < raw.Length; i++)
        {
            PointF a = raw[i], b = raw[(i + 1) % raw.Length];
            float dx = b.X - a.X, dy = b.Y - a.Y, len = (float)Math.Sqrt(dx * dx + dy * dy);
            float pos = carry;
            while (pos < len) { o.Add(new PointF(a.X + dx * pos / len, a.Y + dy * pos / len)); pos += step; }
            carry = pos - len;
        }
        pts = o.ToArray();
        hueOf = new float[pts.Length];
        for (int i = 0; i < pts.Length; i++) hueOf[i] = (float)i / pts.Length;
        if (dwmRound) { Region = null; } else { try { Region = new Region(EdgePath(0f)); } catch { } }
        g.Dispose();
    }
    void InvalidateEdge()
    {
        int w = ClientSize.Width, h = ClientSize.Height, k = 7;
        Invalidate(new Rectangle(0, 0, w, k)); Invalidate(new Rectangle(0, h - k, w, k));
        Invalidate(new Rectangle(0, 0, k, h)); Invalidate(new Rectangle(w - k, 0, k, h));
    }

    static readonly Color[] pal = { Color.FromArgb(214, 40, 90), Color.FromArgb(255, 92, 120), Color.FromArgb(255, 170, 110),
                                    Color.FromArgb(140, 80, 255), Color.FromArgb(90, 110, 255), Color.FromArgb(170, 60, 200) };
    static Color Pal(double x)
    {
        x = x - Math.Floor(x); double f = x * pal.Length; int i = (int)f; double u = f - i;
        u = u * u * (3 - 2 * u);
        Color a = pal[i % pal.Length], b = pal[(i + 1) % pal.Length];
        return Color.FromArgb((int)(a.R + (b.R - a.R) * u), (int)(a.G + (b.G - a.G) * u), (int)(a.B + (b.B - a.B) * u));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        int n = pts.Length;
        if (n < 8) return;
        double t = (Environment.TickCount - t0) / 1000.0;
        Graphics gr = e.Graphics;
        gr.SmoothingMode = SmoothingMode.AntiAlias;
        // two bright currents chase each other around the edge; their speed and length breathe a little so it feels fluid
        double h1 = (t / 7.0 + 0.05 * Math.Sin(t * 0.9)) % 1.0;
        double h2 = (h1 + 0.5 + 0.04 * Math.Sin(t * 0.6 + 1.3)) % 1.0;
        double len1 = 0.10 + 0.025 * Math.Sin(t * 1.3), len2 = 0.08 + 0.02 * Math.Sin(t * 1.1 + 2.0);
        double hueShift = t / 23.0;
        using (Pen glow = new Pen(Color.Black, 5f), core = new Pen(Color.Black, 1.6f))
        {
            glow.StartCap = glow.EndCap = LineCap.Round; core.StartCap = core.EndCap = LineCap.Round;
            for (int i = 0; i < n; i++)
            {
                double p = hueOf[i];
                double d1 = Math.Abs(p - h1); if (d1 > 0.5) d1 = 1 - d1;
                double d2 = Math.Abs(p - h2); if (d2 > 0.5) d2 = 1 - d2;
                double ripple = 0.06 * Math.Sin(p * 37.7 - t * 2.4);
                double lit = Math.Exp(-(d1 * d1) / (len1 * len1)) + 0.75 * Math.Exp(-(d2 * d2) / (len2 * len2));
                double v = Math.Min(1.0, 0.30 + ripple + 0.85 * lit);
                Color c = Pal(p * 2 + hueShift);
                PointF a = pts[i], b = pts[(i + 1) % n];
                glow.Color = Color.FromArgb((int)(Math.Max(0, v - 0.25) * 110), c);
                if (glow.Color.A > 3) gr.DrawLine(glow, a, b);
                int r = (int)(c.R + (255 - c.R) * lit * 0.45), g = (int)(c.G + (255 - c.G) * lit * 0.45), bl = (int)(c.B + (255 - c.B) * lit * 0.45);
                core.Color = Color.FromArgb((int)(v * 255), Math.Min(255, r), Math.Min(255, g), Math.Min(255, bl));
                gr.DrawLine(core, a, b);
            }
        }
    }
}
'@
}
[System.Windows.Forms.Application]::EnableVisualStyles()

$src      = $PSScriptRoot
$hubDir   = Join-Path $env:LOCALAPPDATA 'Starfire'
$cfgPath  = Join-Path $hubDir 'starfire-hub.json'
$liteData = Join-Path $env:LOCALAPPDATA 'StarfireLite'
$appDir   = Join-Path $liteData 'app'
$verFile  = Join-Path $appDir 'version.txt'
$exeDir   = ''; if ($ExePath) { try { $exeDir = Split-Path $ExePath -Parent } catch {} }
if (-not $exeDir) { $exeDir = $src }
$hubExe   = Join-Path $exeDir 'Starfire.exe'            # the full launcher
$miniExe  = Join-Path $exeDir 'Starfire Overlay.exe'    # mini loader: update check, then only the overlay
$liteFiles = @('StarfireLite.ps1', 'starfire-lite-dict.tsv', 'glossary.csv', 'starfire.ico', 'README.txt', 'Install-OcrPack.ps1', 'StarfireLiteSetup.ps1')
New-Item -ItemType Directory -Force -Path $hubDir | Out-Null

# ---------- settings (paths remembered between runs) ----------
$cfg = [ordered]@{ gamePath = ''; uuPath = ''; uuDelay = 6; startLite = $true; startUU = $true; startGame = $true; vpnMode = 'auto'; gameMode = 'on' }
try {
    if (Test-Path $cfgPath) {
        $j = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @($cfg.Keys)) { if ($null -ne $j.$k) { $cfg[$k] = $j.$k } }
    }
} catch {}
function Save-Cfg { try { ($cfg | ConvertTo-Json) | Set-Content -Path $cfgPath -Encoding UTF8 } catch {} }

# first run: try to find the VPN and the game by themselves
function Find-Installed([string[]]$patterns, [string[]]$exeNames) {
    $roots = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')
    foreach ($r in $roots) {
        try {
            foreach ($k in Get-ChildItem $r -ErrorAction SilentlyContinue) {
                $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
                $dn = [string]$p.DisplayName
                $hit = $false; foreach ($pt in $patterns) { if ($dn -like $pt) { $hit = $true } }
                if (-not $hit) { continue }
                $dirs = @()
                if ($p.InstallLocation) { $dirs += [string]$p.InstallLocation }
                if ($p.DisplayIcon) { $dirs += (Split-Path ([string]$p.DisplayIcon).Split(',')[0].Trim('"')) }
                foreach ($dd in $dirs) { foreach ($en in $exeNames) { $c = Join-Path $dd $en; if (Test-Path $c) { return $c } } }
            }
        } catch {}
    }
    return ''
}
# the usual install places are checked first (also when a saved path no longer exists); then the installed-programs list;
# BROWSE stays as the backup
$knownGame = @('C:\yrzx\launcher\yrzx_launcher.exe', 'D:\yrzx\launcher\yrzx_launcher.exe', 'E:\yrzx\launcher\yrzx_launcher.exe')
$knownUU   = @('C:\Program Files (x86)\Netease\UU\uu_launcher.exe', 'C:\Program Files\Netease\UU\uu_launcher.exe', 'D:\Program Files (x86)\Netease\UU\uu_launcher.exe')
function First-Existing([string[]]$list) { foreach ($k in $list) { if (Test-Path -LiteralPath $k) { return $k } }; return '' }
if (-not $cfg.gamePath -or -not (Test-Path -LiteralPath ([string]$cfg.gamePath))) {
    $g0 = First-Existing $knownGame
    if (-not $g0) { $g0 = Find-Installed @('*异人之下*', '*Hidden Ones*', '*YiRenZhiXia*', '*yrzx*') @('yrzx_launcher.exe', 'YiRenZhiXia.exe', 'launcher.exe', 'Launcher.exe') }
    if ($g0) { $cfg.gamePath = $g0 }
}
if (-not $cfg.uuPath -or -not (Test-Path -LiteralPath ([string]$cfg.uuPath))) {
    $u0 = First-Existing $knownUU
    if (-not $u0) { $u0 = Find-Installed @('*UU*', '*网易UU*') @('uu_launcher.exe', 'uu.exe', 'UU.exe', 'uuplayer.exe', 'UUBooster.exe') }
    if ($u0) { $cfg.uuPath = $u0 }
}

function Test-ChineseOcr {
    try {
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        foreach ($l in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) { $lt = [string]$l.LanguageTag; if ($lt -eq 'zh-Hans' -or $lt -like 'zh-Hans-*' -or $lt -eq 'zh-CN') { return $true } }
    } catch {}
    return $false
}
function Get-LiteProcs {
    try { @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*StarfireLite.ps1*' -or $_.CommandLine -like '*StarfireLiteWD*' }) } catch { @() }
}
function Install-Ocr {
    $sp = Join-Path $src 'Install-OcrPack.ps1'
    try { $null = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$sp`"", '-Elevated', '-App', '"Starfire"') } catch {}
    return (Test-ChineseOcr)
}

# ---------- Chinese text recognition is required ----------
# (checked at start AND again before every action: nothing goes ahead without it)
function Ensure-Ocr {
    if (Test-ChineseOcr) { return $true }
    while ($true) {
        $q = "Starfire needs Windows' Chinese (Simplified) text recognition (OCR) to read the game, and it is not installed " +
             "on this PC.`n`nIt is installed now from Windows Update (about 30 MB). Windows will ask for administrator permission " +
             "and a small window shows the progress.`n`nStarfire cannot go on without it."
        $r = Show-NovaMsg 'Starfire' 'Chinese text recognition required' $q @('Install now', 'Cancel')
        if ($r -ne 'Install now') { return $false }
        if (Install-Ocr) { return $true }
        $r2 = Show-NovaMsg 'Starfire' 'Still not available' ("The Chinese text recognition is still not available.`n`nIf it was just installed or removed, restart the PC once - Windows sometimes finishes this only after a restart.`nYou can also add it by hand: Settings > Time & language > Language > Chinese (Simplified) > Language options > Optical character recognition.") @('Try again', 'Cancel')
        if ($r2 -ne 'Try again') { return $false }
    }
}

# ---------- live updates: where they come from (github.com/jett-black/Starfire-Test, updates/latest.json) ----------
$UpdRepo = 'jett-black/Starfire-Test'
$script:Upd = $null
try { Add-Type -AssemblyName System.Net.Http } catch {}
try { [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12 } catch {}
$script:UpdHttp = New-Object System.Net.Http.HttpClient
$script:UpdHttp.Timeout = [TimeSpan]::FromSeconds(60)
try { $script:UpdHttp.DefaultRequestHeaders.Add('User-Agent', 'Starfire-Updater') } catch {}
try { $script:UpdHttp.DefaultRequestHeaders.Add('Accept', 'application/vnd.github+json') } catch {}
function Get-VerObj([string]$v) { try { return [version](($v -replace '^[^\d]*', '') -replace '[^\d\.].*$', '') } catch { return $null } }
function Read-Manifest([string]$txt) {
    # returns the update (newer than this version) or $null when up to date; throws when the text is not a manifest
    $man = $txt | ConvertFrom-Json
    if ($man.content -and $man.encoding -eq 'base64') { $man = ([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(((([string]$man.content) -replace '\s', ''))))) | ConvertFrom-Json }
    if (-not $man.version) { throw 'not an update manifest' }
    $vNew = Get-VerObj ([string]$man.version); $vCur = Get-VerObj $HubVersion
    $fileN = [string]$man.file
    if ($fileN -and $fileN -match '^[A-Za-z0-9._\-]+\.zip$' -and $vNew -and $vCur -and $vNew -gt $vCur) {
        return [pscustomobject]@{ ver = $vNew.ToString(); url = "https://raw.githubusercontent.com/$UpdRepo/main/updates/$fileN"; notes = [string]$man.notes; size = [int64]$man.size }
    }
    return $null
}
function Wait-Task($task, [int]$ms) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while (-not $task.IsCompleted -and $sw.ElapsedMilliseconds -lt $ms) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 40 }
    return ($task.IsCompleted -and $task.Status -eq 'RanToCompletion')
}
function Get-UpdateNow {
    # quick check for the mini loader: API first, raw file second; offline / no answer counts as "no update"
    foreach ($url in @("https://api.github.com/repos/$UpdRepo/contents/updates/latest.json?ref=main", "https://raw.githubusercontent.com/$UpdRepo/main/updates/latest.json")) {
        try { $t = $script:UpdHttp.GetStringAsync($url); if (Wait-Task $t 6000) { return (Read-Manifest ([string]$t.Result)) } } catch {}
    }
    return $null
}

# ---------- background ----------
function New-SpaceArt([int]$w, [int]$h, $cards) {
    $bmp = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    # deep space: near-black violet to dark wine
    $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point(0, 0)), (New-Object System.Drawing.Point($w, $h)), ([System.Drawing.Color]::FromArgb(10, 6, 22)), ([System.Drawing.Color]::FromArgb(26, 4, 14))
    $g.FillRectangle($bg, 0, 0, $w, $h)
    $rnd = New-Object System.Random 7
    # nebula clouds: soft red and purple blobs
    $clouds = @(@(0.78, 0.22, 330, 170, 40, 120), @(0.62, 0.40, 260, 120, 30, 160), @(0.90, 0.55, 220, 150, 20, 140), @(0.15, 0.85, 260, 70, 30, 120), @(0.35, 0.10, 200, 110, 30, 150))
    foreach ($c in $clouds) {
        $cx = $c[0] * $w; $cy = $c[1] * $h; $rr = [double]$c[2]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($cx - $rr), [single]($cy - $rr * 0.7), [single]($rr * 2), [single]($rr * 1.4))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$c[4], [int]$c[3], 20, [int]$c[5])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 10, 0, 20))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    # stars
    for ($i = 0; $i -lt 420; $i++) {
        $x = $rnd.NextDouble() * $w; $y = $rnd.NextDouble() * $h
        $a = 60 + $rnd.Next(195); $sz = 0.6 + $rnd.NextDouble() * 1.6
        $tint = $rnd.Next(3)
        if ($tint -eq 0) { $col = [System.Drawing.Color]::FromArgb($a, 255, 255, 255) } elseif ($tint -eq 1) { $col = [System.Drawing.Color]::FromArgb($a, 255, 200, 220) } else { $col = [System.Drawing.Color]::FromArgb($a, 210, 190, 255) }
        $sb = New-Object System.Drawing.SolidBrush $col
        $g.FillEllipse($sb, [single]$x, [single]$y, [single]$sz, [single]$sz); $sb.Dispose()
    }
    # the supernova: rays, layered glow, white-hot core
    $nx = $w * 0.80; $ny = $h * 0.24
    for ($k = 0; $k -lt 14; $k++) {
        $ang = $k * [Math]::PI / 7 + 0.2; $len = 90 + $rnd.Next(150)
        $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(60, 255, 120, 170)), 1.6
        $g.DrawLine($pen, [single]$nx, [single]$ny, [single]($nx + [Math]::Cos($ang) * $len), [single]($ny + [Math]::Sin($ang) * $len)); $pen.Dispose()
    }
    foreach ($ring in @(@(150, 70, 150, 40, 200), @(95, 120, 230, 40, 120), @(55, 190, 255, 80, 90), @(26, 255, 255, 200, 230))) {
        $rr = [double]$ring[0]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($nx - $rr), [single]($ny - $rr), [single]($rr * 2), [single]($rr * 2))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$ring[1], [int]$ring[2], [int]$ring[3], [int]$ring[4])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 120, 20, 160))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    $core = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 250, 245))
    $g.FillEllipse($core, [single]($nx - 5), [single]($ny - 5), 10, 10); $core.Dispose()
    # glass cards behind the content
    function Fill-Card($gr, [int]$x, [int]$y, [int]$cw, [int]$ch) {
        $p = New-Object System.Drawing.Drawing2D.GraphicsPath; $rad = 14
        $p.AddArc($x, $y, $rad, $rad, 180, 90); $p.AddArc($x + $cw - $rad, $y, $rad, $rad, 270, 90)
        $p.AddArc($x + $cw - $rad, $y + $ch - $rad, $rad, $rad, 0, 90); $p.AddArc($x, $y + $ch - $rad, $rad, $rad, 90, 90); $p.CloseFigure()
        $fb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(150, 12, 8, 24))
        $gr.FillPath($fb, $p); $fb.Dispose()
        $pn = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(90, 200, 90, 220)), 1
        $gr.DrawPath($pn, $p); $pn.Dispose(); $p.Dispose()
    }
    foreach ($cd in $cards) { Fill-Card $g ([int]$cd[0]) ([int]$cd[1]) ([int]$cd[2]) ([int]$cd[3]) }
    $g.Dispose()
    return $bmp
}

# ---------- supernova-themed dialogs ----------
$nWhite = [System.Drawing.Color]::FromArgb(245, 240, 255)
$nSoft  = [System.Drawing.Color]::FromArgb(196, 182, 222)
$nRed   = [System.Drawing.Color]::FromArgb(255, 92, 120)
function New-NovaForm([string]$title, [int]$w, [int]$h) {
    $d = New-Object NovaWin
    $d.Text = $title; $d.ClientSize = New-Object System.Drawing.Size($w, $h)
    $d.ShowInTaskbar = $true; $d.DragHeight = 62; $d.AddCaption($false)
    $d.StartPosition = 'CenterScreen'
    $d.BackColor = [System.Drawing.Color]::FromArgb(10, 6, 22); $d.ForeColor = $nWhite
    $d.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    try { $d.Icon = New-Object System.Drawing.Icon (Join-Path $src 'starfire.ico') } catch {}
    try { $d.BackgroundImage = New-SpaceArt $w $h @(, @(16, 62, ($w - 32), ($h - 78))); $d.BackgroundImageLayout = 'None' } catch {}
    try { $d.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($d, $true, $null) } catch {}
    return $d
}
function Add-NovaLabel($d, [string]$t, [int]$x, [int]$y, [int]$w, [int]$h, [single]$size, [string]$style, [System.Drawing.Color]$col) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $t; $l.BackColor = [System.Drawing.Color]::Transparent; $l.ForeColor = $col
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $size, [System.Drawing.FontStyle]$style)
    $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
    $d.Controls.Add($l); return $l
}
function Show-NovaMsg([string]$title, [string]$heading, [string]$msg, [string[]]$buttons) {
    # themed replacement for MessageBox: returns the text of the button that was clicked ('' when closed)
    $w = 540
    $mf = New-Object System.Drawing.Font('Segoe UI', 10)
    $mh = [System.Windows.Forms.TextRenderer]::MeasureText($msg, $mf, (New-Object System.Drawing.Size(484, 2000)), [System.Windows.Forms.TextFormatFlags]::WordBreak).Height + 8
    $h = 62 + 18 + $mh + 76
    $d = New-NovaForm $title $w $h
    $null = Add-NovaLabel $d $heading 26 16 ($w - 52) 36 16 'Bold' $nWhite
    $null = Add-NovaLabel $d $msg 30 80 484 $mh 10 'Regular' $nSoft
    $bx = $w - 26
    for ($i = $buttons.Count - 1; $i -ge 0; $i--) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $buttons[$i]; $b.Tag = $buttons[$i]
        $bw = [Math]::Max(110, [System.Windows.Forms.TextRenderer]::MeasureText($buttons[$i], $mf).Width + 36)
        $bx -= $bw
        $b.Location = New-Object System.Drawing.Point($bx, ($h - 54)); $b.Size = New-Object System.Drawing.Size($bw, 36)
        $bx -= 10
        $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.Cursor = [System.Windows.Forms.Cursors]::Hand
        $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
        if ($i -eq 0) { $b.BackColor = [System.Drawing.Color]::FromArgb(214, 40, 90); $b.ForeColor = [System.Drawing.Color]::White; $d.AcceptButton = $b }
        else { $b.BackColor = [System.Drawing.Color]::FromArgb(40, 30, 64); $b.ForeColor = $nSoft }
        $b.Add_Click({ $this.FindForm().Tag = [string]$this.Tag; $this.FindForm().Close() })
        $d.Controls.Add($b)
    }
    $d.Tag = ''
    $d.Add_Shown({ $this.TopMost = $true; $this.Activate(); $this.TopMost = $false })
    [void]$d.ShowDialog()
    $r = [string]$d.Tag
    $d.Dispose()
    return $r
}
function New-RoundPath([System.Drawing.RectangleF]$r, [single]$rad) {
    $pp = New-Object System.Drawing.Drawing2D.GraphicsPath
    $dd = [Math]::Min($rad * 2, [Math]::Min($r.Width, $r.Height))
    if ($dd -lt 1) { $pp.AddRectangle($r); return $pp }
    $pp.AddArc($r.X, $r.Y, $dd, $dd, 180, 90); $pp.AddArc($r.Right - $dd, $r.Y, $dd, $dd, 270, 90)
    $pp.AddArc($r.Right - $dd, $r.Bottom - $dd, $dd, $dd, 0, 90); $pp.AddArc($r.X, $r.Bottom - $dd, $dd, $dd, 90, 90)
    $pp.CloseFigure(); return $pp
}
function New-NovaBar($d, [int]$x, [int]$y, [int]$w, [int]$h) {
    # rounded progress bar: dark violet track, crimson -> purple fill with a soft shine; value 0..1 in .Tag
    $pb = New-Object System.Windows.Forms.Panel
    $pb.Location = New-Object System.Drawing.Point($x, $y); $pb.Size = New-Object System.Drawing.Size($w, $h)
    $pb.BackColor = [System.Drawing.Color]::Transparent; $pb.Tag = [double]0
    try { $pb.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($pb, $true, $null) } catch {}
    $pb.Add_Paint({
        param($sender, $e)
        $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
        $v = [Math]::Max(0.0, [Math]::Min(1.0, [double]$sender.Tag))
        $rr = New-Object System.Drawing.RectangleF(0.5, 0.5, ($sender.Width - 1), ($sender.Height - 1))
        $track = New-RoundPath $rr ($sender.Height / 2)
        $tb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(200, 24, 14, 44)); $g.FillPath($tb, $track); $tb.Dispose()
        $tp = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(120, 200, 90, 220)), 1; $g.DrawPath($tp, $track); $tp.Dispose()
        $fw = [single](($sender.Width - 4) * $v)
        if ($fw -ge 2) {
            $fr = New-Object System.Drawing.RectangleF(2, 2, $fw, ($sender.Height - 4))
            $fill = New-RoundPath $fr (($sender.Height - 4) / 2)
            $lg = New-Object System.Drawing.Drawing2D.LinearGradientBrush ((New-Object System.Drawing.RectangleF(2, 2, ($sender.Width - 4), ($sender.Height - 4)))), ([System.Drawing.Color]::FromArgb(255, 235, 45, 95)), ([System.Drawing.Color]::FromArgb(255, 140, 60, 230)), 0.0
            $g.FillPath($lg, $fill); $lg.Dispose()
            $shine = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(55, 255, 255, 255))
            $g.FillRectangle($shine, [single]($fr.X + 4), [single]($fr.Y + 1), [single][Math]::Max(0, $fr.Width - 8), [single](($fr.Height) * 0.35)); $shine.Dispose()
            $tip = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(230, 255, 230, 245))
            $g.FillEllipse($tip, [single]($fr.Right - 6), [single]($fr.Y + $fr.Height / 2 - 3), 6, 6); $tip.Dispose()
            $fill.Dispose()
        }
        $track.Dispose()
    })
    $d.Controls.Add($pb); return $pb
}
function Set-NovaBar($pb, [double]$v) { $pb.Tag = $v; $pb.Invalidate() }

# ---------- Starfire overlay files (shared by the launcher and the mini loader) ----------
function Copy-LiteFiles {
    # stops a running overlay, copies the included overlay files into place; returns $true when one was running
    $procs = Get-LiteProcs
    foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force } catch {} }
    if ($procs.Count -gt 0) { Start-Sleep -Milliseconds 800 }
    New-Item -ItemType Directory -Force -Path $appDir | Out-Null
    foreach ($fn in $liteFiles) {
        $s = Join-Path $src $fn
        if (Test-Path $s) { $d = Join-Path $appDir $fn; if (Test-Path $d) { try { (Get-Item $d).IsReadOnly = $false } catch {} }; Copy-Item $s $d -Force }
    }
    [System.IO.File]::WriteAllText($verFile, $LiteVersion)
    return ($procs.Count -gt 0)
}
function Test-LiteFilesSame {
    # the installed overlay files must be exactly the included ones - the version number alone is not enough
    # (two builds can carry the same number, and an older copy would otherwise be kept)
    try {
        $md5 = [System.Security.Cryptography.MD5]::Create()
        foreach ($fn in @('StarfireLite.ps1', 'starfire-lite-dict.tsv', 'glossary.csv')) {
            $a = Join-Path $src $fn; $b = Join-Path $appDir $fn
            if (-not (Test-Path $a)) { continue }
            if (-not (Test-Path $b)) { return $false }
            if ((Get-Item $a).Length -ne (Get-Item $b).Length) { return $false }
            if ([BitConverter]::ToString($md5.ComputeHash([System.IO.File]::ReadAllBytes($a))) -ne [BitConverter]::ToString($md5.ComputeHash([System.IO.File]::ReadAllBytes($b)))) { return $false }
        }
        return $true
    } catch { return $false }
}
function Run-LiteProcess {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $appDir 'StarfireLite.ps1')`"")
}

# ---------- mini loader (Starfire Overlay.exe): check for updates, then start only the overlay ----------
# No update (or offline): the overlay starts and the launcher never opens. Update found: the launcher opens, installs it
# by itself and restarts the mini loader, which then starts the overlay.
$script:QuickUpd = $null
if ($Quick) {
    $qf = New-NovaForm 'Starfire' 420 150
    $null = Add-NovaLabel $qf 'Starfire overlay' 26 16 368 36 16 'Bold' $nWhite
    $qs = Add-NovaLabel $qf 'Checking for updates ...' 32 86 356 24 10 'Regular' $nSoft
    $qf.Show(); $qf.Activate(); [System.Windows.Forms.Application]::DoEvents()
    $u = $null; try { $u = Get-UpdateNow } catch {}
    if ($u) {
        $script:QuickUpd = $u
        $qs.Text = "Update v$($u.ver) found - opening Starfire to install it ..."; [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 600
        $qf.Close()
    } else {
        $qs.Text = 'Up to date - starting the overlay ...'; [System.Windows.Forms.Application]::DoEvents()
        $ok = Ensure-Ocr
        if ($ok) {
            try {
                $inst = ''; try { if (Test-Path $verFile) { $inst = ([System.IO.File]::ReadAllText($verFile)).Trim() } } catch {}
                if ($inst -ne $LiteVersion -or -not (Test-LiteFilesSame)) { $qs.Text = "Installing the Starfire overlay $LiteVersion ..."; [System.Windows.Forms.Application]::DoEvents(); $null = Copy-LiteFiles }
                if ((Get-LiteProcs).Count -gt 0) { $qs.Text = 'The overlay is already running - F8 turns it on / off.' }
                else { Run-LiteProcess; $qs.Text = 'Overlay started - F8 turns it on / off.' }
                [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 1100
            } catch { $null = Show-NovaMsg 'Starfire' 'The overlay could not start' $_.Exception.Message @('OK') }
        }
        $qf.Close()
        exit
    }
}

# Chinese text recognition is required before anything else (asked in the themed dialog)
if (-not (Ensure-Ocr)) { exit 1 }

$W = 720; $H = 600
$cards = @(@(24, 112, 672, 112), @(24, 236, 672, 92), @(24, 340, 672, 92), @(24, 444, 672, 64))
$cardsNoVpn = @(@(24, 112, 672, 112), @(24, 236, 672, 92), @(24, 340, 672, 64))
$VpnShift = 104

# ---------- window ----------
$f = New-Object NovaWin
$f.Text = "Starfire $HubVersion"
$f.ClientSize = New-Object System.Drawing.Size($W, $H)
$f.DragHeight = 108; $f.AddCaption($true)
$f.StartPosition = 'CenterScreen'
$f.BackColor = [System.Drawing.Color]::FromArgb(10, 6, 22); $f.ForeColor = [System.Drawing.Color]::White
$f.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
try { $f.Icon = New-Object System.Drawing.Icon (Join-Path $src 'starfire.ico') } catch {}
$script:BgCache = @{}
$f.BackgroundImageLayout = 'None'
try { $f.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($f, $true, $null) } catch {}

$cWhite = [System.Drawing.Color]::FromArgb(245, 240, 255)
$cSoft  = [System.Drawing.Color]::FromArgb(196, 182, 222)
$cRed   = [System.Drawing.Color]::FromArgb(255, 92, 120)
$cGreen = [System.Drawing.Color]::FromArgb(120, 230, 170)
function New-Label([string]$t, [int]$x, [int]$y, [single]$size, [string]$style, [System.Drawing.Color]$col, [int]$w = 0) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $t; $l.BackColor = [System.Drawing.Color]::Transparent; $l.ForeColor = $col
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $size, [System.Drawing.FontStyle]$style)
    $l.Location = New-Object System.Drawing.Point($x, $y)
    if ($w -gt 0) { $l.Size = New-Object System.Drawing.Size($w, [int]($size * 2.2)); $l.AutoEllipsis = $true } else { $l.AutoSize = $true }
    $f.Controls.Add($l); return $l
}
function New-Btn([string]$t, [int]$x, [int]$y, [int]$w, [int]$h, [System.Drawing.Color]$bc, [System.Drawing.Color]$fc, [single]$fs = 9.5) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $bc; $b.ForeColor = $fc
    $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', $fs); $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $f.Controls.Add($b); return $b
}
function New-Check([string]$t, [int]$x, [int]$y, [bool]$on) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $t; $c.Checked = $on; $c.AutoSize = $true; $c.BackColor = [System.Drawing.Color]::Transparent; $c.ForeColor = $cWhite
    $c.Location = New-Object System.Drawing.Point($x, $y); $f.Controls.Add($c); return $c
}
$cCrimson = [System.Drawing.Color]::FromArgb(214, 40, 90)
$cPurple  = [System.Drawing.Color]::FromArgb(110, 50, 170)
$cDark    = [System.Drawing.Color]::FromArgb(40, 30, 64)

$null = New-Label 'STARFIRE' 26 16 30 'Bold' $cWhite
$lblSub = New-Label "The Hidden Ones companion   |   v$HubVersion" 30 82 9.5 'Regular' $cSoft
$lblOcr = New-Label '' 300 84 8.5 'Bold' $cGreen 150

# --- Starfire overlay card ---
$null = New-Label 'STARFIRE  -  TRANSLATION OVERLAY' 44 122 8.5 'Bold' $cRed
$prev = ''
try { if (Test-Path $verFile) { $prev = ([System.IO.File]::ReadAllText($verFile)).Trim() } } catch {}
if (-not $prev -and (Test-Path (Join-Path $appDir 'StarfireLite.ps1'))) { $prev = 'older' }
if ($prev -eq $LiteVersion -and -not (Test-LiteFilesSame)) { $prev = "$LiteVersion (older copy)" }   # same number, different files: replaced on START
function Get-LiteState {
    if ($prev -eq '') { return "Not installed - version $LiteVersion is included and installs with one click" }
    if ($prev -eq $LiteVersion) { return "Version $LiteVersion installed - up to date" }
    return "Installed: $prev  ->  update to $LiteVersion included"
}
$lblLite = New-Label (Get-LiteState) 44 142 11 'Bold' $cWhite 470
$lblLiteRun = New-Label '' 44 170 9 'Regular' $cSoft 470
$btnLiteInst  = New-Btn 'INSTALL / UPDATE' 530 136 150 30 $cPurple $cWhite
$btnLiteStart = New-Btn 'START STARFIRE' 530 172 150 30 $cCrimson $cWhite
$btnMini = New-Btn 'MINI LOADER' 44 192 128 26 $cPurple $cWhite 8.5
$lblMini = New-Label 'desktop icon that starts only the overlay (checks for updates first)' 180 196 9 'Regular' $cSoft 340

# --- game card ---
$lblGameT = New-Label 'THE HIDDEN ONES  -  GAME / LAUNCHER (.EXE)' 44 246 8.5 'Bold' $cRed
$tbGame = New-Object System.Windows.Forms.TextBox
$tbGame.Location = New-Object System.Drawing.Point(44, 268); $tbGame.Size = New-Object System.Drawing.Size(370, 26)
$tbGame.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $tbGame.ForeColor = $cWhite; $tbGame.BorderStyle = 'FixedSingle'
$tbGame.Text = [string]$cfg.gamePath; $f.Controls.Add($tbGame)
$btnGameBrowse = New-Btn 'BROWSE' 422 266 96 28 $cDark $cSoft
$btnGame       = New-Btn 'LAUNCH GAME' 530 266 150 28 $cCrimson $cWhite
$lblGame = New-Label '' 44 298 9 'Regular' $cSoft 630

# --- VPN card ---
$lblVpnT = New-Label 'VPN / ACCELERATOR (.EXE)' 44 350 8.5 'Bold' $cRed
$tbUU = New-Object System.Windows.Forms.TextBox
$tbUU.Location = New-Object System.Drawing.Point(44, 372); $tbUU.Size = New-Object System.Drawing.Size(370, 26)
$tbUU.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $tbUU.ForeColor = $cWhite; $tbUU.BorderStyle = 'FixedSingle'
$tbUU.Text = [string]$cfg.uuPath; $f.Controls.Add($tbUU)
$btnUUBrowse = New-Btn 'BROWSE' 422 370 96 28 $cDark $cSoft
$btnUU       = New-Btn 'OPEN VPN' 530 370 150 28 $cCrimson $cWhite
$lblUU = New-Label '' 44 402 9 'Regular' $cSoft 630

# --- launch all card ---
$lblAll = New-Label 'LAUNCH ALL - order: VPN, wait, game, Starfire' 44 452 8.5 'Bold' $cRed 640
$cbUU    = New-Check 'VPN' 44 474 ([bool]$cfg.startUU)
$cbGame  = New-Check 'Game' 150 474 ([bool]$cfg.startGame)
$cbLite  = New-Check 'Starfire' 230 474 ([bool]$cfg.startLite)
$lblWait = New-Label 'wait after VPN (s):' 352 476 9 'Regular' $cSoft
$nudDelay = New-Object System.Windows.Forms.NumericUpDown
$nudDelay.Location = New-Object System.Drawing.Point(468, 472); $nudDelay.Size = New-Object System.Drawing.Size(50, 24)
$nudDelay.Minimum = 0; $nudDelay.Maximum = 120; $nudDelay.Value = [Math]::Max(0, [Math]::Min(120, [int]$cfg.uuDelay))
$nudDelay.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $nudDelay.ForeColor = $cWhite
$f.Controls.Add($nudDelay)

$btnAll   = New-Btn 'LAUNCH ALL' 24 528 420 52 $cCrimson $cWhite 14
$btnShort = New-Btn ('DESKTOP' + [Environment]::NewLine + 'SHORTCUT') 454 528 132 52 $cPurple $cWhite 9.5
$btnClose = New-Btn 'CLOSE' 596 528 100 52 $cDark $cSoft 11
$stat = New-Label 'Ready.' 26 584 8.5 'Regular' $cSoft 670

# ---------- Game / VPN sections on / off: one checkbox each, remembered, instant ----------
# Every panel below the Starfire panel moves up when a panel above it is switched off; with both off, LAUNCH ALL becomes
# LAUNCH STARFIRE without checkboxes. Each layout's background is drawn once and kept, so switching back is immediate.
$gameCtls  = @($lblGameT, $tbGame, $btnGameBrowse, $btnGame, $lblGame)
$vpnCtls   = @($lblVpnT, $tbUU, $btnUUBrowse, $btnUU, $lblUU)
$allCtls   = @($lblAll, $cbUU, $cbGame, $cbLite, $lblWait, $nudDelay)
$botCtls   = @($btnAll, $btnShort, $btnClose, $stat)
$baseTop = @{}
foreach ($c in ($gameCtls + $vpnCtls + $allCtls + $botCtls)) { $baseTop[$c] = $c.Top }
function Get-Layout([bool]$g, [bool]$v) {
    $y = 236; $cl = @(, @(24, 112, 672, 112))
    $L = @{ game = 0; vpn = 0; all = 0; bot = 0; cards = $null; h = 0 }
    if ($g) { $L.game = $y - 236; $cl += , @(24, $y, 672, 92); $y += 104 }
    if ($v) { $L.vpn = $y - 340; $cl += , @(24, $y, 672, 92); $y += 104 }
    if ($g -or $v) { $L.all = $y - 444; $cl += , @(24, $y, 672, 64); $bottom = $y + 84 } else { $bottom = $y + 6 }
    $L.bot = $bottom - 528; $L.h = $bottom + 72; $L.cards = $cl
    return $L
}
function Get-Bg([bool]$g, [bool]$v) {
    $k = "$g|$v"
    if (-not $script:BgCache.ContainsKey($k)) { $L = Get-Layout $g $v; try { $script:BgCache[$k] = New-SpaceArt $W $L.h $L.cards } catch { $script:BgCache[$k] = $null } }
    return $script:BgCache[$k]
}
function Set-Sections([bool]$g, [bool]$v) {
    $L = Get-Layout $g $v
    $f.SuspendLayout()
    foreach ($c in $gameCtls) { $c.Visible = $g; $c.Top = [int]$baseTop[$c] + $L.game }
    foreach ($c in $vpnCtls)  { $c.Visible = $v; $c.Top = [int]$baseTop[$c] + $L.vpn }
    $any = ($g -or $v)
    foreach ($c in $allCtls)  { $c.Top = [int]$baseTop[$c] + $L.all }
    $lblAll.Visible = $any; $cbLite.Visible = $any
    $cbUU.Visible = $v; $lblWait.Visible = $v; $nudDelay.Visible = $v
    $cbGame.Visible = $g
    $x = 44
    if ($v) { $cbUU.Left = $x; $x += 106 }
    if ($g) { $cbGame.Left = $x; $x += 80 }
    $cbLite.Left = $x
    $parts = @(); if ($v) { $parts += 'VPN, wait' }; if ($g) { $parts += 'game' }; $parts += 'Starfire'
    $lblAll.Text = 'LAUNCH ALL - order: ' + ($parts -join ', ')
    foreach ($c in $botCtls) { $c.Top = [int]$baseTop[$c] + $L.bot }
    if ($any) { $btnAll.Text = 'LAUNCH ALL' } else { $btnAll.Text = 'LAUNCH STARFIRE' }
    $bg = Get-Bg $g $v; if ($bg) { $f.BackgroundImage = $bg }
    $f.ClientSize = New-Object System.Drawing.Size($W, $L.h)
    $f.ResumeLayout()
}
function New-Switch([string]$t, [int]$x) {
    $c = New-Check $t $x 82 $false
    $c.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    $c.BringToFront(); return $c
}
$cbGameSec = New-Switch 'Game section' 466
$cbVpn     = New-Switch 'VPN section' 592
# Game: on unless switched off by hand. VPN: a choice made by hand is kept; until then shown only when a VPN was found / picked
$gameStart = ([string]$cfg.gameMode -ne 'off')
$vpnStart = $false
if ([string]$cfg.vpnMode -eq 'on') { $vpnStart = $true }
elseif ([string]$cfg.vpnMode -eq 'off') { $vpnStart = $false }
else { $vpnStart = [bool]($cfg.uuPath -and (Test-Path -LiteralPath ([string]$cfg.uuPath))) }
$cbGameSec.Checked = $gameStart
$cbVpn.Checked = $vpnStart
Set-Sections $gameStart $vpnStart
$cbGameSec.Add_CheckedChanged({
    if ($cbGameSec.Checked) { $cfg.gameMode = 'on' } else { $cfg.gameMode = 'off' }
    Set-Sections $cbGameSec.Checked $cbVpn.Checked
    Save-Cfg
})
$cbVpn.Add_CheckedChanged({
    if ($cbVpn.Checked) { $cfg.vpnMode = 'on' } else { $cfg.vpnMode = 'off' }
    Set-Sections $cbGameSec.Checked $cbVpn.Checked
    Save-Cfg
})
# draw the other layouts' backgrounds in the quiet moments after the window opens, so every switch is instant
$bgPre = New-Object System.Windows.Forms.Timer
$bgPre.Interval = 400
$script:BgIdx = 0
$bgPre.Add_Tick({
    if ($script:BgIdx -ge 4) { $this.Stop(); return }
    $gi = ($script:BgIdx -band 2) -eq 0; $vi = ($script:BgIdx -band 1) -eq 0
    $script:BgIdx++
    $null = Get-Bg $gi $vi
})
$bgPre.Start()

# ---------- live updates from GitHub (github.com/jett-black/Starfire, latest release) ----------
$lblUpd = New-Label 'Checking for updates ...' 430 26 9 'Regular' $cSoft 266
$btnUpd = New-Btn 'UPDATE' 430 44 120 28 $cCrimson $cWhite
$btnUpd.Visible = $false
$btnChk = New-Btn 'CHECK AGAIN' 560 44 136 28 $cDark $cSoft 8.5
$script:UpdTask = $null; $script:UpdViaRaw = $false
function Start-UpdCheck {
    $lblUpd.Text = 'Checking for updates ...'; $lblUpd.ForeColor = $cSoft; $btnUpd.Visible = $false
    # updates are published as updates/latest.json + the zip in the repo (raw files, no login needed)
    $script:UpdViaRaw = $false
    try { $script:UpdTask = $script:UpdHttp.GetStringAsync("https://api.github.com/repos/$UpdRepo/contents/updates/latest.json?ref=main") } catch { $lblUpd.Text = 'Update check failed.' }
}
$updTimer = New-Object System.Windows.Forms.Timer
$updTimer.Interval = 250
$updTimer.Add_Tick({
    # 1) the release check came back
    if ($script:UpdTask -and $script:UpdTask.IsCompleted) {
        $t = $script:UpdTask; $script:UpdTask = $null
        if ($t.Status -ne 'RanToCompletion' -and -not $script:UpdViaRaw) {
            # API not reachable / rate limited: read the raw file instead
            $script:UpdViaRaw = $true
            try { $script:UpdTask = $script:UpdHttp.GetStringAsync("https://raw.githubusercontent.com/$UpdRepo/main/updates/latest.json") } catch {}
            return
        }
        if ($t.Status -ne 'RanToCompletion') {
            $m = ''; try { $m = [string]$t.Exception.InnerException.Message } catch {}
            if ($m -match '404') { $lblUpd.Text = "v$HubVersion - no releases published yet" } else { $lblUpd.Text = "v$HubVersion - update check failed (offline?)" }
            return
        }
        try {
            $u = Read-Manifest ([string]$t.Result)
            if ($u) {
                $script:Upd = $u
                $lblUpd.Text = "Update available:  v$HubVersion  ->  v$($script:Upd.ver)"; $lblUpd.ForeColor = $cGreen
                $btnUpd.Text = "UPDATE TO $($script:Upd.ver)"; $btnUpd.Visible = $true
                # automatic: install it right away (once per start - if it fails, UPDATE tries again by hand)
                if (-not $script:AutoTried -and -not $script:Dl) {
                    $script:AutoTried = $true
                    $lblUpd.Text = "Updating to v$($script:Upd.ver) ..."
                    Say "A new version (v$($script:Upd.ver)) was found - installing it automatically, Starfire restarts by itself."
                    Begin-Update
                }
            } else { $lblUpd.Text = "v$HubVersion - up to date"; $lblUpd.ForeColor = $cGreen }
        } catch {
            if (-not $script:UpdViaRaw) {
                $script:UpdViaRaw = $true
                try { $script:UpdTask = $script:UpdHttp.GetStringAsync("https://raw.githubusercontent.com/$UpdRepo/main/updates/latest.json") } catch {}
                return
            }
            $lblUpd.Text = "v$HubVersion - update check failed"
        }
    }
})
$updTimer.Start()

# themed update window with a live progress bar; the download is read piece by piece so the bar can follow it
$script:UpWin = $null; $script:Dl = $null
function Show-UpdateWindow {
    $uw = New-NovaForm 'Starfire update' 540 250
    $null = Add-NovaLabel $uw "Updating Starfire" 26 16 488 36 16 'Bold' $nWhite
    $null = Add-NovaLabel $uw ("v$HubVersion   ->   v" + $script:Upd.ver) 30 84 480 24 11 'Bold' $nRed
    $st = Add-NovaLabel $uw 'Connecting ...' 30 114 480 22 9.5 'Regular' $nSoft
    $bar = New-NovaBar $uw 30 146 480 22
    $pc = Add-NovaLabel $uw '0 %' 30 176 480 24 10 'Bold' $nWhite
    $pc.TextAlign = 'MiddleRight'
    $uw.Add_FormClosing({ param($s2, $e2) if ($script:Dl) { $e2.Cancel = $true } })        # cannot be closed in the middle of an update
    $uw.Show($f)
    $script:UpWin = [pscustomobject]@{ form = $uw; status = $st; bar = $bar; pct = $pc }
}
function Set-UpWin([double]$v, [string]$text) {
    if (-not $script:UpWin) { return }
    Set-NovaBar $script:UpWin.bar $v
    $script:UpWin.pct.Text = ([int][Math]::Round($v * 100)).ToString() + ' %'
    if ($text) { $script:UpWin.status.Text = $text }
    [System.Windows.Forms.Application]::DoEvents()
}
function Fail-Update([string]$why) {
    $script:Dl = $null
    if ($script:UpWin) { try { $script:UpWin.form.Close() } catch {}; $script:UpWin = $null }
    $btnUpd.Enabled = $true
    Say ('Update failed - nothing was changed: ' + $why)
    $null = Show-NovaMsg 'Starfire update' 'Update failed' ("Nothing was changed.`n`n" + $why + "`n`nYou can try again with UPDATE.") @('OK')
    if ($Quick) { Say 'Update failed - START STARFIRE runs the overlay you have now, UPDATE tries again.' }
}
$dlTimer = New-Object System.Windows.Forms.Timer
$dlTimer.Interval = 60
$dlTimer.Add_Tick({
    $dl = $script:Dl
    if (-not $dl) { return }
    try {
        if ($dl.stage -eq 'head') {
            if (-not $dl.task.IsCompleted) { return }
            if ($dl.task.Status -ne 'RanToCompletion') { Fail-Update 'could not reach GitHub (offline?)'; return }
            $resp = $dl.task.Result
            if (-not $resp.IsSuccessStatusCode) { Fail-Update ('GitHub answered ' + [int]$resp.StatusCode); return }
            $len = $resp.Content.Headers.ContentLength
            if ($len) { $dl.total = [int64]$len } elseif ($script:Upd.size -gt 0) { $dl.total = [int64]$script:Upd.size }
            $dl.task = $resp.Content.ReadAsStreamAsync(); $dl.stage = 'stream'
            return
        }
        if ($dl.stage -eq 'stream') {
            if (-not $dl.task.IsCompleted) { return }
            $dl.stream = $dl.task.Result
            $dl.task = $dl.stream.ReadAsync($dl.buf, 0, $dl.buf.Length); $dl.stage = 'read'
            return
        }
        if ($dl.stage -eq 'read') {
            for ($k = 0; $k -lt 16 -and $dl.task.IsCompleted; $k++) {
                if ($dl.task.Status -ne 'RanToCompletion') { Fail-Update 'the download was interrupted'; return }
                $n = [int]$dl.task.Result
                if ($n -le 0) {
                    try { $dl.stream.Dispose() } catch {}
                    $data = $dl.mem.ToArray()
                    $script:Dl = $null
                    Set-UpWin 1.0 'Installing - checking and replacing files ...'
                    try { Apply-Update $data } catch { Fail-Update $_.Exception.Message }
                    return
                }
                $dl.mem.Write($dl.buf, 0, $n)
                $dl.task = $dl.stream.ReadAsync($dl.buf, 0, $dl.buf.Length)
            }
            $got = [double]$dl.mem.Length
            if ($dl.total -gt 0) { $v = [Math]::Min(0.97, $got / $dl.total) } else { $v = 0.5 }
            Set-UpWin $v ('Downloading ...   ' + ('{0:N1}' -f ($got / 1MB)) + ' MB' + $(if ($dl.total -gt 0) { ' of ' + ('{0:N1}' -f ($dl.total / 1MB)) + ' MB' } else { '' }))
        }
    } catch { Fail-Update $_.Exception.Message }
})
$dlTimer.Start()
function Apply-Update([byte[]]$data) {
    if ($data.Length -lt 100000 -or ($script:Upd.size -gt 0 -and $data.Length -ne $script:Upd.size)) { throw 'the download is incomplete' }
    $work = Join-Path $env:TEMP ('Starfire-Update-' + [DateTime]::Now.Ticks)
    $zip = $work + '.zip'
    [System.IO.File]::WriteAllBytes($zip, $data)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $work)
    $newExe = Get-ChildItem $work -Recurse -Filter 'Starfire.exe' | Select-Object -First 1
    if (-not $newExe) { throw 'the update does not contain Starfire.exe' }
    $from = $newExe.DirectoryName
    $to = ''
    if ($ExePath -and (Test-Path $ExePath)) { $to = Split-Path $ExePath -Parent }
    if (-not $to) { $to = Join-Path $env:LOCALAPPDATA 'Starfire\program' }
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    # back up the current files first, then copy the new ones over them
    $bak = Join-Path $env:LOCALAPPDATA ('Starfire\backup-' + $HubVersion)
    New-Item -ItemType Directory -Force -Path $bak | Out-Null
    foreach ($fi in Get-ChildItem $from -File) {
        $d = Join-Path $to $fi.Name
        if (Test-Path $d) { Copy-Item $d (Join-Path $bak $fi.Name) -Force; try { (Get-Item $d).IsReadOnly = $false } catch {} }
        Copy-Item $fi.FullName $d -Force
    }
    try { Remove-Item $zip -Force; Remove-Item $work -Recurse -Force } catch {}
    Say "Updated to v$($script:Upd.ver) - restarting Starfire ..."
    if ($Quick) { Set-UpWin 1.0 "Done - v$($script:Upd.ver) is installed. Starting the overlay ..." } else { Set-UpWin 1.0 "Done - v$($script:Upd.ver) is installed. Restarting Starfire ..." }
    Start-Sleep -Milliseconds 900
    $again = Join-Path $to 'Starfire.exe'
    if ($Quick -and (Test-Path (Join-Path $to 'Starfire Overlay.exe'))) { $again = Join-Path $to 'Starfire Overlay.exe' }   # mini loader: back to it, it then starts the overlay
    Start-Process -FilePath $again -WorkingDirectory $to
    if ($script:UpWin) { try { $script:UpWin.form.Close() } catch {} }
    $f.Close()
}
$btnUpd.Add_Click({
    if (-not $script:Upd -or $script:Dl) { return }
    $n = $script:Upd.notes; if ($n.Length -gt 900) { $n = $n.Substring(0, 900) + ' ...' }
    $q = "What's new:`n$n`n`nStarfire downloads the new version, keeps a backup of the current files, replaces them and restarts."
    if ((Show-NovaMsg 'Starfire update' ("Update to v" + $script:Upd.ver + "?") $q @('Update now', 'Later')) -ne 'Update now') { return }
    Begin-Update
})
function Begin-Update {
    $btnUpd.Enabled = $false
    Show-UpdateWindow
    Set-UpWin 0 'Connecting ...'
    try {
        $script:Dl = [pscustomobject]@{ stage = 'head'; task = $script:UpdHttp.GetAsync($script:Upd.url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead); total = [int64]0; stream = $null; buf = (New-Object byte[] 65536); mem = (New-Object System.IO.MemoryStream) }
    } catch { Fail-Update $_.Exception.Message }
}
$btnChk.Add_Click({ Start-UpdCheck })

# desktop shortcut for Starfire itself (points at this Starfire.exe, so it keeps working after live updates)
$deskLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Starfire.lnk'
$miniLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Starfire Overlay.lnk'
function Show-ShortState {
    if (Test-Path $deskLnk) { $btnShort.Text = 'SHORTCUT' + [Environment]::NewLine + 'ON DESKTOP' }
    if (Test-Path $miniLnk) { $btnMini.Text = 'MINI LOADER  ✓' }
}
$btnMini.Add_Click({
    try {
        New-LiteShortcut
        Show-ShortState
        Say 'Desktop icon "Starfire Overlay" created - it checks for updates, then starts only the overlay.'
    } catch { Say ('Mini loader shortcut failed: ' + $_.Exception.Message) }
})
$btnShort.Add_Click({
    if (-not (Test-Path $hubExe)) { Say 'Start Starfire with Starfire.exe to create its shortcut.'; return }
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($deskLnk)
        $sc.TargetPath = $hubExe
        $sc.WorkingDirectory = $exeDir
        $sc.IconLocation = $hubExe + ',0'
        $sc.Description = 'Starfire - The Hidden Ones companion (translator, game, VPN)'
        $sc.Save()
        Say 'Desktop shortcut "Starfire" created.'
        Show-ShortState
    } catch { Say ('Shortcut failed: ' + $_.Exception.Message) }
})

$f.AcceptButton = $btnAll
$btnClose.Add_Click({ $f.Close() })

function Show-Ocr([bool]$ok) {
    if ($ok) { $lblOcr.Text = 'OCR: installed'; $lblOcr.ForeColor = $cGreen }
    else { $lblOcr.Text = 'OCR: MISSING'; $lblOcr.ForeColor = $cRed }
}
function Gate {
    # every button calls this first: re-checks the OCR, offers to install it, and stops the action without it
    $ok = Ensure-Ocr
    Show-Ocr $ok
    if (-not $ok) { Say 'Not started: Chinese text recognition (OCR) is required.' }
    return $ok
}
function Say([string]$t) { $stat.Text = $t; [System.Windows.Forms.Application]::DoEvents() }
function Show-PathState {
    if ($tbGame.Text -and (Test-Path $tbGame.Text)) { $lblGame.Text = 'Found.'; $lblGame.ForeColor = $cGreen } elseif ($tbGame.Text) { $lblGame.Text = 'This file does not exist - use BROWSE.'; $lblGame.ForeColor = $cRed } else { $lblGame.Text = 'Pick the game or its launcher (for example YiRenZhiXia.exe) with BROWSE.'; $lblGame.ForeColor = $cSoft }
    if ($tbUU.Text -and (Test-Path $tbUU.Text)) { $lblUU.Text = 'Found.'; $lblUU.ForeColor = $cGreen } elseif ($tbUU.Text) { $lblUU.Text = 'This file does not exist - use BROWSE.'; $lblUU.ForeColor = $cRed } else { $lblUU.Text = 'Pick the VPN / accelerator (.exe or its shortcut) with BROWSE.'; $lblUU.ForeColor = $cSoft }
    if ((Get-LiteProcs).Count -gt 0) { $lblLiteRun.Text = 'Starfire is running now (F8 = overlay on / off).' } else { $lblLiteRun.Text = 'Starfire is not running.' }
}
function Save-Now {
    $cfg.gamePath = $tbGame.Text.Trim('" '); $cfg.uuPath = $tbUU.Text.Trim('" '); $cfg.uuDelay = [int]$nudDelay.Value
    $cfg.startUU = $cbUU.Checked; $cfg.startGame = $cbGame.Checked; $cfg.startLite = $cbLite.Checked
    Save-Cfg
}
function Pick-Exe($tb, [string]$title) {
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.Title = $title; $d.Filter = 'Programs (*.exe;*.lnk)|*.exe;*.lnk|All files (*.*)|*.*'
    if ($tb.Text -and (Test-Path (Split-Path $tb.Text -Parent -ErrorAction SilentlyContinue))) { $d.InitialDirectory = Split-Path $tb.Text -Parent }
    if ($d.ShowDialog($f) -eq 'OK') {
        $p = $d.FileName
        if ($p -like '*.lnk') { try { $p = (New-Object -ComObject WScript.Shell).CreateShortcut($p).TargetPath } catch {} }
        $tb.Text = $p; Save-Now; Show-PathState
    }
}
function Start-Exe([string]$path, [string]$name) {
    $path = $path.Trim('" ')
    if (-not $path -or -not (Test-Path $path)) { Say "$name : no valid .exe chosen - use BROWSE."; return $false }
    try { Start-Process -FilePath $path -WorkingDirectory (Split-Path $path -Parent); Say "$name started."; return $true }
    catch { Say "$name could not be started: $($_.Exception.Message)"; return $false }
}

# ---------- Starfire overlay install / start ----------
function New-LiteShortcut {
    # desktop shortcut "Starfire Overlay" -> the mini loader (Starfire Overlay.exe next to Starfire.exe)
    if (-not (Test-Path $miniExe)) { throw 'Starfire Overlay.exe is missing - unzip the whole download into one folder.' }
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($miniLnk)
    $sc.TargetPath = $miniExe; $sc.Arguments = ''
    $sc.WorkingDirectory = $exeDir; $sc.IconLocation = $miniExe + ',0'; $sc.WindowStyle = 1
    $sc.Description = 'Starfire overlay only - checks for updates, then starts the translator'
    $sc.Save()
}
function Install-Lite {
    Say 'Installing Starfire ...'
    $was = Copy-LiteFiles
    if (Test-Path $miniLnk) { try { New-LiteShortcut } catch {} }      # an older overlay shortcut now points at the mini loader
    $script:prev = $LiteVersion; $lblLite.Text = Get-LiteState
    Say "Starfire $LiteVersion installed."
    return $was
}
function Start-Lite {
    if ($script:prev -ne $LiteVersion) { $null = Install-Lite }
    if ((Get-LiteProcs).Count -gt 0) { Say 'Starfire is already running - F8 turns the overlay on / off.'; return }
    Run-LiteProcess
    Say 'Starfire started - look for its icon in the tray. F8 turns the overlay on / off.'
}

$btnLiteInst.Add_Click({ if (-not (Gate)) { return }; try { $wasRunning = Install-Lite; if ($wasRunning) { Start-Lite } } catch { Say ('Install failed: ' + $_.Exception.Message) }; Show-PathState })
# after a successful launch the Starfire window closes by itself (a moment later, so the status line can be read)
function Close-Soon {
    $ct = New-Object System.Windows.Forms.Timer
    $ct.Interval = 900
    $ct.Add_Tick({ $this.Stop(); try { $f.Close() } catch {} })
    $ct.Start()
}
$btnLiteStart.Add_Click({ if (-not (Gate)) { return }; try { Start-Lite; Close-Soon } catch { Say ('Start failed: ' + $_.Exception.Message) }; Show-PathState })
$btnGameBrowse.Add_Click({ Pick-Exe $tbGame 'Choose The Hidden Ones (game or launcher .exe)' })
$btnUUBrowse.Add_Click({ Pick-Exe $tbUU 'Choose the VPN / accelerator (.exe)' })
$btnGame.Add_Click({ if (-not (Gate)) { return }; Save-Now; if (Start-Exe $tbGame.Text 'The Hidden Ones') { Close-Soon } })
$btnUU.Add_Click({ if (-not (Gate)) { return }; Save-Now; if (Start-Exe $tbUU.Text 'VPN') { Close-Soon } })
$tbGame.Add_Leave({ Save-Now; Show-PathState })
$tbUU.Add_Leave({ Save-Now; Show-PathState })

$btnAll.Add_Click({
    if (-not (Gate)) { return }
    Save-Now
    $btnAll.Enabled = $false
    try {
        if ($cbVpn.Checked -and $cbUU.Checked) {
            if (Start-Exe $tbUU.Text 'VPN') {
                $wait = [int]$nudDelay.Value
                for ($s = $wait; $s -gt 0; $s--) { Say "VPN started - starting the game in $s s (connect / accelerate the game in the VPN now) ..."; for ($k = 0; $k -lt 10; $k++) { Start-Sleep -Milliseconds 100; [System.Windows.Forms.Application]::DoEvents() } }
            }
        }
        if ($cbGameSec.Checked -and $cbGame.Checked) { $null = Start-Exe $tbGame.Text 'The Hidden Ones' }
        if ($cbLite.Checked -or -not ($cbGameSec.Checked -or $cbVpn.Checked)) { Start-Lite }
        Say 'Launched. Have fun!'
        Close-Soon
    } catch { Say ('Launch failed: ' + $_.Exception.Message) }
    $btnAll.Enabled = $true
    Show-PathState
})
$f.Add_FormClosing({ Save-Now })
$script:AutoTried = $false
# the Starfire overlay is kept up to date automatically: an installed copy that differs from the included one is replaced
# as soon as the window opens (and restarted if it was running), no button needed
function Auto-UpdateLite {
    if ($prev -eq '' -or $script:prev -eq $LiteVersion) { return }
    try {
        $wasRunning = Install-Lite
        if ($wasRunning) { Start-Lite }
        Say "The Starfire overlay was updated to $LiteVersion automatically."
        Show-PathState
    } catch { Say ('Automatic overlay update failed: ' + $_.Exception.Message + ' - use INSTALL / UPDATE.') }
}
$f.Add_Shown({
    Auto-UpdateLite
    if ($script:QuickUpd) {
        # opened by the mini loader because an update is waiting: install it right away (no question), then back to the overlay
        $script:Upd = $script:QuickUpd
        $lblUpd.Text = "Update available:  v$HubVersion  ->  v$($script:Upd.ver)"; $lblUpd.ForeColor = $cGreen
        $btnUpd.Text = "UPDATE TO $($script:Upd.ver)"; $btnUpd.Visible = $true
        Say 'Installing the update - the overlay starts by itself afterwards.'
        Begin-Update
    } else { Start-UpdCheck }
})
$f.Add_Shown({ Show-ShortState; Show-Ocr (Test-ChineseOcr); Show-PathState; $f.TopMost = $true; $f.Activate(); $f.TopMost = $false })
[void]$f.ShowDialog()
