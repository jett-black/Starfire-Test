﻿# Starfire Lite launcher / setup window: installs, updates and starts Starfire Lite (%LOCALAPPDATA%\StarfireLite\app)
param([string]$Version = '2.9.3')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$src      = $PSScriptRoot
$dataDir  = Join-Path $env:LOCALAPPDATA 'StarfireLite'
$appDir   = Join-Path $dataDir 'app'
$verFile  = Join-Path $appDir 'version.txt'
$files    = @('StarfireLite.ps1', 'starfire-lite-dict.tsv', 'glossary.csv', 'starfire.ico', 'README.txt', 'Install-OcrPack.ps1', 'StarfireLiteSetup.ps1')

$prev = ''
try { if (Test-Path $verFile) { $prev = ([System.IO.File]::ReadAllText($verFile)).Trim() } } catch {}
if (-not $prev -and (Test-Path (Join-Path $appDir 'StarfireLite.ps1'))) { $prev = 'older' }

function Test-ChineseOcr {
    try {
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        foreach ($l in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) { $lt = [string]$l.LanguageTag; if ($lt -eq 'zh-Hans' -or $lt -like 'zh-Hans-*' -or $lt -eq 'zh-CN') { return $true } }
    } catch {}
    return $false
}
function Get-LiteProcs {
    try { @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*StarfireLite.ps1*' -or $_.CommandLine -like '*StarfireLiteWD*' }) } catch { @() }
}
function Install-Ocr {
    # elevated install of the Chinese OCR pack with its own progress window; true when it is available afterwards
    $sp = Join-Path $src 'Install-OcrPack.ps1'
    try { $null = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$sp`"", '-Elevated', '-App', '"Starfire Lite"') } catch {}
    return (Test-ChineseOcr)
}

# ---------- Chinese text recognition is required: install it first ----------
$ocrOk = Test-ChineseOcr
while (-not $ocrOk) {
    $q = "Starfire Lite needs Windows' Chinese (Simplified) text recognition (OCR) to read the game, and it is not installed " +
         "on this PC.`n`nIt is installed now from Windows Update (about 30 MB). Windows will ask for administrator permission " +
         "and a small window shows the progress.`n`nInstall it now?  (Starfire Lite cannot work without it.)"
    $r = [System.Windows.Forms.MessageBox]::Show($q, 'Starfire Lite - Chinese text recognition required', 'OKCancel', 'Warning')
    if ([string]$r -ne 'OK') { exit 1 }
    $ocrOk = Install-Ocr
    if (-not $ocrOk) {
        $r2 = [System.Windows.Forms.MessageBox]::Show("The Chinese text recognition is still not available.`n`nIf the install window showed an error (for example on a school / work PC), you can also add it by hand: Settings > Time & language > Language > Chinese (Simplified) > Language options > Optical character recognition.`n`nTry again?", 'Starfire Lite', 'RetryCancel', 'Error')
        if ([string]$r2 -ne 'Retry') { exit 1 }
    }
}

# ---------- supernova background (drawn once) ----------
$W = 640; $H = 470
function New-SpaceArt([int]$w, [int]$h) {
    $bmp = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    # deep space: near-black violet to dark wine
    $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point(0, 0)), (New-Object System.Drawing.Point($w, $h)), ([System.Drawing.Color]::FromArgb(10, 6, 22)), ([System.Drawing.Color]::FromArgb(26, 4, 14))
    $g.FillRectangle($bg, 0, 0, $w, $h)
    $rnd = New-Object System.Random 7
    # nebula clouds: soft red and purple blobs
    $clouds = @(@(0.78, 0.22, 330, 170, 40, 120), @(0.62, 0.40, 260, 120, 30, 160), @(0.90, 0.55, 220, 150, 20, 140), @(0.15, 0.85, 260, 70, 30, 120), @(0.35, 0.10, 200, 110, 30, 150))
    foreach ($c in $clouds) {
        $cx = $c[0] * $w; $cy = $c[1] * $h; $rr = [double]$c[2]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($cx - $rr), [single]($cy - $rr * 0.7), [single]($rr * 2), [single]($rr * 1.4))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$c[4], [int]$c[3], 20, [int]$c[5])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 10, 0, 20))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    # stars
    for ($i = 0; $i -lt 420; $i++) {
        $x = $rnd.NextDouble() * $w; $y = $rnd.NextDouble() * $h
        $a = 60 + $rnd.Next(195); $sz = 0.6 + $rnd.NextDouble() * 1.6
        $tint = $rnd.Next(3)
        if ($tint -eq 0) { $col = [System.Drawing.Color]::FromArgb($a, 255, 255, 255) } elseif ($tint -eq 1) { $col = [System.Drawing.Color]::FromArgb($a, 255, 200, 220) } else { $col = [System.Drawing.Color]::FromArgb($a, 210, 190, 255) }
        $sb = New-Object System.Drawing.SolidBrush $col
        $g.FillEllipse($sb, [single]$x, [single]$y, [single]$sz, [single]$sz); $sb.Dispose()
    }
    # the supernova: rays, layered glow, white-hot core
    $nx = $w * 0.80; $ny = $h * 0.24
    for ($k = 0; $k -lt 14; $k++) {
        $ang = $k * [Math]::PI / 7 + 0.2; $len = 90 + $rnd.Next(150)
        $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(60, 255, 120, 170)), 1.6
        $g.DrawLine($pen, [single]$nx, [single]$ny, [single]($nx + [Math]::Cos($ang) * $len), [single]($ny + [Math]::Sin($ang) * $len)); $pen.Dispose()
    }
    foreach ($ring in @(@(150, 70, 150, 40, 200), @(95, 120, 230, 40, 120), @(55, 190, 255, 80, 90), @(26, 255, 255, 200, 230))) {
        $rr = [double]$ring[0]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($nx - $rr), [single]($ny - $rr), [single]($rr * 2), [single]($rr * 2))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$ring[1], [int]$ring[2], [int]$ring[3], [int]$ring[4])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 120, 20, 160))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    $core = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 250, 245))
    $g.FillEllipse($core, [single]($nx - 5), [single]($ny - 5), 10, 10); $core.Dispose()
    # glass cards behind the content
    function Fill-Card($gr, [int]$x, [int]$y, [int]$cw, [int]$ch) {
        $p = New-Object System.Drawing.Drawing2D.GraphicsPath; $rad = 14
        $p.AddArc($x, $y, $rad, $rad, 180, 90); $p.AddArc($x + $cw - $rad, $y, $rad, $rad, 270, 90)
        $p.AddArc($x + $cw - $rad, $y + $ch - $rad, $rad, $rad, 0, 90); $p.AddArc($x, $y + $ch - $rad, $rad, $rad, 90, 90); $p.CloseFigure()
        $fb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(150, 12, 8, 24))
        $gr.FillPath($fb, $p); $fb.Dispose()
        $pn = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(90, 200, 90, 220)), 1
        $gr.DrawPath($pn, $p); $pn.Dispose(); $p.Dispose()
    }
    Fill-Card $g 24 128 592 152
    Fill-Card $g 24 292 592 118
    $g.Dispose()
    return $bmp
}

# ---------- window ----------
$f = New-Object System.Windows.Forms.Form
$f.Text = "Starfire Lite $Version"
$f.ClientSize = New-Object System.Drawing.Size($W, $H)
$f.FormBorderStyle = 'FixedSingle'; $f.MaximizeBox = $false
$f.StartPosition = 'CenterScreen'
$f.BackColor = [System.Drawing.Color]::FromArgb(10, 6, 22); $f.ForeColor = [System.Drawing.Color]::White
$f.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
try { $f.Icon = New-Object System.Drawing.Icon (Join-Path $src 'starfire.ico') } catch {}
try { $f.BackgroundImage = New-SpaceArt $W $H; $f.BackgroundImageLayout = 'None' } catch {}
try { $f.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($f, $true, $null) } catch {}

function New-Label([string]$t, [int]$x, [int]$y, [single]$size, [string]$style, [System.Drawing.Color]$col, [int]$w = 0) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $t; $l.BackColor = [System.Drawing.Color]::Transparent; $l.ForeColor = $col
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $size, [System.Drawing.FontStyle]$style)
    $l.Location = New-Object System.Drawing.Point($x, $y)
    if ($w -gt 0) { $l.Size = New-Object System.Drawing.Size($w, [int]($size * 2.2)) } else { $l.AutoSize = $true }
    $f.Controls.Add($l); return $l
}
$cWhite = [System.Drawing.Color]::FromArgb(245, 240, 255)
$cSoft  = [System.Drawing.Color]::FromArgb(196, 182, 222)
$cRed   = [System.Drawing.Color]::FromArgb(255, 92, 120)
$cGreen = [System.Drawing.Color]::FromArgb(120, 230, 170)

$null = New-Label 'STARFIRE' 26 18 30 'Bold' $cWhite
$null = New-Label 'LITE' 238 34 14 'Bold' $cRed
$null = New-Label "Chinese -> English overlay for The Hidden Ones   |   v$Version" 30 74 9.5 'Regular' $cSoft

# status card
$null = New-Label 'STATUS' 44 140 8.5 'Bold' $cRed
if ($prev -eq '') { $stT = 'Not installed yet' } elseif ($prev -eq $Version) { $stT = "Version $Version installed - up to date" } else { $stT = "Installed: $prev   ->   update to $Version available" }
$null = New-Label $stT 44 160 12 'Bold' $cWhite 550
$null = New-Label 'Chinese text recognition (OCR):  installed' 44 192 9.5 'Regular' $cGreen
$null = New-Label "Folder:  $appDir" 44 214 9 'Regular' $cSoft 550
$running = (Get-LiteProcs).Count -gt 0
if ($running) { $null = New-Label 'Starfire Lite is running right now (it is restarted after an update).' 44 236 9 'Regular' $cSoft 550 }

# options card
$null = New-Label 'OPTIONS' 44 302 8.5 'Bold' $cRed
function New-Check([string]$t, [int]$x, [int]$y, [bool]$on) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $t; $c.Checked = $on; $c.AutoSize = $true; $c.BackColor = [System.Drawing.Color]::Transparent; $c.ForeColor = $cWhite
    $c.Location = New-Object System.Drawing.Point($x, $y); $f.Controls.Add($c); return $c
}
$cbDesk  = New-Check 'Desktop shortcut' 44 324 $true
$cbStart = New-Check 'Start menu entry' 220 324 $true
$cbRun   = New-Check 'Start Starfire Lite when done' 390 324 $true

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Location = New-Object System.Drawing.Point(44, 356); $bar.Size = New-Object System.Drawing.Size(552, 8); $bar.Style = 'Continuous'
$f.Controls.Add($bar)
$stat = New-Label 'Ready.' 44 372 9 'Regular' $cSoft 552

function New-Btn([string]$t, [int]$x, [int]$w, [System.Drawing.Color]$bc, [System.Drawing.Color]$fc) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, 420); $b.Size = New-Object System.Drawing.Size($w, 36)
    $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $bc; $b.ForeColor = $fc
    $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $f.Controls.Add($b); return $b
}
$upToDate = ($prev -eq $Version)
if ($upToDate) { $mainT = 'START' } elseif ($prev -eq '') { $mainT = 'INSTALL' } else { $mainT = 'UPDATE' }
$btnMain  = New-Btn $mainT 24 200 ([System.Drawing.Color]::FromArgb(214, 40, 90)) ([System.Drawing.Color]::White)
$btnAlt   = New-Btn 'REINSTALL' 234 150 ([System.Drawing.Color]::FromArgb(110, 50, 170)) ([System.Drawing.Color]::White)
$btnClose = New-Btn 'CLOSE' 486 130 ([System.Drawing.Color]::FromArgb(40, 30, 64)) $cSoft
$btnAlt.Visible = $upToDate
$f.AcceptButton = $btnMain
$btnClose.Add_Click({ $f.Close() })

function Say([string]$t) { $stat.Text = $t; [System.Windows.Forms.Application]::DoEvents() }
function Step([int]$p) { $bar.Value = [Math]::Max(0, [Math]::Min(100, $p)); [System.Windows.Forms.Application]::DoEvents() }
function New-Shortcut([string]$path) {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($path)
    $sc.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $sc.Arguments = '-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $appDir 'StarfireLite.ps1') + '"'
    $sc.WorkingDirectory = $appDir
    $sc.IconLocation = (Join-Path $appDir 'starfire.ico') + ',0'
    $sc.Description = 'Starfire Lite - Chinese to English overlay'
    $sc.WindowStyle = 7
    $sc.Save()
}
function Start-Lite {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $appDir 'StarfireLite.ps1')`"")
}
function Do-Install {
    foreach ($c in @($btnMain, $btnAlt, $btnClose, $cbDesk, $cbStart, $cbRun)) { $c.Enabled = $false }
    try {
        Step 5
        $procs = Get-LiteProcs
        if ($procs.Count -gt 0) { Say 'Closing the running Starfire Lite ...'; foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force } catch {} }; Start-Sleep -Milliseconds 800 }
        Say 'Copying files ...'
        New-Item -ItemType Directory -Force -Path $appDir | Out-Null
        $i = 0
        foreach ($fn in $files) {
            $s = Join-Path $src $fn
            if (Test-Path $s) {
                $d = Join-Path $appDir $fn
                if ($s -ne $d) {
                    if (Test-Path $d) { try { (Get-Item $d).IsReadOnly = $false } catch {} }
                    Copy-Item $s $d -Force
                }
            }
            $i++; Step (10 + [int](70 * $i / $files.Count))
        }
        [System.IO.File]::WriteAllText($verFile, $Version)
        if ($cbDesk.Checked) { try { New-Shortcut (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Starfire Lite.lnk') } catch {} }
        if ($cbStart.Checked) { try { New-Shortcut (Join-Path ([Environment]::GetFolderPath('Programs')) 'Starfire Lite.lnk') } catch {} }
        Step 100
        if ($prev -eq '') { $done = "Starfire Lite $Version is installed." } elseif ($prev -eq $Version) { $done = "Starfire Lite $Version has been reinstalled." } else { $done = "Updated from $prev to $Version." }
        if ($cbRun.Checked) { Start-Lite; $done += '  Starting it now - F8 turns the overlay on / off.' }
        Say $done
        $btnClose.Text = 'DONE'
    } catch {
        Say ('Setup failed: ' + $_.Exception.Message + '  - quit Starfire Lite (Ctrl+Shift+Q) and try again.')
        $btnMain.Enabled = $true; $btnAlt.Enabled = $true
    }
    $btnClose.Enabled = $true
}
$btnMain.Add_Click({
    if ($upToDate) {
        if ((Get-LiteProcs).Count -gt 0) { Say 'Starfire Lite is already running - press F8 in the game.' }
        else { Start-Lite; Say 'Starting Starfire Lite - look for its icon in the tray. F8 turns the overlay on / off.' }
        $btnClose.Text = 'DONE'
    } else { Do-Install }
})
$btnAlt.Add_Click({ Do-Install })

$f.Add_Shown({ $f.TopMost = $true; $f.Activate(); $f.TopMost = $false })
[void]$f.ShowDialog()
