﻿# Starfire Lite 2.8 - Chinese -> English overlay for The Hidden Ones: game dictionary first, online translators as backup
# based on Project Starfire 1.6.19
# Project Starfire v2.3 - key thread (F7/F8 work during scans), un-stick fixes, ~500-entry short UI dictionary, on-screen toggle notices.
# Project Starfire v2.2 - F8 on/off, F7 debug, stricter box chaining, built-in UI dictionary.
# Project Starfire v2.1 - attaches to the game (YiRenZhiXia.exe), exits when it closes, on/off + debug toggles.
# Project Starfire v2 - live Chinese -> English overlay
# v2: non-blocking translation, game-string dictionary + glossary, overlay excluded from capture,
#     no more sticky-position drift, larger/padded labels, BMP instead of PNG, lower CPU priority.
# Full lines and description blocks. Click-through. F8 toggles.
# Tray icon is created BEFORE any OCR work so a failure cannot hide the app.

$ErrorActionPreference = 'Continue'
$script:AppName = 'Starfire Lite'
# test builds (a "channel-test.txt" next to this script) keep everything apart from the normal version: own settings,
# cache, log and watchdog in %LOCALAPPDATA%\StarfireLite-Test, so a test copy never touches the normal one
$script:IsTest = $false; try { $script:IsTest = Test-Path (Join-Path $PSScriptRoot 'channel-test.txt') } catch {}
$script:Tag = ''; if ($script:IsTest) { $script:Tag = ' TEST' }
if ($script:IsTest) { $script:DataDir = Join-Path $env:LOCALAPPDATA 'StarfireLite-Test' } else { $script:DataDir = Join-Path $env:LOCALAPPDATA 'StarfireLite' }
New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null
# carry over glossary/dictionary from the old Project Starfire data folder (first run only)
try {
    $oldDir = Join-Path $env:LOCALAPPDATA 'Starfire Lite'
    if (Test-Path $oldDir) { foreach ($f in 'glossary.csv', 'dictionary.tsv') { $o = Join-Path $oldDir $f; $n = Join-Path $script:DataDir $f; if ((Test-Path $o) -and -not (Test-Path $n)) { Copy-Item $o $n } } }
} catch {}
if ($script:IsTest) { try { $nd = Join-Path $env:LOCALAPPDATA 'StarfireLite'; foreach ($f in 'settings.json', 'translation-cache.json', 'glossary.csv') { $o = Join-Path $nd $f; $n = Join-Path $script:DataDir $f; if ((Test-Path $o) -and -not (Test-Path $n)) { Copy-Item $o $n } } } catch {} }   # a test copy starts with a copy of the normal settings
$script:SettingsPath = Join-Path $script:DataDir 'settings.json'
$script:CachePath    = Join-Path $script:DataDir 'translation-cache.json'
try {
    $psCache = Join-Path (Join-Path $env:LOCALAPPDATA 'ProjectStarfire') 'translation-cache.json'
    if ((Test-Path $psCache) -and -not (Test-Path $script:CachePath)) { Copy-Item $psCache $script:CachePath -Force }
    $psGl = Join-Path (Join-Path $env:LOCALAPPDATA 'ProjectStarfire') 'glossary.csv'
    $myGl = Join-Path $script:DataDir 'glossary.csv'
    if ((Test-Path $psGl) -and -not (Test-Path $myGl)) { Copy-Item $psGl $myGl -Force }
} catch {}
$script:LogPath      = Join-Path $script:DataDir 'starfire.log'
try { if ((Test-Path $script:LogPath) -and ((Get-Item $script:LogPath).Length -gt 1MB)) { $tail0 = Get-Content $script:LogPath -Tail 300 -Encoding UTF8; Set-Content -Path $script:LogPath -Value $tail0 -Encoding UTF8 } } catch {}

function Write-Log([string]$msg) {
    try {
        $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $msg
        Add-Content -Path $script:LogPath -Value $line -Encoding UTF8
    } catch {}
}
function Show-Error([string]$msg) {
    Write-Log "ERROR: $msg"
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show($msg, 'Starfire Lite', 'OK', 'Error') | Out-Null
    } catch {}
}

trap {
    Write-Log ("trap: " + $_.Exception.Message)
    continue
}

$script:AppVersion = '2.9.36'
Write-Log ('---- start ---- Starfire Lite ' + $script:AppVersion)
$script:IsAdmin = $false
try { $script:IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch {}
if (-not $script:IsAdmin -and -not ($args -contains '--elevated') -and -not (Test-Path (Join-Path $script:DataDir 'no-elevate.txt'))) {
    # Windows blocks keyboard access across privilege levels, so run elevated (create no-elevate.txt in the data folder to opt out).
    try {
        Write-Log 'relaunching elevated'
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $PSCommandPath + '" --elevated')
        exit
    } catch { Write-Log ('elevation declined: ' + $_.Exception.Message) }
}
Write-Log ('admin: ' + $script:IsAdmin)

# ---------- only one Starfire overlay at a time ----------
# Starting this overlay closes every other one first: other copies of Starfire Lite (test or official, any version or folder),
# the full Project Starfire and the old HanScreen - together with their watchdogs, so those cannot bring them back.
# (This copy runs elevated, so it can also close copies that run elevated.)
try {
    foreach ($dd in @((Join-Path $env:LOCALAPPDATA 'ProjectStarfire'), (Join-Path $env:LOCALAPPDATA 'StarfireLite'), (Join-Path $env:LOCALAPPDATA 'StarfireLite-Test'))) { try { if (Test-Path $dd) { [System.IO.File]::WriteAllText((Join-Path $dd 'quit.flag'), '1') } } catch {} }
    $ps0 = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue)
    $myPid = $PID
    $wds = @($ps0 | Where-Object { $_.ProcessId -ne $myPid -and $_.CommandLine -and ($_.CommandLine -like '*StarfireLiteWD*' -or $_.CommandLine -like '*StarfireWatchdog*') })
    $apps = @($ps0 | Where-Object { $_.ProcessId -ne $myPid -and $_.CommandLine -and ($_.CommandLine -like '*StarfireLite.ps1*' -or $_.CommandLine -match '[\\/"]Starfire\.ps1' -or $_.CommandLine -like '*HanScreen*.ps1*') })
    foreach ($p0 in @($wds + $apps)) {
        try { Stop-Process -Id $p0.ProcessId -Force -ErrorAction Stop; Write-Log ('closed another Starfire overlay / watchdog: pid ' + $p0.ProcessId) }
        catch { Write-Log ('could not close pid ' + $p0.ProcessId + ': ' + $_.Exception.Message) }
    }
    if (@($apps).Count -gt 0) { Start-Sleep -Milliseconds 400 }       # let their tray icons and hotkeys go before this one claims them
} catch { Write-Log ('closing other copies: ' + $_.Exception.Message) }

try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
    [System.Windows.Forms.Application]::add_ThreadException({
        try { Write-Log ("ui: " + $_.Exception.Message) } catch {}
    })
} catch {
    Show-Error "Could not load Windows Forms: $($_.Exception.Message)"
    exit 1
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class HSNative {
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
    [DllImport("user32.dll")] public static extern bool SetWindowDisplayAffinity(IntPtr hWnd, uint affinity);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

try { Add-Type -ReferencedAssemblies System.Drawing -ErrorAction Stop -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public class HSLayer {
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    public struct SIZE { public int CX; public int CY; }
    [StructLayout(LayoutKind.Sequential)]
    public struct BLENDFUNCTION {
        public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct BITMAPINFOHEADER {
        public int biSize; public int biWidth; public int biHeight; public short biPlanes; public short biBitCount;
        public int biCompression; public int biSizeImage; public int biXPelsPerMeter; public int biYPelsPerMeter;
        public int biClrUsed; public int biClrImportant;
    }
    [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize, IntPtr hdcSrc, ref POINT pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hwnd);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
    [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
    [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFOHEADER pbmi, uint usage, out IntPtr bits, IntPtr section, uint offset);

    public static void Apply(IntPtr hwnd, Bitmap bmp, int x, int y) {
        IntPtr screenDc = GetDC(IntPtr.Zero);
        IntPtr memDc = CreateCompatibleDC(screenDc);
        IntPtr hBitmap = IntPtr.Zero;
        IntPtr old = IntPtr.Zero;
        try {
            BITMAPINFOHEADER bmi = new BITMAPINFOHEADER();
            bmi.biSize = 40;
            bmi.biWidth = bmp.Width;
            bmi.biHeight = -bmp.Height;
            bmi.biPlanes = 1;
            bmi.biBitCount = 32;
            IntPtr bits;
            hBitmap = CreateDIBSection(screenDc, ref bmi, 0, out bits, IntPtr.Zero, 0);
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int bytes = Math.Abs(data.Stride) * bmp.Height;
            byte[] buf = new byte[bytes];
            Marshal.Copy(data.Scan0, buf, 0, bytes);
            bmp.UnlockBits(data);
            for (int i = 0; i < buf.Length; i += 4) {
                byte a = buf[i + 3];
                buf[i] = (byte)(buf[i] * a / 255);
                buf[i + 1] = (byte)(buf[i + 1] * a / 255);
                buf[i + 2] = (byte)(buf[i + 2] * a / 255);
            }
            Marshal.Copy(buf, 0, bits, bytes);
            old = SelectObject(memDc, hBitmap);
            SIZE size = new SIZE { CX = bmp.Width, CY = bmp.Height };
            POINT src = new POINT { X = 0, Y = 0 };
            POINT dst = new POINT { X = x, Y = y };
            BLENDFUNCTION blend = new BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
            UpdateLayeredWindow(hwnd, screenDc, ref dst, ref size, memDc, ref src, 0, ref blend, 2);
        } finally {
            if (old != IntPtr.Zero) SelectObject(memDc, old);
            if (hBitmap != IntPtr.Zero) DeleteObject(hBitmap);
            DeleteDC(memDc);
            ReleaseDC(IntPtr.Zero, screenDc);
        }
    }

    public static Bitmap Frost(Bitmap src, int x, int y, int w, int h, int alpha) {
        if (x < 0) { w += x; x = 0; }
        if (y < 0) { h += y; y = 0; }
        if (x + w > src.Width) w = src.Width - x;
        if (y + h > src.Height) h = src.Height - y;
        if (w < 2 || h < 2) return null;
        Bitmap crop = src.Clone(new Rectangle(x, y, w, h), PixelFormat.Format32bppArgb);
        Bitmap blurred = BoxBlur(crop, 3);
        crop.Dispose();
        BitmapData data = blurred.LockBits(new Rectangle(0, 0, blurred.Width, blurred.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        int bytes = Math.Abs(data.Stride) * blurred.Height;
        byte[] buf = new byte[bytes];
        Marshal.Copy(data.Scan0, buf, 0, bytes);
        for (int i = 0; i < buf.Length; i += 4) buf[i + 3] = (byte)alpha;
        Marshal.Copy(buf, 0, data.Scan0, bytes);
        blurred.UnlockBits(data);
        return blurred;
    }

    static Bitmap BoxBlur(Bitmap src, int radius) {
        int w = src.Width, h = src.Height;
        BitmapData sdata = src.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        byte[] srcB = new byte[Math.Abs(sdata.Stride) * h];
        Marshal.Copy(sdata.Scan0, srcB, 0, srcB.Length);
        src.UnlockBits(sdata);
        int stride = Math.Abs(sdata.Stride);
        byte[] tmp = new byte[srcB.Length];
        byte[] dst = new byte[srcB.Length];
        int diam = radius * 2 + 1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0;
                for (int k = -radius; k <= radius; k++) {
                    int xx = x + k; if (xx < 0) xx = 0; if (xx >= w) xx = w - 1;
                    int i = y * stride + xx * 4;
                    b += srcB[i]; g += srcB[i + 1]; r += srcB[i + 2];
                }
                int o = y * stride + x * 4;
                tmp[o] = (byte)(b / diam); tmp[o + 1] = (byte)(g / diam); tmp[o + 2] = (byte)(r / diam); tmp[o + 3] = 255;
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0;
                for (int k = -radius; k <= radius; k++) {
                    int yy = y + k; if (yy < 0) yy = 0; if (yy >= h) yy = h - 1;
                    int i = yy * stride + x * 4;
                    b += tmp[i]; g += tmp[i + 1]; r += tmp[i + 2];
                }
                int o = y * stride + x * 4;
                dst[o] = (byte)(b / diam); dst[o + 1] = (byte)(g / diam); dst[o + 2] = (byte)(r / diam); dst[o + 3] = 255;
            }
        }
        Bitmap result = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData ddata = result.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        Marshal.Copy(dst, 0, ddata.Scan0, dst.Length);
        result.UnlockBits(ddata);
        return result;
    }
}
"@
} catch {}

try { [HSNative]::SetProcessDpiAwarenessContext([IntPtr]::new(-4)) | Out-Null } catch {}
try {
    $con = [HSNative]::GetConsoleWindow()
    if ($con -ne [IntPtr]::Zero) { [HSNative]::ShowWindow($con, 0) | Out-Null }
} catch {}

# ---------- settings / cache ----------
$script:Settings = @{
    enabled = $true
    intervalMs = 1000
    ocrLang = 'zh-Hans'
    captureMode = 'game'
    gameProcess = 'YiRenZhiXia'
    exitWithGame = $false
    debug = $false
    excludeFromCapture = $false
    printCapture = 'auto'
    glassBlur = 4
    glassTint = 16
    settingsVersion = 2
    region = $null
    displayMode = 'labels'
    maxCaptureWidth = 1600
    fontSize = 16
    joinDescriptions = $true
    glass = $true
    maxBlockChars = 1500
}
if (Test-Path $script:SettingsPath) {
    try {
        $j = Get-Content $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in $j.PSObject.Properties) { $script:Settings[$p.Name] = $p.Value }
    } catch { Write-Log "settings: $_" }
}
$script:Settings.intervalMs = 1500
$script:Settings.debug = $false          # the debug overlay is switched off in released builds (no menu item, F7 does nothing)
if ([int]$script:Settings.settingsVersion -lt 2) { $script:Settings.captureMode = 'game'; $script:Settings.settingsVersion = 2; $script:Settings.exitWithGame = $false; if (-not $script:Settings.gameProcess) { $script:Settings.gameProcess = 'YiRenZhiXia' } }
function Save-Settings {
    try { ($script:Settings | ConvertTo-Json -Depth 6) | Set-Content $script:SettingsPath -Encoding UTF8 } catch {}
}
# 1.6.11: contrast passes run every 0.7 s (was 1.2 s) and cycle through three kinds; the new one multiplies small brightness / colour differences by 16 so grey text on a similar background is read.
# 1.6.10: the label-background routines copied whole rows of the screen picture for partial areas, which reads memory past the end of the picture when a label sits near the bottom edge; Windows then ends the process without any message. Rows are now copied exactly (CopyRows). Watchdog gives up only after 30 restarts in 10 minutes.
# 1.6.9: the program never closes by itself any more (the old 'close when the game closes' option is switched off once)
if ([string]$script:Settings.captureMode -eq 'activewindow') { $script:Settings.captureMode = 'fullscreen' }      # the old 'active window' mode is now the desktop overlay
if ([int]$script:Settings.settingsVersion -lt 3) { $script:Settings.exitWithGame = $false; $script:Settings.settingsVersion = 3; Save-Settings }

function Clean-Names([string]$t) {
    # the game's name for itself is "Hidden Ones": drop pinyin glosses such as "Hidden Ones (Yi Ren)" / "[Yi Ren]" / "- Yi Ren"
    if ([string]::IsNullOrEmpty($t)) { return $t }
    # 天下会武 is called "Martial Tournament" everywhere (also in older saved / online translations)
    if ($t.IndexOf('Martial Gathering', [StringComparison]::OrdinalIgnoreCase) -ge 0) { $t = [regex]::Replace($t, '(?:Grand\s+)?Martial\s+Gathering', 'Martial Tournament', 'IgnoreCase') }
    if ($t.IndexOf('Yi', [StringComparison]::OrdinalIgnoreCase) -lt 0) { return $t }
    $t = [regex]::Replace($t, '\s*[\(\[\{\uff08\u3010<]\s*Yi\s?-?Ren\s*[\)\]\}\uff09\u3011>]', '', 'IgnoreCase')
    $t = [regex]::Replace($t, '(?<=Hidden Ones?)\s*[,:;/\-\u2013\u2014|]\s*Yi\s?-?Ren\b', '', 'IgnoreCase')
    $t = [regex]::Replace($t, '\bYi\s?-?Ren\b(?!\s*-?\s*(?:Zhi|Xia))', 'Hidden Ones', 'IgnoreCase')
    $t = [regex]::Replace($t, '\b(Hidden Ones?)(\s+\1\b)+', '$1', 'IgnoreCase')
    return $t
}
$script:Cache = @{}
if (Test-Path $script:CachePath) {
    try {
        $raw = Get-Content $script:CachePath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in $raw.PSObject.Properties) { $script:Cache[$p.Name] = (Clean-Names ([string]$p.Value)) }
    } catch {}
}
$script:CacheDirty = 0
$script:CacheSavedAt = [int64]0
function Save-Cache {
    try {
        if ($script:Cache.Count -gt 12000) { foreach ($ck in @($script:Cache.Keys | Select-Object -First 3000)) { $script:Cache.Remove($ck) } }       # keep the file (and memory) bounded
        $json = $null
        try {
            if (-not $script:SerC) { Add-Type -AssemblyName System.Web.Extensions; $script:SerC = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $script:SerC.MaxJsonLength = 67108864 }
            $json = $script:SerC.Serialize($script:Cache)
        } catch { $json = $null }
        if (-not $json) { $json = ($script:Cache | ConvertTo-Json -Depth 3 -Compress) }
        [System.IO.File]::WriteAllText($script:CachePath, $json, (New-Object System.Text.UTF8Encoding($true)))
        $script:CacheDirty = 0; $script:CacheSavedAt = [int64][Environment]::TickCount
    } catch {}
}

# ---------- tray FIRST, before OCR ----------
$script:Status = 'starting'
$script:Sample = ''
$script:LastBlocks = @()
$script:LastHash = $null
$script:PendingHash = $null
$script:LastOcrAt = $null
$script:EmptyScans = 0
$script:Scanning = $false
$script:OcrReady = $false
$script:OcrError = $null

function New-TrayIcon([bool]$on) {
    $bmp = New-Object System.Drawing.Bitmap 32, 32
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.Clear([System.Drawing.Color]::Transparent)
    $br0 = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 12, 6, 10)); $g.FillEllipse($br0, 1, 1, 30, 30); $br0.Dispose()
    if ($on) { $ringC = [System.Drawing.Color]::FromArgb(255, 150, 70, 220); $starC = [System.Drawing.Color]::FromArgb(255, 230, 30, 45) }
    else { $ringC = [System.Drawing.Color]::FromArgb(255, 90, 90, 96); $starC = [System.Drawing.Color]::FromArgb(255, 120, 120, 128) }
    $pn0 = New-Object System.Drawing.Pen $ringC, 2; $g.DrawEllipse($pn0, 2, 2, 27, 27); $pn0.Dispose()
    $pts = New-Object 'System.Drawing.PointF[]' 8
    for ($i = 0; $i -lt 8; $i++) {
        $ang = [Math]::PI / 4 * $i - [Math]::PI / 2
        if ($i % 2 -eq 0) { $r = 12 } else { $r = 3.6 }
        $pts[$i] = New-Object System.Drawing.PointF ([single](16 + $r * [Math]::Cos($ang))), ([single](16 + $r * [Math]::Sin($ang)))
    }
    $br1 = New-Object System.Drawing.SolidBrush $starC; $g.FillPolygon($br1, $pts); $br1.Dispose()
    $g.Dispose()
    # copy the icon so it owns its data, then free the Windows icon handle and the bitmap at once (each GetHicon makes a
    # handle that Windows never frees by itself: made on every scan, they ran out after a while and every scan then failed
    # with 'A generic error occurred in GDI+')
    $h = $bmp.GetHicon()
    try { $tmp = [System.Drawing.Icon]::FromHandle($h); $ico = $tmp.Clone(); $tmp.Dispose() } finally { [void][StarIco]::DestroyIcon($h); $bmp.Dispose() }
    return $ico
}
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class StarIco { [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr h); }'
# the two tray icons are made once and re-used
$script:IconOn = New-TrayIcon $true
$script:IconOff = New-TrayIcon $false
$script:TrayOn = $null

$script:Tray = New-Object System.Windows.Forms.NotifyIcon
$script:Tray.Icon = $script:IconOn
$script:Tray.Visible = $true
$script:Tray.Text = ('Starfire Lite ' + $script:AppVersion + $script:Tag + '  ON  (F8)')

function Update-Tray {
    $on = [bool]$script:Settings.enabled
    if ($script:TrayOn -ne $on) { if ($on) { $script:Tray.Icon = $script:IconOn } else { $script:Tray.Icon = $script:IconOff }; $script:TrayOn = $on }
    $label = if ($on) { 'ON' } else { 'OFF' }
    $t = "Starfire Lite $($script:AppVersion)$($script:Tag) $label  $($script:Status)"
    if ($t.Length -gt 63) { $t = $t.Substring(0, 63) }
    if ($script:Tray.Text -ne $t) { $script:Tray.Text = $t }
}

$menu = New-Object System.Windows.Forms.ContextMenuStrip
function Add-Item([string]$text, [scriptblock]$action) {
    $it = New-Object System.Windows.Forms.ToolStripMenuItem $text
    $it.Add_Click($action)
    [void]$menu.Items.Add($it)
    return $it
}
$script:ToggleItem = Add-Item 'Turn off   (F8)' { Toggle-Enabled }
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
# what the overlay translates: the game window, or the desktop (whole screen / an area) for anything else on the PC
function Set-Target([string]$mode) {
    $script:Settings.captureMode = $mode
    $script:LastHash = $null; $script:LastTextSig = $null
    try { $script:Tracks.Clear() } catch {}
    $script:LastBlocks = @(); $script:BCarry = $null
    if ($mode -ne 'game') { $script:HideOverlay = $false; $script:Status = 'desktop' }
    Save-Settings
    try { Update-GameState } catch {}
    try { $script:Overlay.Invalidate() } catch {}
    if ($mode -eq 'game') { Show-Notice 'Starfire: game overlay' } else { Show-Notice 'Starfire: desktop overlay' }
}
$script:TgtGame = Add-Item 'Translate: The Hidden Ones (game window)' { Set-Target 'game' }
$script:TgtDesk = Add-Item 'Translate: desktop (whole screen, any app)' { Set-Target 'fullscreen' }
$script:TgtArea = Add-Item 'Translate: desktop area you choose...' { Start-RegionSelect }
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$script:GlassItem = Add-Item 'Frosted-glass label background' { $script:Settings.glass = -not [bool]$script:Settings.glass; $script:LastTextSig = $null; $script:LastHash = $null; Save-Settings }
$script:CaptItem = Add-Item 'Show overlay in screenshots / recordings' {
    $script:Settings.excludeFromCapture = -not [bool]$script:Settings.excludeFromCapture
    Save-Settings; Apply-CaptureAffinity
}
$script:SmoothItem = Add-Item 'Smooth capture for streaming (no flicker)' {
    if ([string]$script:Settings.printCapture -eq 'off') { $script:Settings.printCapture = 'auto'; $script:PwNext = Get-Date }
    else { $script:Settings.printCapture = 'off'; $script:PwMode = 'off'; $script:PwPass = 0 }
    Save-Settings
}
$script:ExitItem = Add-Item 'Close Starfire when the game closes' { Toggle-ExitWithGame }
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
Add-Item 'Show status' {
    $tg = 'game window'; if ([string]$script:Settings.captureMode -eq 'fullscreen') { $tg = 'desktop (whole screen)' } elseif ([string]$script:Settings.captureMode -eq 'region') { $tg = 'desktop area' }
    $msg = "Starfire Lite $($script:AppVersion)$($script:Tag) is running.`r`n`r`nStatus: $($script:Status)`r`nTranslating: $tg`r`nLabels last scan: $(@($script:LastBlocks).Count)`r`n`r`nF8 turns the overlay on / off. Right-click this icon for options.`r`nLog: $script:LogPath"
    [System.Windows.Forms.MessageBox]::Show($msg, 'Starfire Lite')
}
Add-Item 'Install Chinese OCR packs (admin)...' { Install-OcrPacks }
Add-Item 'Open log folder' { Start-Process explorer.exe $script:DataDir }
Add-Item 'Quit' { Cleanup-And-Exit }
# tick marks always show the current settings (refreshed every time the menu opens)
$menu.Add_Opening({
    try {
        $m = [string]$script:Settings.captureMode
        $script:TgtGame.Checked = ($m -eq 'game'); $script:TgtDesk.Checked = ($m -eq 'fullscreen'); $script:TgtArea.Checked = ($m -eq 'region')
        $script:GlassItem.Checked = [bool]$script:Settings.glass
        $script:CaptItem.Checked = -not [bool]$script:Settings.excludeFromCapture
        $script:SmoothItem.Checked = ([string]$script:Settings.printCapture -ne 'off')
        $script:ExitItem.Checked = [bool]$script:Settings.exitWithGame
        $script:ExitItem.Enabled = ($m -eq 'game')
        $script:SmoothItem.Enabled = ($m -eq 'game')
    } catch {}
})
$script:Tray.ContextMenuStrip = $menu
$script:Tray.Add_MouseClick({
    param($s, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) { Toggle-Enabled }
})
$script:Tray.Add_DoubleClick({ Toggle-Enabled })

try {
    $script:Tray.BalloonTipTitle = 'Starfire Lite' + $script:Tag + ' is running'
    $script:Tray.BalloonTipText = 'F8 on/off. End closes.'
    $script:Tray.ShowBalloonTip(8000)
} catch {}

# Hide any console immediately so no terminal window appears
try {
    $con = [HSNative]::GetConsoleWindow()
    if ($con -ne [IntPtr]::Zero) { [HSNative]::ShowWindow($con, 0) | Out-Null }
} catch {}

Write-Log 'tray visible'

# ---------- overlay ----------
# Magenta color key, click-through, never a solid window. A layered bitmap
# that fails to apply leaves a black full-screen form, which is what blocked
# the desktop. Only the translation boxes are painted; everything else is
# the key color and disappears.
$script:Overlay = New-Object System.Windows.Forms.Form
$script:Overlay.FormBorderStyle = 'None'
$script:Overlay.ShowInTaskbar = $false
$script:Overlay.TopMost = $true
$script:Overlay.StartPosition = 'Manual'
$script:Overlay.AllowTransparency = $true
$script:Overlay.BackColor = [System.Drawing.Color]::Magenta
$script:Overlay.TransparencyKey = [System.Drawing.Color]::Magenta
$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
try { $script:Overlay.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic').SetValue($script:Overlay, $true, $null) } catch {}
$script:Overlay.Bounds = New-Object System.Drawing.Rectangle $vs.X, $vs.Y, $vs.Width, $vs.Height

$script:Overlay.Add_Paint({
    param($sender, $e)
    if ($script:HideOverlay) { return }
    try {
        $g = $e.Graphics
        try { $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::None } catch {}
        $drawList = @(); if ($script:Settings.enabled) { $drawList = @($script:LastBlocks) }
        foreach ($b in $drawList) {
            if ($null -eq $b) { continue }
            $text = ''
            try { $text = [string]$b.en } catch { continue }
            if ([string]::IsNullOrWhiteSpace($text)) {
                if ($script:Settings.debug) { $yp = New-Object System.Drawing.Pen ([System.Drawing.Color]::Gold), 1; $g.DrawRectangle($yp, [int]$b.x - $script:Overlay.Left, [int]$b.y - $script:Overlay.Top, [int]$b.w, [int]$b.h); $yp.Dispose() }
                continue
            }
            $bx = [int]$b.x - $script:Overlay.Left
            $by = [int]$b.y - $script:Overlay.Top
            $bw0 = [int]$b.w
            $bh0 = [int]$b.h
            if ($bw0 -lt 8) { $bw0 = 8 }
            if ($bh0 -lt 10) { $bh0 = 10 }
            if ($script:Settings.debug) { $rp = New-Object System.Drawing.Pen ([System.Drawing.Color]::Red), 1; $g.DrawRectangle($rp, $bx, $by, $bw0, $bh0); $rp.Dispose() }
            if ([int]$b.lw -le 0) {
                # translation arrived after the last layout pass
                try { Layout-Block $b $script:FrameBmp $script:FrameRect } catch {}
                if ([int]$b.lw -le 0) { continue }
            }
            $dx = [int]$b.lx - $script:Overlay.Left; $dy = [int]$b.ly - $script:Overlay.Top
            $dw = [int]$b.lw; $dh = [int]$b.lh
            $cr = $e.ClipRectangle
            if (($dx + $dw) -lt $cr.Left -or $dx -gt $cr.Right -or ($dy + $dh) -lt $cr.Top -or $dy -gt $cr.Bottom) { continue }
            $lf = Get-BoldFont ([single]$b.pt)
            $br = [int]$b.gR; $bbg = [int]$b.gG; $bbb = [int]$b.gB
            $lum = [int]$b.gLum
            if ($lum -lt 0) { $lum = [int](0.3 * $br + 0.59 * $bbg + 0.11 * $bbb) }
            if ($br -lt 0) { $br = 0 }; if ($br -gt 254) { $br = 254 }
            if ($bbg -lt 0) { $bbg = 0 }; if ($bbg -gt 254) { $bbg = 254 }
            if ($bbb -lt 0) { $bbb = 0 }; if ($bbb -gt 254) { $bbb = 254 }
            if ($br -gt 200 -and $bbb -gt 200 -and $bbg -lt 80) { $bbg = 80 }
            # text colour = colour of the original Chinese ink (when it contrasts with the glass), else black/white by brightness
            $useInk = $false; $ir = 0; $ig = 0; $ib = 0; $lumI = 0
            if ($b.iOk) {
                $ir = [int]$b.iR; $ig = [int]$b.iG; $ib = [int]$b.iB
                $lumI = [int](0.299 * $ir + 0.587 * $ig + 0.114 * $ib)
                if ([Math]::Abs($lumI - $lum) -ge 70) { $useInk = $true }
            }
            if ($useInk) {
                # keep the hue of the original text, but make every label stand out equally strongly
                $dlI = [Math]::Abs($lumI - $lum)
                if ($dlI -lt 150) {
                    if ($lumI -gt $lum) {
                        $kI = (150 - $dlI) / [Math]::Max(1.0, (255.0 - $lumI)); if ($kI -gt 1) { $kI = 1.0 }
                        $ir = [int]($ir + (255 - $ir) * $kI); $ig = [int]($ig + (255 - $ig) * $kI); $ib = [int]($ib + (255 - $ib) * $kI)
                    } else {
                        $kI = (150 - $dlI) / [Math]::Max(1.0, [double]$lumI); if ($kI -gt 1) { $kI = 1.0 }
                        $ir = [int]($ir * (1 - $kI)); $ig = [int]($ig * (1 - $kI)); $ib = [int]($ib * (1 - $kI))
                    }
                    $lumI = [int](0.299 * $ir + 0.587 * $ig + 0.114 * $ib)
                }
                $ink = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, $ir, $ig, $ib))
                if ($lumI -gt 128) { $shade = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(130, 0, 0, 0)) }
                else { $shade = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(100, 255, 255, 255)) }
            }
            elseif ($lum -gt 150) { $ink = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 16, 16, 18)); $shade = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(70, 255, 255, 255)) }
            else { $ink = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 250, 250, 250)); $shade = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(110, 0, 0, 0)) }
            if ($b.glass) {
                $g.DrawImageUnscaled($b.glass, $dx, $dy)
            } else {
                $wash = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, $br, $bbg, $bbb))
                $g.FillRectangle($wash, $dx, $dy, $dw, $dh); $wash.Dispose()
            }
            $sf = New-Object System.Drawing.StringFormat
            if ($b.nw) { $sf.FormatFlags = [System.Drawing.StringFormatFlags]([int][System.Drawing.StringFormatFlags]::NoWrap -bor [int][System.Drawing.StringFormatFlags]::NoClip); $sf.Trimming = [System.Drawing.StringTrimming]::None }
            else { $sf.FormatFlags = [System.Drawing.StringFormatFlags]::NoClip }
            if ($b.txt) { $text = [string]$b.txt }
            if (([int]$b.lines -le 1 -and -not $b.ext) -or $b.ctr) { $sf.Alignment = [System.Drawing.StringAlignment]::Center }
            $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
            $tr = New-Object System.Drawing.RectangleF ([single]($dx + 3)), ([single]($dy + 1)), ([single]($dw - 6)), ([single]($dh - 2))
            # very slight drop shadow straight below the text (1 px solid, 2 px faint)
            $trs = New-Object System.Drawing.RectangleF ([single]($dx + 3)), ([single]($dy + 2)), ([single]($dw - 6)), ([single]($dh - 2))
            $trs2 = New-Object System.Drawing.RectangleF ([single]($dx + 3)), ([single]($dy + 3)), ([single]($dw - 6)), ([single]($dh - 2))
            $shade2 = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb([int]($shade.Color.A * 0.4), $shade.Color.R, $shade.Color.G, $shade.Color.B))
            $g.DrawString($text, $lf, $shade2, $trs2, $sf)
            $g.DrawString($text, $lf, $shade, $trs, $sf)
            # the same weight for every label: the ink is drawn twice, one pixel apart (bold looks lighter on some colours / sizes)
            $trb = New-Object System.Drawing.RectangleF ([single]($dx + 4)), ([single]($dy + 1)), ([single]($dw - 6)), ([single]($dh - 2))
            $g.DrawString($text, $lf, $ink, $trb, $sf)
            $g.DrawString($text, $lf, $ink, $tr, $sf)
            $sf.Dispose(); $ink.Dispose(); $shade.Dispose(); $shade2.Dispose()
        }

        if ((Get-Date) -lt $script:NoticeUntil -and $script:Notice) {
            $nf = New-Object System.Drawing.Font 'Segoe UI', 20, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
            $nsz = $g.MeasureString($script:Notice, $nf)
            $nx = 40; $ny = 40
            if ($script:LastRect) { $nx = $script:LastRect.X - $script:Overlay.Left + [int](($script:LastRect.Width - $nsz.Width) / 2); $ny = $script:LastRect.Y - $script:Overlay.Top + 28 }
            $nb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 20, 20, 24))
            $nw = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))
            $g.FillRectangle($nb, $nx - 12, $ny - 6, [int]$nsz.Width + 24, [int]$nsz.Height + 12)
            $g.DrawString($script:Notice, $nf, $nw, [single]$nx, [single]$ny)
            $nf.Dispose(); $nb.Dispose(); $nw.Dispose()
        }

        if ($script:Settings.debug) {
            $gtxt = 'waiting for game'
            if ($script:Game) { $gtxt = 'attached, pid ' + $script:Game.pid }
            $hl = @(
                ('Starfire Lite v2 DEBUG   overlay: ' + $(if ($script:Settings.enabled) { 'ON' } else { 'OFF' })),
                ('game: ' + $gtxt + '   capture mode: ' + $script:Settings.captureMode),
                ('capture rect: ' + $script:LastRect),
                ('scan: ' + $script:LastScanMs + ' ms   status: ' + $script:Status),
                ('blocks: ' + @($script:LastBlocks).Count + '   pending: ' + $script:Pending.Count + '   dictionary hits: ' + $script:DictHits + '   cache: ' + $script:Cache.Count + '   tracks: ' + $script:Tracks.Count + '   moved: ' + $script:LastMoved),
                ('online translations ok: ' + [int]$script:TrOk + '   failed: ' + [int]$script:TrFail + '   ' + [string]$script:TrErr),
                ('Starfire Lite admin: ' + $script:IsAdmin + '   game elevated: ' + $script:GameElevated),
                ('hidden from recordings: ' + $script:ExcludeOk + '   red = OCR box, gold = awaiting translation')
            )
            $hx = 12; $hy = 40
            if ($script:LastRect) { $hx = $script:LastRect.X - $script:Overlay.Left + 12; $hy = $script:LastRect.Y - $script:Overlay.Top + 40 }
            $hf = New-Object System.Drawing.Font 'Consolas', 13, ([System.Drawing.FontStyle]::Regular), ([System.Drawing.GraphicsUnit]::Pixel)
            $hb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 10, 10, 14))
            $hw = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 120, 255, 140))
            $g.FillRectangle($hb, $hx - 6, $hy - 6, 620, ($hl.Count * 17) + 10)
            for ($i = 0; $i -lt $hl.Count; $i++) { $g.DrawString([string]$hl[$i], $hf, $hw, [single]$hx, [single]($hy + $i * 17)) }
            $hf.Dispose(); $hb.Dispose(); $hw.Dispose()
        }
    } catch { Write-Log "paint: $_" }
})

# Force the handle, set click-through, THEN show. Clicks pass through to
# whatever is underneath, including the tray.
$null = $script:Overlay.Handle
try {
    $ex = [HSNative]::GetWindowLong($script:Overlay.Handle, -20)
    $new = $ex -bor 0x20 -bor 0x80 -bor 0x08000000
    [HSNative]::SetWindowLong($script:Overlay.Handle, -20, $new) | Out-Null
} catch { Write-Log "exstyle: $_" }
$script:Overlay.Show()
$script:ExcludeOk = $false
function Apply-CaptureAffinity {
    # excludeFromCapture = true : overlay is invisible to screenshots/recordings (smoother OCR, no flicker)
    # excludeFromCapture = false: overlay shows in screenshots/recordings; it is hidden for a split second per OCR scan instead
    $script:ExcludeOk = $false
    try {
        if ($script:Settings.excludeFromCapture) { $script:ExcludeOk = [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0x11) }
        else { [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0) | Out-Null }
    } catch {}
    Write-Log "capture-exclude: $($script:ExcludeOk) (setting: $($script:Settings.excludeFromCapture))"
}
Apply-CaptureAffinity
# Smooth capture: read the game window's own picture with PrintWindow, so the overlay never has to be hidden from
# the screen capture (hiding it makes streaming / recording software see the overlay flicker). Validated against
# a real screen grab before it is used; falls back to the old method whenever it does not match.
$script:PrintOk = $false
$script:PwMode = 'off'; $script:PwPass = 0; $script:PwFails = 0; $script:PwNext = Get-Date
$script:LivePw = $null; $script:TopAt = [int64]-10000
try {
    Add-Type -ReferencedAssemblies System.Drawing -ErrorAction Stop -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class HSPrint {
    [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RC r);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RC r);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h, ref PT p);
    [StructLayout(LayoutKind.Sequential)] struct RC { public int L, T, R, B; }
    [StructLayout(LayoutKind.Sequential)] struct PT { public int X, Y; }
    static Bitmap full;
    // Draws the client area of the window into dst (which must have exactly the client size). False when that is not possible.
    public static bool Client(IntPtr hwnd, Bitmap dst) {
        RC wr, cr; PT p = new PT();
        if (!GetWindowRect(hwnd, out wr)) return false;
        if (!GetClientRect(hwnd, out cr)) return false;
        if (!ClientToScreen(hwnd, ref p)) return false;
        int ww = wr.R - wr.L, wh = wr.B - wr.T, cw = cr.R - cr.L, ch = cr.B - cr.T;
        if (ww < 64 || wh < 64 || cw != dst.Width || ch != dst.Height) return false;
        int ox = p.X - wr.L, oy = p.Y - wr.T;
        if (ox < 0 || oy < 0 || ox + cw > ww || oy + ch > wh) return false;
        if (full == null || full.Width != ww || full.Height != wh) {
            if (full != null) full.Dispose();
            full = new Bitmap(ww, wh, PixelFormat.Format32bppArgb);
        }
        bool ok;
        using (Graphics g = Graphics.FromImage(full)) {
            IntPtr dc = g.GetHdc();
            try { ok = PrintWindow(hwnd, dc, 2); } finally { g.ReleaseHdc(dc); }
        }
        if (!ok) return false;
        BitmapData sd = full.LockBits(new Rectangle(0, 0, ww, wh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        BitmapData dd = dst.LockBits(new Rectangle(0, 0, cw, ch), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try {
            byte[] row = new byte[cw * 4];
            for (int y = 0; y < ch; y++) {
                Marshal.Copy(new IntPtr(sd.Scan0.ToInt64() + (long)(y + oy) * sd.Stride + (long)ox * 4), row, 0, row.Length);
                for (int x = 3; x < row.Length; x += 4) row[x] = 255;
                Marshal.Copy(row, 0, new IntPtr(dd.Scan0.ToInt64() + (long)y * dd.Stride), row.Length);
            }
        } finally { full.UnlockBits(sd); dst.UnlockBits(dd); }
        return true;
    }
    // True when the picture is (almost) completely black.
    public static bool Dark(Bitmap b) {
        int W = b.Width, H = b.Height;
        BitmapData d = b.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int n = 0, dark = 0;
            for (int gy = 0; gy < 12; gy++) {
                int y = (gy * (H - 1)) / 11;
                for (int gx = 0; gx < 20; gx++) {
                    int x = (gx * (W - 1)) / 19;
                    int o = y * d.Stride + x * 4;
                    int m1 = Marshal.ReadByte(d.Scan0, o), m2 = Marshal.ReadByte(d.Scan0, o + 1), m3 = Marshal.ReadByte(d.Scan0, o + 2);
                    int mx = Math.Max(m1, Math.Max(m2, m3));
                    n++; if (mx < 6) dark++;
                }
            }
            return dark * 100 >= n * 98;
        } finally { b.UnlockBits(d); }
    }
    // Mean difference of two pictures on a grid of samples; -1 when the second one is too dark to judge.
    public static int Diff(Bitmap a, Bitmap b) {
        if (a == null || b == null || a.Width != b.Width || a.Height != b.Height) return 999;
        int W = a.Width, H = a.Height;
        BitmapData da = a.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        BitmapData db = b.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            long sum = 0, lumB = 0; int n = 0;
            for (int gy = 0; gy < 18; gy++) {
                int y = (gy * (H - 1)) / 17;
                for (int gx = 0; gx < 32; gx++) {
                    int x = (gx * (W - 1)) / 31;
                    int oa = y * da.Stride + x * 4, ob = y * db.Stride + x * 4;
                    int sd1 = 0, l1 = 0;
                    for (int c = 0; c < 3; c++) {
                        int va = Marshal.ReadByte(da.Scan0, oa + c), vb = Marshal.ReadByte(db.Scan0, ob + c);
                        sd1 += Math.Abs(va - vb); l1 += vb;
                    }
                    sum += sd1 / 3; lumB += l1 / 3; n++;
                }
            }
            if (lumB / n < 12) return -1;
            return (int)(sum / n);
        } finally { a.UnlockBits(da); b.UnlockBits(db); }
    }
}
'@
    $script:PrintOk = $true
} catch { Write-Log ('smooth capture unavailable: ' + $_.Exception.Message) }
# Windows window capture (the same method as OBS "Window Capture (Windows 10 1903 and up)"): reads the game window's own
# picture, so the overlay never has to be hidden for a scan (no flicker in recordings / streams)
$script:WgcOk = $false
try {
    Add-Type -ReferencedAssemblies System.Drawing -ErrorAction Stop -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class StarWgc {
    [DllImport("d3d11.dll")] static extern int D3D11CreateDevice(IntPtr adapter, int driverType, IntPtr software, uint flags, IntPtr levels, uint nLevels, uint sdk, out IntPtr device, out int level, out IntPtr ctx);
    [DllImport("d3d11.dll")] static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr dxgiDevice, out IntPtr graphicsDevice);
    [DllImport("combase.dll", CharSet = CharSet.Unicode)] static extern int WindowsCreateString(string s, int len, out IntPtr hs);
    [DllImport("combase.dll")] static extern int WindowsDeleteString(IntPtr hs);
    [DllImport("combase.dll")] static extern int RoGetActivationFactory(IntPtr cls, ref Guid iid, out IntPtr factory);
    [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr hwnd, int attr, out RC rect, int size);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out RC rect);
    [StructLayout(LayoutKind.Sequential)] struct RC { public int L, T, R, B; }
    [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IGraphicsCaptureItemInterop {
        [PreserveSig] int CreateForWindow(IntPtr window, ref Guid iid, out IntPtr result);
        [PreserveSig] int CreateForMonitor(IntPtr monitor, ref Guid iid, out IntPtr result);
    }
    public static object CreateDevice() {
        IntPtr dev, ctx; int lvl;
        int hr = D3D11CreateDevice(IntPtr.Zero, 1, IntPtr.Zero, 0x20, IntPtr.Zero, 0, 7, out dev, out lvl, out ctx);
        if (hr < 0) hr = D3D11CreateDevice(IntPtr.Zero, 5, IntPtr.Zero, 0x20, IntPtr.Zero, 0, 7, out dev, out lvl, out ctx);
        Marshal.ThrowExceptionForHR(hr);
        try {
            Guid iidDxgi = new Guid("54ec77fa-1377-44e6-8c32-88fd5f44c84c");
            IntPtr dxgi;
            Marshal.ThrowExceptionForHR(Marshal.QueryInterface(dev, ref iidDxgi, out dxgi));
            IntPtr insp;
            try { Marshal.ThrowExceptionForHR(CreateDirect3D11DeviceFromDXGIDevice(dxgi, out insp)); }
            finally { Marshal.Release(dxgi); }
            try { return Marshal.GetObjectForIUnknown(insp); } finally { Marshal.Release(insp); }
        } finally {
            Marshal.Release(dev);
            if (ctx != IntPtr.Zero) Marshal.Release(ctx);
        }
    }
    public static object CreateItem(IntPtr hwnd) {
        const string cls = "Windows.Graphics.Capture.GraphicsCaptureItem";
        IntPtr hs;
        Marshal.ThrowExceptionForHR(WindowsCreateString(cls, cls.Length, out hs));
        IntPtr fac;
        try {
            Guid iidInterop = typeof(IGraphicsCaptureItemInterop).GUID;
            Marshal.ThrowExceptionForHR(RoGetActivationFactory(hs, ref iidInterop, out fac));
        } finally { WindowsDeleteString(hs); }
        IGraphicsCaptureItemInterop interop;
        try { interop = (IGraphicsCaptureItemInterop)Marshal.GetObjectForIUnknown(fac); } finally { Marshal.Release(fac); }
        Guid iidItem = new Guid("79C3F95B-31F7-4EC2-A464-632EF5D30760");
        IntPtr item;
        Marshal.ThrowExceptionForHR(interop.CreateForWindow(hwnd, ref iidItem, out item));
        try { return Marshal.GetObjectForIUnknown(item); } finally { Marshal.Release(item); }
    }
    // frame pool / resize through reflection, so the D3D device (a plain COM object) is matched to its WinRT interface by the runtime
    const string FmtT = "Windows.Graphics.DirectX.DirectXPixelFormat, Windows.Graphics, ContentType=WindowsRuntime";
    const string PoolT = "Windows.Graphics.Capture.Direct3D11CaptureFramePool, Windows.Graphics, ContentType=WindowsRuntime";
    public static object CreatePool(object dev, object item) {
        Type poolT = Type.GetType(PoolT, true);
        object fmt = Enum.ToObject(Type.GetType(FmtT, true), 87);
        object size = item.GetType().GetProperty("Size").GetValue(item, null);
        return poolT.GetMethod("CreateFreeThreaded").Invoke(null, new object[] { dev, fmt, 2, size });
    }
    public static void Recreate(object pool, object dev, object size) {
        object fmt = Enum.ToObject(Type.GetType(FmtT, true), 87);
        pool.GetType().GetMethod("Recreate").Invoke(pool, new object[] { dev, fmt, 2, size });
    }
    // copies a captured frame into a SoftwareBitmap (returns the IAsyncOperation); done through reflection because
    // PowerShell cannot pass the frame's surface object to the method itself
    public static object CopyAsync(object frame, Type sbType) {
        object surface = frame.GetType().GetProperty("Surface").GetValue(frame, null);
        foreach (System.Reflection.MethodInfo m in sbType.GetMethods()) {
            if (m.Name == "CreateCopyFromSurfaceAsync" && m.GetParameters().Length == 1) return m.Invoke(null, new object[] { surface });
        }
        throw new InvalidOperationException("CreateCopyFromSurfaceAsync not found");
    }
    // top-left corner of the captured picture on screen (the visible window frame, without the invisible resize borders)
    public static Point FrameOrigin(IntPtr hwnd) {
        RC r;
        if (DwmGetWindowAttribute(hwnd, 9, out r, Marshal.SizeOf(typeof(RC))) == 0) return new Point(r.L, r.T);
        if (GetWindowRect(hwnd, out r)) return new Point(r.L, r.T);
        return new Point(0, 0);
    }
    // copies a dst-sized area at (sx, sy) of the captured BGRA picture into dst; false when it does not lie inside
    public static bool Blit(byte[] src, int sw, int sh, int sx, int sy, Bitmap dst) {
        int w = dst.Width, h = dst.Height;
        if (sx < 0 || sy < 0 || sx + w > sw || sy + h > sh || src.Length < sw * sh * 4) return false;
        BitmapData d = dst.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try {
            byte[] row = new byte[w * 4];
            for (int y = 0; y < h; y++) {
                Buffer.BlockCopy(src, ((sy + y) * sw + sx) * 4, row, 0, row.Length);
                for (int x = 3; x < row.Length; x += 4) row[x] = 255;
                Marshal.Copy(row, 0, new IntPtr(d.Scan0.ToInt64() + (long)y * d.Stride), row.Length);
            }
        } finally { dst.UnlockBits(d); }
        return true;
    }
}
'@
    $script:WgcOk = $true
} catch { Write-Log ('window capture unavailable: ' + $_.Exception.Message) }
try { [System.Diagnostics.Process]::GetCurrentProcess().PriorityClass = 'BelowNormal' } catch {}

# Poll the keyboard directly. RegisterHotKey and hooks never arrived while
# the game had focus. GetAsyncKeyState works regardless of which window is active.
Add-Type @"
using System.Runtime.InteropServices;
public class KeyPoll {
    [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
}
"@

Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class StarContrast {
    static byte[] buf, L, S, ob; static int[] iL, iS;
    public static bool Within1(string a, string b) {
        int la = a.Length, lb = b.Length;
        if (Math.Abs(la - lb) > 1) return false;
        int i = 0, j = 0, d = 0;
        while (i < la && j < lb) {
            if (a[i] == b[j]) { i++; j++; continue; }
            if (++d > 1) return false;
            if (la == lb) { i++; j++; }
            else if (la > lb) i++;
            else j++;
        }
        d += (la - i) + (lb - j);
        return d <= 1;
    }
    // Polarity-agnostic local contrast: dark-on-light, light-on-dark and coloured text all become dark ink on white.
    public static Bitmap Process(Bitmap src, int r, int gain) {
        int w = src.Width, h = src.Height;
        BitmapData bd = src.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = bd.Stride; if (buf == null || buf.Length != stride * h) buf = new byte[stride * h];
        Marshal.Copy(bd.Scan0, buf, 0, buf.Length); src.UnlockBits(bd);
        int W1 = w + 1;
        if (iL == null || iL.Length != W1 * (h + 1)) { iL = new int[W1 * (h + 1)]; iS = new int[W1 * (h + 1)]; L = new byte[w * h]; S = new byte[w * h]; }
        for (int y = 0; y < h; y++) {
            int rowL = 0, rowS = 0, o = y * stride;
            for (int x = 0; x < w; x++) {
                int b = buf[o + x * 4], g = buf[o + x * 4 + 1], rr = buf[o + x * 4 + 2];
                int lum = (299 * rr + 587 * g + 114 * b) / 1000;
                int mx = Math.Max(rr, Math.Max(g, b)), mn = Math.Min(rr, Math.Min(g, b));
                L[y * w + x] = (byte)lum; S[y * w + x] = (byte)(mx - mn);
                rowL += lum; rowS += (mx - mn);
                iL[(y + 1) * W1 + x + 1] = iL[y * W1 + x + 1] + rowL;
                iS[(y + 1) * W1 + x + 1] = iS[y * W1 + x + 1] + rowS;
            }
        }
        Bitmap res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData rd = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        int rs = rd.Stride; if (ob == null || ob.Length != rs * h) ob = new byte[rs * h];
        for (int y = 0; y < h; y++) {
            int y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
            for (int x = 0; x < w; x++) {
                int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1);
                int area = (x1 - x0) * (y1 - y0);
                int sl = iL[y1 * W1 + x1] - iL[y0 * W1 + x1] - iL[y1 * W1 + x0] + iL[y0 * W1 + x0];
                int ss = iS[y1 * W1 + x1] - iS[y0 * W1 + x1] - iS[y1 * W1 + x0] + iS[y0 * W1 + x0];
                int dl = Math.Abs(L[y * w + x] - sl / area);
                int ds = Math.Abs(S[y * w + x] - ss / area) * 9 / 10;
                int v = Math.Max(dl, ds) * gain;
                if (v > 255) v = 255;
                byte c = (byte)(255 - v);
                int po = y * rs + x * 4;
                ob[po] = c; ob[po + 1] = c; ob[po + 2] = c; ob[po + 3] = 255;
            }
        }
        Marshal.Copy(ob, 0, rd.Scan0, ob.Length); res.UnlockBits(rd);
        return res;
    }
}
public static class StarGlass {
    // Copies the rows of a locked sub-rectangle without reading past the end of the bitmap (the last row only has w pixels).
    static void CopyRows(BitmapData d, byte[] buf, int rows, int wpx) {
        int st = d.Stride;
        for (int j = 0; j < rows; j++) {
            int len = (j == rows - 1) ? wpx * 4 : st;
            if (len > st) len = st;
            if (j * st + len > buf.Length) len = buf.Length - j * st;
            if (len > 0) Marshal.Copy(new IntPtr(d.Scan0.ToInt64() + (long)j * st), buf, j * st, len);
        }
    }
    public static int TR, TG, TB, Lum;
    static void Blur(int[] a, int w, int h, int r) {
        int[] p = new int[Math.Max(w, h) + 1];
        for (int y = 0; y < h; y++) {
            int o = y * w; p[0] = 0;
            for (int x = 0; x < w; x++) p[x + 1] = p[x] + a[o + x];
            for (int x = 0; x < w; x++) {
                int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1);
                a[o + x] = (p[x1] - p[x0]) / (x1 - x0);
            }
        }
        for (int x = 0; x < w; x++) {
            p[0] = 0;
            for (int y = 0; y < h; y++) p[y + 1] = p[y] + a[y * w + x];
            for (int y = 0; y < h; y++) {
                int y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
                a[y * w + x] = (p[y1] - p[y0]) / (y1 - y0);
            }
        }
    }
    static int Median(int[] v, int n) { Array.Sort(v, 0, n); return v[n / 2]; }
    // Frosted-glass box for the region (x,y,w,h) of the captured frame: the Chinese strokes are suppressed,
    // the rest of the picture is blurred and mixed with the surrounding colour. Corners outside the
    // rounded rectangle are magenta (the overlay colour key).
    public static Bitmap Make(Bitmap frame, int x, int y, int w, int h, int r, int tintPct, int corner) {
        if (w < 4 || h < 4) throw new ArgumentException("size");
        int W = frame.Width, H = frame.Height;
        int rx0 = Math.Max(0, x - r), ry0 = Math.Max(0, y - r);
        int rx1 = Math.Min(W, x + w + r), ry1 = Math.Min(H, y + h + r);
        int rw = rx1 - rx0, rh = ry1 - ry0;
        int tR = 28, tG = 28, tB = 32;
        int[] cr = null, cg = null, cb = null; byte[] buf = null; int stride = 0;
        if (rw >= 2 && rh >= 2) {
            BitmapData bd = frame.LockBits(new Rectangle(rx0, ry0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            stride = bd.Stride; buf = new byte[stride * rh];
            CopyRows(bd, buf, rh, rw); frame.UnlockBits(bd);
            int cap = 2 * (w + h) * 2 + 8;
            int[] sr = new int[cap], sg = new int[cap], sb = new int[cap]; int n = 0;
            for (int band = 0; band < 2; band++) {
                for (int i = 0; i < w; i++) {
                    int[] ys = new int[] { y + band, y + h - 1 - band };
                    for (int k = 0; k < 2; k++) {
                        int px = x + i - rx0, py = ys[k] - ry0;
                        if (px < 0 || py < 0 || px >= rw || py >= rh || n >= cap) continue;
                        int o = py * stride + px * 4; sb[n] = buf[o]; sg[n] = buf[o + 1]; sr[n] = buf[o + 2]; n++;
                    }
                }
                for (int j = 0; j < h; j++) {
                    int[] xs = new int[] { x + band, x + w - 1 - band };
                    for (int k = 0; k < 2; k++) {
                        int px = xs[k] - rx0, py = y + j - ry0;
                        if (px < 0 || py < 0 || px >= rw || py >= rh || n >= cap) continue;
                        int o = py * stride + px * 4; sb[n] = buf[o]; sg[n] = buf[o + 1]; sr[n] = buf[o + 2]; n++;
                    }
                }
            }
            if (n > 0) { tR = Median(sr, n); tG = Median(sg, n); tB = Median(sb, n); }
            cr = new int[rw * rh]; cg = new int[rw * rh]; cb = new int[rw * rh];
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) {
                int o = j * stride + i * 4; int B = buf[o], G = buf[o + 1], R = buf[o + 2];
                int dR = R - tR, dG = G - tG, dB = B - tB;
                int dm = Math.Max(Math.Abs(dR), Math.Max(Math.Abs(dG), Math.Abs(dB)));
                double f = dm <= 28 ? 1.0 : (dm >= 100 ? 0.0 : (100.0 - dm) / 72.0);
                int q = j * rw + i;
                cr[q] = tR + (int)(dR * f); cg[q] = tG + (int)(dG * f); cb[q] = tB + (int)(dB * f);
            }
            for (int pass = 0; pass < 2; pass++) { Blur(cr, rw, rh, r); Blur(cg, rw, rh, r); Blur(cb, rw, rh, r); }
        }
        TR = tR; TG = tG; TB = tB;
        Bitmap res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData rd = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        int rs = rd.Stride; byte[] ob = new byte[rs * h];
        long lsum = 0; int lcnt = 0;
        int cn = Math.Max(0, Math.Min(corner, Math.Min(w, h) / 2));
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int po = j * rs + i * 4;
                bool outside = false;
                if (cn > 0) {
                    int cx = -1, cy = -1;
                    if (i < cn && j < cn) { cx = cn; cy = cn; }
                    else if (i >= w - cn && j < cn) { cx = w - cn - 1; cy = cn; }
                    else if (i < cn && j >= h - cn) { cx = cn; cy = h - cn - 1; }
                    else if (i >= w - cn && j >= h - cn) { cx = w - cn - 1; cy = h - cn - 1; }
                    if (cx >= 0) { int dx = i - cx, dy = j - cy; if (dx * dx + dy * dy > cn * cn) outside = true; }
                }
                if (outside) { ob[po] = 255; ob[po + 1] = 0; ob[po + 2] = 255; ob[po + 3] = 255; continue; }
                int R = tR, G = tG, B = tB;
                if (cr != null) {
                    int sx = x + i - rx0, sy = y + j - ry0;
                    if (sx >= 0 && sy >= 0 && sx < rw && sy < rh) {
                        int q = sy * rw + sx;
                        R = (cr[q] * (100 - tintPct) + tR * tintPct) / 100;
                        G = (cg[q] * (100 - tintPct) + tG * tintPct) / 100;
                        B = (cb[q] * (100 - tintPct) + tB * tintPct) / 100;
                    }
                }
                if (R < 0) R = 0; if (R > 254) R = 254; if (G < 0) G = 0; if (G > 254) G = 254; if (B < 0) B = 0; if (B > 254) B = 254;
                ob[po] = (byte)B; ob[po + 1] = (byte)G; ob[po + 2] = (byte)R; ob[po + 3] = 255;
                lsum += (299 * R + 587 * G + 114 * B) / 1000; lcnt++;
            }
        }
        Marshal.Copy(ob, 0, rd.Scan0, ob.Length); res.UnlockBits(rd);
        Lum = lcnt > 0 ? (int)(lsum / lcnt) : 40;
        return res;
    }
}
public static class StarRaw {
    static byte[] shared;      // reused for every OCR call (a fresh 18 MB array each time floods the large-object heap)
    // tightly packed BGRA bytes of a bitmap (lets OCR skip the BMP encode + decode round trip)
    public static byte[] Bytes(Bitmap b) {
        BitmapData d = b.LockBits(new Rectangle(0, 0, b.Width, b.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int row = b.Width * 4; if (shared == null || shared.Length != row * b.Height) shared = new byte[row * b.Height];
            byte[] r = shared;
            if (d.Stride == row) Marshal.Copy(d.Scan0, r, 0, r.Length);
            else for (int y = 0; y < b.Height; y++) Marshal.Copy(IntPtr.Add(d.Scan0, y * d.Stride), r, y * row, row);
            return r;
        } finally { b.UnlockBits(d); }
    }
}
public static class StarBytes {
    // I18NTranslation_*.bytes: 6 x uint32 header [offA,lenA,offB,lenB,offC,lenC]; A = key hashes, B = offsets into C, C = null separated UTF-8
    public static Dictionary<uint, string> Read(string path) {
        byte[] d = File.ReadAllBytes(path);
        int oa = (int)BitConverter.ToUInt32(d, 0), la = (int)BitConverter.ToUInt32(d, 4), ob = (int)BitConverter.ToUInt32(d, 8), oc = (int)BitConverter.ToUInt32(d, 16);
        int n = la / 4;
        Dictionary<uint, string> r = new Dictionary<uint, string>(n);
        for (int i = 0; i < n; i++) {
            uint key = BitConverter.ToUInt32(d, oa + 4 * i);
            int off = oc + (int)BitConverter.ToUInt32(d, ob + 4 * i);
            int e = Array.IndexOf(d, (byte)0, off); if (e < 0) e = d.Length;
            r[key] = Encoding.UTF8.GetString(d, off, e - off);
        }
        return r;
    }
}
"@ -ReferencedAssemblies System.Drawing
# light-text isolation: keeps only bright, nearly colourless pixels (white / light-grey game text) and turns them into black
# type on plain white - for buttons whose see-through backgrounds show a busy, colourful, moving picture behind the text
$script:MaskOk = $false
try {
    Add-Type -ReferencedAssemblies System.Drawing -ErrorAction Stop -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class StarMask {
    static byte[] inb, outb; static int[] lum, ii;
    // minLum: how bright a pixel must be (0-255); maxSat: how far apart R, G and B may be (colour); local: also brighter
    // than the average around it by this much (text stands out from its own background, large white areas do not)
    public static Bitmap LightText(Bitmap src, int minLum, int maxSat, int local) {
        int w = src.Width, h = src.Height;
        Rectangle r = new Rectangle(0, 0, w, h);
        BitmapData d = src.LockBits(r, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        int stride = d.Stride, n = stride * h;
        if (inb == null || inb.Length < n) inb = new byte[n];
        for (int y = 0; y < h; y++) Marshal.Copy(IntPtr.Add(d.Scan0, y * stride), inb, y * stride, w * 3);
        src.UnlockBits(d);
        // luminance + integral image for the local average (window 2*R+1)
        if (lum == null || lum.Length < w * h) lum = new int[w * h];
        if (ii == null || ii.Length < (w + 1) * (h + 1)) ii = new int[(w + 1) * (h + 1)];
        for (int x = 0; x <= w; x++) ii[x] = 0;
        for (int y = 0; y < h; y++) {
            int row = 0; int o = y * stride; ii[(y + 1) * (w + 1)] = 0;
            for (int x = 0; x < w; x++) {
                int b = inb[o + x * 3], g = inb[o + x * 3 + 1], rr = inb[o + x * 3 + 2];
                int l = (rr * 299 + g * 587 + b * 114) / 1000;
                lum[y * w + x] = l; row += l;
                ii[(y + 1) * (w + 1) + x + 1] = ii[y * (w + 1) + x + 1] + row;
            }
        }
        Bitmap res = new Bitmap(w, h, PixelFormat.Format24bppRgb);
        BitmapData od = res.LockBits(r, ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
        int os = od.Stride;
        if (outb == null || outb.Length < os * h) outb = new byte[os * h];
        int R = Math.Max(6, h / 60);
        for (int y = 0; y < h; y++) {
            int o = y * stride, oo = y * os;
            int y0 = Math.Max(0, y - R), y1 = Math.Min(h - 1, y + R);
            for (int x = 0; x < w; x++) {
                int b = inb[o + x * 3], g = inb[o + x * 3 + 1], rr = inb[o + x * 3 + 2];
                int mx = Math.Max(rr, Math.Max(g, b)), mn = Math.Min(rr, Math.Min(g, b));
                int l = lum[y * w + x];
                bool ink = l >= minLum && (mx - mn) <= maxSat;
                if (ink && local > 0) {
                    int x0 = Math.Max(0, x - R), x1 = Math.Min(w - 1, x + R);
                    int sum = ii[(y1 + 1) * (w + 1) + x1 + 1] - ii[y0 * (w + 1) + x1 + 1] - ii[(y1 + 1) * (w + 1) + x0] + ii[y0 * (w + 1) + x0];
                    int cnt = (x1 - x0 + 1) * (y1 - y0 + 1);
                    if (l - (sum / cnt) < local) ink = false;
                }
                byte v = ink ? (byte)0 : (byte)255;
                outb[oo + x * 3] = v; outb[oo + x * 3 + 1] = v; outb[oo + x * 3 + 2] = v;
            }
        }
        for (int y = 0; y < h; y++) Marshal.Copy(outb, y * os, IntPtr.Add(od.Scan0, y * os), w * 3);
        res.UnlockBits(od);
        return res;
    }
    // How much light text ink a box holds, in 1/1000 of its pixels: bright, nearly colourless pixels clearly brighter than
    // the box's own average. White type keeps this value while a moving picture behind it changes; -1 when unknown.
    public static int InkPermille(Bitmap f, int x, int y, int w, int h, int minLum, int maxSat, int above) {
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(f.Width, x + w), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 6 || rh < 6) return -1;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            long tot = 0;
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; tot += (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
            int mean = (int)(tot / (rw * rh));
            int ink = 0;
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) {
                int o = j * stride + i * 3;
                int bb = b[o], g = b[o + 1], r = b[o + 2];
                int l = (r * 299 + g * 587 + bb * 114) / 1000;
                int mx = Math.Max(r, Math.Max(g, bb)), mn = Math.Min(r, Math.Min(g, bb));
                if (l >= minLum && (mx - mn) <= maxSat && l - mean >= above) ink++;
            }
            return (int)((ink * 1000L) / (rw * rh));
        } finally { f.UnlockBits(d); }
    }
    // Distance (pixels, from the text box edge) to the nearest separate compact bright shape (an icon, check box, badge)
    // on one side of the box (dir -1 = left, +1 = right), or maxDist when there is none. Strokes touching the box
    // (the OCR box is often a little tight) count as the text itself; the shape must start after a gap of 3+ clear columns.
    public static int NeighborGap(Bitmap f, int x, int y, int w, int h, int maxDist, int dir) {
        int x0 = dir < 0 ? Math.Max(0, x - maxDist) : Math.Min(f.Width, x + w);
        int x1 = dir < 0 ? Math.Max(0, x) : Math.Min(f.Width, x + w + maxDist);
        int y0 = Math.Max(0, y), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 8) return maxDist;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        int[] lum = new int[rw * rh];
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; lum[j * rw + i] = (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
        } finally { f.UnlockBits(d); }
        long tot = 0; for (int q = 0; q < lum.Length; q++) tot += lum[q];
        int mean = (int)(tot / lum.Length);
        int need = Math.Max(2, rh / 8);
        bool[] on = new bool[rw];
        for (int i = 0; i < rw; i++) {
            int c = 0;
            for (int j = 0; j < rh; j++) { int l = lum[j * rw + i]; if (l >= 95 && l - mean >= 45) c++; }
            on[i] = c >= need;
        }
        int k = 0;
        while (k < rw && on[dir < 0 ? rw - 1 - k : k]) k++;          // strokes touching the text box
        int gap = 0;
        for (; k < rw; k++) {
            bool o = on[dir < 0 ? rw - 1 - k : k];
            if (!o) { gap++; continue; }
            if (gap >= 3) {
                int run = 0, g2 = 0;
                for (int m = k; m < rw && g2 <= 2; m++) { if (on[dir < 0 ? rw - 1 - m : m]) { run = m - k + 1; g2 = 0; } else g2++; }
                if (run >= 3 && run <= 3 * rh) return k;
            }
            gap = 0;
            int m2 = k; while (m2 < rw && on[dir < 0 ? rw - 1 - m2 : m2]) m2++; k = m2 - 1;
        }
        return maxDist;
    }
    // The boxes the extra (light-text) pass reports can sit 10-30 px off the real text (the log showed whole rows of buttons
    // "moving" by the same amounts). Finds the shift (dx, dy) within +-range that puts the box on the light ink: ink inside
    // the box minus ink in a ring just outside it (a box half on a neighbouring icon scores worse than one on the text).
    // Returns {0, 0} when there is no clear improvement or too little light ink to judge.
    public static int[] BestShift(Bitmap f, int x, int y, int w, int h, int range, int step) {
        int[] none = new int[] { 0, 0 };
        int ring = Math.Max(3, h / 4);
        int x0 = Math.Max(0, x - range - ring), y0 = Math.Max(0, y - range - ring);
        int x1 = Math.Min(f.Width, x + w + range + ring), y1 = Math.Min(f.Height, y + h + range + ring);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < w + 4 || rh < h + 4 || w < 12 || h < 8) return none;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        int[] lum = new int[rw * rh]; int[] sat = new int[rw * rh];
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) {
                int o = j * stride + i * 3; int bb = b[o], g = b[o + 1], r = b[o + 2];
                lum[j * rw + i] = (r * 299 + g * 587 + bb * 114) / 1000;
                sat[j * rw + i] = Math.Max(r, Math.Max(g, bb)) - Math.Min(r, Math.Min(g, bb));
            }
        } finally { f.UnlockBits(d); }
        long tot = 0; for (int q = 0; q < lum.Length; q++) tot += lum[q];
        int mean = (int)(tot / lum.Length);
        int thr = Math.Max(150, mean + 28);
        int[] ii = new int[(rw + 1) * (rh + 1)];
        for (int j = 0; j < rh; j++) {
            int row = 0;
            for (int i = 0; i < rw; i++) {
                if (lum[j * rw + i] >= thr && sat[j * rw + i] <= 55) row++;
                ii[(j + 1) * (rw + 1) + i + 1] = ii[j * (rw + 1) + i + 1] + row;
            }
        }
        Func<int, int, int, int, int> cnt = (ax, ay, aw, ah) => {
            int ax0 = Math.Max(0, ax), ay0 = Math.Max(0, ay), ax1 = Math.Min(rw, ax + aw), ay1 = Math.Min(rh, ay + ah);
            if (ax1 <= ax0 || ay1 <= ay0) return 0;
            return ii[ay1 * (rw + 1) + ax1] - ii[ay0 * (rw + 1) + ax1] - ii[ay1 * (rw + 1) + ax0] + ii[ay0 * (rw + 1) + ax0];
        };
        int bx = x - x0, by = y - y0;
        Func<int, int, int> score = (dx, dy) => {
            int inB = cnt(bx + dx, by + dy, w, h);
            int outB = cnt(bx + dx - ring, by + dy - ring, w + 2 * ring, h + 2 * ring) - inB;
            return inB - outB;
        };
        int s0 = score(0, 0), best = s0, bdx = 0, bdy = 0;
        // text drifts by a fraction of its own size, not by a whole line or half its width; and a place that is mostly bright
        // (a sunlit wall, a window, a plain highlight) is no text: those were what the box used to jump onto
        int ry = Math.Min(range, Math.Max(4, (int)(0.7 * h))), rx = Math.Min(range, Math.Max(4, w / 2));
        int maxInk = (int)(0.55 * w * h);
        for (int dy = -ry; dy <= ry; dy += step) for (int dx = -rx; dx <= rx; dx += step) {
            if (dx == 0 && dy == 0) continue;
            if (cnt(bx + dx, by + dy, w, h) > maxInk) continue;
            int sc = score(dx, dy);
            if (sc > best || (sc == best && (Math.Abs(dx) + Math.Abs(dy)) < (Math.Abs(bdx) + Math.Abs(bdy)) && (bdx != 0 || bdy != 0))) { best = sc; bdx = dx; bdy = dy; }
        }
        if (best < 0.04 * w * h) return none;
        if (best < s0 * 1.3 + 8) return none;
        return new int[] { bdx, bdy };
    }
    // Bright column segments inside a box: runs of columns holding light pixels, runs closer than gapMin are merged.
    // Returns {start0, end0, start1, end1, ...} relative to x. Used to tell an icon inside an OCR box from its text.
    public static int[] ColumnSegs(Bitmap f, int x, int y, int w, int h, int gapMin) {
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(f.Width, x + w), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 8) return new int[0];
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        int[] lum = new int[rw * rh];
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; lum[j * rw + i] = (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
        } finally { f.UnlockBits(d); }
        long tot = 0; for (int q = 0; q < lum.Length; q++) tot += lum[q];
        int mean = (int)(tot / lum.Length);
        int need = Math.Max(2, rh / 8);
        System.Collections.Generic.List<int> res = new System.Collections.Generic.List<int>();
        int s0 = -1, last = -1;
        for (int i = 0; i < rw; i++) {
            int c = 0;
            for (int j = 0; j < rh; j++) { int l = lum[j * rw + i]; if (l >= 90 && l - mean >= 40) c++; }
            if (c >= need) {
                if (s0 < 0) s0 = i;
                else if (i - last - 1 >= gapMin) { res.Add(s0 + (x0 - x)); res.Add(last + (x0 - x)); s0 = i; }
                last = i;
            }
        }
        if (s0 >= 0) { res.Add(s0 + (x0 - x)); res.Add(last + (x0 - x)); }
        return res.ToArray();
    }
    // How far bright ink (glow, calligraphy, outline) reaches just outside a box: returns {top, bottom, left, right} in pixels,
    // each at most 'margin'. A side grows while the next row / column outside still holds bright pixels (one empty line is bridged).
    public static int[] InkExtent(Bitmap f, int x, int y, int w, int h, int margin, int minLum, int above) {
        int[] res = new int[4];
        int x0 = Math.Max(0, x - margin), y0 = Math.Max(0, y - margin), x1 = Math.Min(f.Width, x + w + margin), y1 = Math.Min(f.Height, y + h + margin);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 6 || w < 4 || h < 4) return res;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            long tot = 0;
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; tot += (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
            int mean = (int)(tot / (rw * rh));
            int bx = x - x0, by = y - y0;
            for (int side = 0; side < 4; side++) {
                int run = 0, gap = 0;
                for (int k = 1; k <= margin; k++) {
                    int cnt = 0, len = (side < 2) ? w : h;
                    for (int t = 0; t < len; t++) {
                        int px, py;
                        if (side == 0) { px = bx + t; py = by - k; }
                        else if (side == 1) { px = bx + t; py = by + h - 1 + k; }
                        else if (side == 2) { px = bx - k; py = by + t; }
                        else { px = bx + w - 1 + k; py = by + t; }
                        if (px < 0 || py < 0 || px >= rw || py >= rh) continue;
                        int o = py * stride + px * 3;
                        int l = (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000;
                        if (l >= minLum && l - mean >= above) cnt++;
                    }
                    if (cnt >= Math.Max(2, len / 30)) { run = k; gap = 0; }
                    else { gap++; if (gap > 1) break; }
                }
                res[side] = run;
            }
            return res;
        } finally { f.UnlockBits(d); }
    }
    // A character the OCR box left out: bright, glyph-sized ink right beside the box (gap at most rh/3, tall like text, short of
    // maxExt wide). Returns {extend left, extend right} in pixels (0 = nothing). Long runs of ink (frames, art) are no glyph: 0.
    public static int[] GlyphReach(Bitmap f, int x, int y, int w, int h, int maxExt, int firstGap) {
        int[] res = new int[2];
        int x0 = Math.Max(0, x - maxExt - 2), x1 = Math.Min(f.Width, x + w + maxExt + 2);
        int y0 = Math.Max(0, y), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 8 || w < 4) return res;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            long tot = 0;
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; tot += (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
            int mean = (int)(tot / (rw * rh));
            int[] cc = new int[rw]; int[] ct = new int[rw]; int[] cb = new int[rw];
            for (int i = 0; i < rw; i++) {
                ct[i] = rh; cb[i] = -1;
                for (int j = 0; j < rh; j++) {
                    int o = j * stride + i * 3;
                    int l = (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000;
                    if (l >= 120 && l - mean >= 35) { cc[i]++; if (j < ct[i]) ct[i] = j; cb[i] = j; }
                }
            }
            for (int side = 0; side < 2; side++) {
                int dir = (side == 0) ? -1 : 1;
                int edge = (side == 0) ? (x - x0) : (x + w - 1 - x0);
                int gap = 0, last = 0, top = rh, bot = -1; bool any = false, endInk = false;
                for (int k = 1; k <= maxExt; k++) {
                    int px = edge + dir * k;
                    if (px < 0 || px >= rw) break;
                    if (cc[px] >= 2) { last = k; gap = 0; any = true; if (ct[px] < top) top = ct[px]; if (cb[px] > bot) bot = cb[px]; if (k == maxExt) endInk = true; }
                    else { gap++; int lim = any ? Math.Max(2, rh / 6) : Math.Max(3, firstGap); if (gap > lim) break; }
                }
                if (!any || endInk) continue;
                if ((bot - top + 1) < 0.7 * rh) continue;
                // one character, not a fill: not wider than a text height, not a hairline, and with gaps in it like strokes have
                // (a button face, a glossy highlight or a glow is mostly bright)
                long inkSum = 0; int cols = 0;
                for (int k = 1; k <= last; k++) { int px = edge + dir * k; if (px < 0 || px >= rw) break; inkSum += cc[px]; cols++; }
                if (cols < 3) continue;
                if (last > (int)(1.3 * rh) + Math.Max(3, firstGap)) continue;
                double dens = (double)inkSum / ((double)cols * rh);
                if (dens < 0.06 || dens > 0.45) continue;
                res[side] = last + 1;
            }
            return res;
        } finally { f.UnlockBits(d); }
    }
    // Where the light ink sits in a box: 8 x 2 cells, ink per cell in 1/1000. Different text (another menu entry slid into
    // the same spot) puts its ink in different cells, so this tells "same text still here" from "other text here now".
    public static int[] InkGrid(Bitmap f, int x, int y, int w, int h, int minLum, int maxSat, int above) {
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(f.Width, x + w), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 6) return new int[0];
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        try {
            int stride = d.Stride;
            byte[] b = new byte[stride * rh];
            for (int j = 0; j < rh; j++) Marshal.Copy(IntPtr.Add(d.Scan0, j * stride), b, j * stride, rw * 3);
            long tot = 0;
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 3; tot += (b[o + 2] * 299 + b[o + 1] * 587 + b[o] * 114) / 1000; }
            int mean = (int)(tot / (rw * rh));
            int[] cnt = new int[16]; int[] all = new int[16];
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) {
                int o = j * stride + i * 3;
                int bb = b[o], g = b[o + 1], r = b[o + 2];
                int l = (r * 299 + g * 587 + bb * 114) / 1000;
                int mx = Math.Max(r, Math.Max(g, bb)), mn = Math.Min(r, Math.Min(g, bb));
                int c = ((j * 2) / rh) * 8 + (i * 8) / rw;
                all[c]++;
                if (l >= minLum && (mx - mn) <= maxSat && l - mean >= above) cnt[c]++;
            }
            int[] res = new int[16];
            for (int q = 0; q < 16; q++) res[q] = all[q] > 0 ? (int)((cnt[q] * 1000L) / all[q]) : 0;
            return res;
        } finally { f.UnlockBits(d); }
    }
}
'@
    $script:MaskOk = $true
} catch { Write-Log ('light-text pass unavailable: ' + $_.Exception.Message) }

$script:Glass2Ok = $false
try {
    $glass2Src = @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class StarGlass2 {
    // Copies the rows of a locked sub-rectangle without reading past the end of the bitmap (the last row only has w pixels).
    static void CopyRows(BitmapData d, byte[] buf, int rows, int wpx) {
        int st = d.Stride;
        for (int j = 0; j < rows; j++) {
            int len = (j == rows - 1) ? wpx * 4 : st;
            if (len > st) len = st;
            if (j * st + len > buf.Length) len = buf.Length - j * st;
            if (len > 0) Marshal.Copy(new IntPtr(d.Scan0.ToInt64() + (long)j * st), buf, j * st, len);
        }
    }
    public static int TR, TG, TB, Lum, IR, IG, IB;
    public static bool InkOk;
    static void Blur(int[] a, int w, int h, int r) {
        int[] p = new int[Math.Max(w, h) + 1];
        for (int y = 0; y < h; y++) {
            int o = y * w; p[0] = 0;
            for (int x = 0; x < w; x++) p[x + 1] = p[x] + a[o + x];
            for (int x = 0; x < w; x++) {
                int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1);
                a[o + x] = (p[x1] - p[x0]) / (x1 - x0);
            }
        }
        for (int x = 0; x < w; x++) {
            p[0] = 0;
            for (int y = 0; y < h; y++) p[y + 1] = p[y] + a[y * w + x];
            for (int y = 0; y < h; y++) {
                int y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
                a[y * w + x] = (p[y1] - p[y0]) / (y1 - y0);
            }
        }
    }
    static int Median5(int[] a, int i) {
        int n = a.Length;
        int lo = Math.Max(0, i - 2), hi = Math.Min(n - 1, i + 2);
        int cnt = hi - lo + 1;
        int[] t = new int[5];
        for (int k = 0; k < cnt; k++) t[k] = a[lo + k];
        Array.Sort(t, 0, cnt);
        return t[cnt / 2];
    }
    static int[] Smooth(int[] a) {
        int n = a.Length;
        int[] m = new int[n];
        for (int i = 0; i < n; i++) m[i] = Median5(a, i);
        int[] o = new int[n];
        for (int i = 0; i < n; i++) {
            int lo = Math.Max(0, i - 1), hi = Math.Min(n - 1, i + 1);
            int s = 0;
            for (int k = lo; k <= hi; k++) s += m[k];
            o[i] = s / (hi - lo + 1);
        }
        return o;
    }
    static readonly char[] HexC = "0123456789ABCDEF".ToCharArray();
    // Frame fingerprint (about 128 columns of samples, 4 bits per channel) and a change test that is also
    // sensitive to the lower 40% of the screen where subtitles appear.
    public static string Hash(Bitmap b) {
        int W = b.Width, H = b.Height;
        int step = Math.Max(6, W / 128);
        int gw = (W + step - 1) / step, gh = (H + step - 1) / step;
        char[] c = new char[gw * gh * 3];
        BitmapData d = b.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int k = 0;
            for (int gy = 0; gy < gh; gy++) {
                int y = Math.Min(H - 1, gy * step + step / 2);
                for (int gx = 0; gx < gw; gx++) {
                    int x = Math.Min(W - 1, gx * step + step / 2);
                    int o = y * d.Stride + x * 4;
                    c[k++] = HexC[Marshal.ReadByte(d.Scan0, o + 2) >> 4];
                    c[k++] = HexC[Marshal.ReadByte(d.Scan0, o + 1) >> 4];
                    c[k++] = HexC[Marshal.ReadByte(d.Scan0, o) >> 4];
                }
            }
            return gw.ToString() + "," + gh.ToString() + ";" + new string(c);
        } finally { b.UnlockBits(d); }
    }
    public static bool Changed(string a, string b) {
        if (a == null || b == null || a.Length != b.Length) return true;
        int p = a.IndexOf(';');
        if (p < 0) return true;
        string[] dims = a.Substring(0, p).Split(',');
        int gw = int.Parse(dims[0]), gh = int.Parse(dims[1]);
        int baseO = p + 1, coarse = 0, band = 0, bandStart = (gh * 60) / 100;
        for (int gy = 0; gy < gh; gy++) {
            for (int gx = 0; gx < gw; gx++) {
                int o = baseO + (gy * gw + gx) * 3;
                if (a[o] != b[o] || a[o + 1] != b[o + 1] || a[o + 2] != b[o + 2]) {
                    if ((gy & 3) == 0 && (gx & 3) == 0) coarse++;
                    if (gy >= bandStart) band++;
                }
            }
        }
        return coarse >= 8 || band >= 16;
    }
    // The OCR rectangle is often a little tighter than the real strokes. Looks just outside each edge of the box for
    // text-coloured pixels (different from the surrounding background) and returns how far to grow left, top, right, bottom.
    public static int[] InkBounds(Bitmap f, int x, int y, int w, int h, int mx, int my) {
        int[] res = new int[] { 0, 0, 0, 0 };
        int W = f.Width, H = f.Height;
        int x0 = Math.Max(0, x - mx), y0 = Math.Max(0, y - my), x1 = Math.Min(W, x + w + mx), y1 = Math.Min(H, y + h + my);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 6 || rh < 6 || w < 2 || h < 2) return res;
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = d.Stride;
        byte[] buf = new byte[stride * rh];
        CopyRows(d, buf, rh, rw);
        f.UnlockBits(d);
        int nr = 2 * rw + 2 * (rh - 2), k = 0;
        int[] rr = new int[nr], rg = new int[nr], rb = new int[nr];
        for (int i = 0; i < rw; i++) {
            int o = i * 4;
            rb[k] = buf[o]; rg[k] = buf[o + 1]; rr[k] = buf[o + 2]; k++;
            o = (rh - 1) * stride + i * 4;
            rb[k] = buf[o]; rg[k] = buf[o + 1]; rr[k] = buf[o + 2]; k++;
        }
        for (int j = 1; j < rh - 1; j++) {
            int o = j * stride;
            rb[k] = buf[o]; rg[k] = buf[o + 1]; rr[k] = buf[o + 2]; k++;
            o = j * stride + (rw - 1) * 4;
            rb[k] = buf[o]; rg[k] = buf[o + 1]; rr[k] = buf[o + 2]; k++;
        }
        Array.Sort(rr); Array.Sort(rg); Array.Sort(rb);
        int mr = rr[nr / 2], mg = rg[nr / 2], mb = rb[nr / 2];
        bool[] ink = new bool[rw * rh];
        int cnt = 0;
        for (int j = 0; j < rh; j++) {
            for (int i = 0; i < rw; i++) {
                int o = j * stride + i * 4;
                int dd = Math.Max(Math.Abs(buf[o + 2] - mr), Math.Max(Math.Abs(buf[o + 1] - mg), Math.Abs(buf[o] - mb)));
                if (dd > 28) { ink[j * rw + i] = true; cnt++; }
            }
        }
        if (cnt * 100 > rw * rh * 55) return res;
        int bl = x - x0, bt = y - y0, br = bl + w, bb = bt + h;
        int gtol = Math.Max(2, Math.Min(6, h / 5));   // gap between glyphs that still counts as the same text
        for (int iter = 0; iter < mx + 2; iter++) {
            int moved = 0;
            for (int step = 1; step <= gtol; step++) {
                int c = bl - step; if (c < 0) break;
                bool has = false;
                for (int j = Math.Max(0, bt); j < Math.Min(rh, bb); j++) { if (ink[j * rw + c]) { has = true; break; } }
                if (has) { moved = step; break; }
            }
            if (moved == 0) break;
            bl -= moved;
        }
        for (int iter = 0; iter < mx + 2; iter++) {
            int moved = 0;
            for (int step = 1; step <= gtol; step++) {
                int c = br - 1 + step; if (c > rw - 1) break;
                bool has = false;
                for (int j = Math.Max(0, bt); j < Math.Min(rh, bb); j++) { if (ink[j * rw + c]) { has = true; break; } }
                if (has) { moved = step; break; }
            }
            if (moved == 0) break;
            br += moved;
        }
        for (int iter = 0; iter < my + 2; iter++) {
            int moved = 0;
            for (int step = 1; step <= 2; step++) {
                int rwi = bt - step; if (rwi < 0) break;
                bool has = false;
                for (int i = Math.Max(0, bl); i < Math.Min(rw, br); i++) { if (ink[rwi * rw + i]) { has = true; break; } }
                if (has) { moved = step; break; }
            }
            if (moved == 0) break;
            bt -= moved;
        }
        for (int iter = 0; iter < my + 2; iter++) {
            int moved = 0;
            for (int step = 1; step <= 2; step++) {
                int rwi = bb - 1 + step; if (rwi > rh - 1) break;
                bool has = false;
                for (int i = Math.Max(0, bl); i < Math.Min(rw, br); i++) { if (ink[rwi * rw + i]) { has = true; break; } }
                if (has) { moved = step; break; }
            }
            if (moved == 0) break;
            bb += moved;
        }
        res[0] = (x - x0) - bl; res[1] = (y - y0) - bt; res[2] = br - (x - x0 + w); res[3] = bb - (y - y0 + h);
        for (int q = 0; q < 4; q++) { if (res[q] < 0) res[q] = 0; }
        return res;
    }
    // How many pixels to the right of the Chinese text box (frame pixels) are free of strong vertical edges
    // (button borders, check boxes, panel edges). Used to stop a label from stretching across such shapes.
    public static int EdgeRoom(Bitmap f, int x, int y, int w, int h, int maxExtra) {
        int W = f.Width, H = f.Height;
        int y0 = Math.Max(0, y), y1 = Math.Min(H, y + h);
        int xs = Math.Max(2, x + w + 2), xe = Math.Min(W - 1, x + w + maxExtra);
        if (y1 - y0 < 3 || xs >= xe) return maxExtra;
        BitmapData d = f.LockBits(new Rectangle(0, y0, W, y1 - y0), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int rows = y1 - y0;
            for (int cx = xs; cx <= xe; cx++) {
                int hits = 0;
                for (int j = 0; j < rows; j++) {
                    int o1 = j * d.Stride + cx * 4, o0 = j * d.Stride + (cx - 2) * 4;
                    int dm = 0;
                    for (int c = 0; c < 3; c++) {
                        int dd = Math.Abs(Marshal.ReadByte(d.Scan0, o1 + c) - Marshal.ReadByte(d.Scan0, o0 + c));
                        if (dd > dm) dm = dd;
                    }
                    if (dm > 40) hits++;
                }
                if (hits * 100 >= rows * 60) return Math.Max(0, cx - 2 - (x + w) - 2);
            }
            return maxExtra;
        } finally { f.UnlockBits(d); }
    }
    static int Mean(int[] I, int W1, int w, int h, int x, int y, int r) {
        int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1), y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
        int area = (x1 - x0) * (y1 - y0);
        return (I[y1 * W1 + x1] - I[y0 * W1 + x1] - I[y1 * W1 + x0] + I[y0 * W1 + x0]) / area;
    }
    // Band-pass image for the second OCR pass: keeps strokes of text, removes smooth gradients and large patterns,
    // works on brightness and colour so text that only differs in hue still shows up. Dark ink on white.
    static byte[] bBuf, bOb; static int[] bIL, bIS;      // buffers reused between passes (about 75 MB of garbage per call otherwise)
    public static Bitmap Band(Bitmap src, int rIn, int rA, int rB, int gain) {
        int w = src.Width, h = src.Height;
        BitmapData d = src.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = d.Stride;
        if (bBuf == null || bBuf.Length != stride * h) bBuf = new byte[stride * h];
        byte[] buf = bBuf;
        Marshal.Copy(d.Scan0, buf, 0, buf.Length);
        src.UnlockBits(d);
        int W1 = w + 1;
        if (bIL == null || bIL.Length != W1 * (h + 1)) { bIL = new int[W1 * (h + 1)]; bIS = new int[W1 * (h + 1)]; }
        int[] iL = bIL, iS = bIS;
        for (int y = 0; y < h; y++) {
            int rowL = 0, rowS = 0;
            for (int x = 0; x < w; x++) {
                int o = y * stride + x * 4;
                int bl = buf[o], gr = buf[o + 1], rd0 = buf[o + 2];
                int lum = (299 * rd0 + 587 * gr + 114 * bl) / 1000;
                int mx = Math.Max(rd0, Math.Max(gr, bl)), mn = Math.Min(rd0, Math.Min(gr, bl));
                rowL += lum; rowS += (mx - mn);
                iL[(y + 1) * W1 + x + 1] = iL[y * W1 + x + 1] + rowL;
                iS[(y + 1) * W1 + x + 1] = iS[y * W1 + x + 1] + rowS;
            }
        }
        Bitmap res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData rd = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        int rs = rd.Stride;
        if (bOb == null || bOb.Length != rs * h) bOb = new byte[rs * h];
        byte[] ob = bOb;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int mi = Mean(iL, W1, w, h, x, y, rIn), si = Mean(iS, W1, w, h, x, y, rIn);
                int dl1 = Math.Abs(mi - Mean(iL, W1, w, h, x, y, rA));
                int ds1 = Math.Abs(si - Mean(iS, W1, w, h, x, y, rA)) * 9 / 10;
                int dl2 = Math.Abs(mi - Mean(iL, W1, w, h, x, y, rB));
                int dmax = Math.Max(Math.Max(dl1, ds1), dl2);
                int v = (dmax - 10) * gain;
                if (v < 0) v = 0; if (v > 255) v = 255;
                byte cc = (byte)(255 - v);
                int po = y * rs + x * 4;
                ob[po] = cc; ob[po + 1] = cc; ob[po + 2] = cc; ob[po + 3] = 255;
            }
        }
        Marshal.Copy(ob, 0, rd.Scan0, ob.Length);
        res.UnlockBits(rd);
        return res;
    }
    // Coarse picture of a text area: mean brightness of up to 12 x 4 cells. Robust against 1 px shifts; used to notice
    // that the text under a label has changed or gone.
    // Signature of the TEXT in an area: how much fine detail (stroke edges) each of 16 x 4 cells holds. A glow that pulses,
    // light that sweeps over a button or a slowly moving background barely changes it; different text changes it a lot.
    public static byte[] TextSig(Bitmap f, int x, int y, int w, int h) {
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(f.Width, x + w), y1 = Math.Min(f.Height, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 6 || rh < 6) return new byte[0];
        int gw = Math.Min(16, rw / 2), gh = Math.Min(4, rh / 2);
        BitmapData d = f.LockBits(new Rectangle(x0, y0, rw, rh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int stride = d.Stride;
            byte[] buf = new byte[stride * rh];
            CopyRows(d, buf, rh, rw);
            int[] lum = new int[rw * rh];
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) { int o = j * stride + i * 4; lum[j * rw + i] = (buf[o + 2] * 77 + buf[o + 1] * 150 + buf[o] * 29) >> 8; }
            long[] sum = new long[gw * gh];
            int[] cn = new int[gw * gh];
            for (int j = 0; j < rh - 1; j++) {
                int cj = (j * gh) / rh;
                for (int i = 0; i < rw - 1; i++) {
                    int ci = (i * gw) / rw;
                    int l = lum[j * rw + i];
                    int e = Math.Abs(lum[j * rw + i + 1] - l) + Math.Abs(lum[(j + 1) * rw + i] - l);
                    if (e < 12) e = 0;                       // soft gradients (glow, haze) are not text
                    sum[cj * gw + ci] += e; cn[cj * gw + ci]++;
                }
            }
            byte[] sg = new byte[gw * gh];
            for (int q = 0; q < sg.Length; q++) { if (cn[q] > 0) sg[q] = (byte)Math.Min(255L, sum[q] * 2 / cn[q]); }
            return sg;
        } finally { f.UnlockBits(d); }
    }
    // How different two TextSig arrays are, on a 0..24 scale (about 0-2 = same text, 5 and up = different text); -1 when
    // they cannot be compared.
    public static int SigDiff(byte[] a, byte[] b) {
        if (a == null || b == null || a.Length == 0 || a.Length != b.Length) return -1;
        long d = 0, ta = 0, tb = 0;
        for (int i = 0; i < a.Length; i++) { d += Math.Abs((int)a[i] - (int)b[i]); ta += a[i]; tb += b[i]; }
        long mean = (ta + tb) / 2;
        if (mean < a.Length * 4) return (int)Math.Min(24L, d / a.Length);       // (almost) no detail in either: plain brightness difference
        return (int)Math.Min(24L, (d * 12) / mean);
    }
    // Icon test: share of the "ink" in a box that survives an erosion wider than a text stroke. Letters are made of thin
    // strokes (almost nothing survives), filled icons such as padlocks keep a solid core. Returns {solid %, fill %} or {-1, -1}.
    public static int[] SolidPct(Bitmap f, int x, int y, int w, int h) {
        int[] none = new int[] { -1, -1 };
        int W = f.Width, H = f.Height;
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(W, x + w), y1 = Math.Min(H, y + h);
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 8 || rh < 8) return none;
        int pm = 3;
        int ax0 = Math.Max(0, x0 - pm), ay0 = Math.Max(0, y0 - pm), ax1 = Math.Min(W, x1 + pm), ay1 = Math.Min(H, y1 + pm);
        int aw = ax1 - ax0, ah = ay1 - ay0;
        BitmapData d = f.LockBits(new Rectangle(ax0, ay0, aw, ah), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = d.Stride;
        byte[] buf = new byte[stride * ah];
        try { CopyRows(d, buf, ah, aw); } finally { f.UnlockBits(d); }
        int rn = 0;
        int[] qr = new int[aw * ah], qg = new int[aw * ah], qb = new int[aw * ah];
        for (int j = 0; j < ah; j++) {
            for (int i = 0; i < aw; i++) {
                int gx = ax0 + i, gy = ay0 + j;
                if (gx >= x0 && gx < x1 && gy >= y0 && gy < y1) continue;
                int o = j * stride + i * 4;
                qb[rn] = buf[o]; qg[rn] = buf[o + 1]; qr[rn] = buf[o + 2]; rn++;
            }
        }
        if (rn < 8) return none;
        Array.Sort(qr, 0, rn); Array.Sort(qg, 0, rn); Array.Sort(qb, 0, rn);
        int mr = qr[rn / 2], mgc = qg[rn / 2], mb = qb[rn / 2];
        int rw1 = rw + 1;
        int[] I = new int[rw1 * (rh + 1)];
        int[] mk = new int[rw * rh];
        int inkN = 0;
        for (int j = 0; j < rh; j++) {
            int rowSum = 0;
            for (int i = 0; i < rw; i++) {
                int o = (y0 - ay0 + j) * stride + (x0 - ax0 + i) * 4;
                int dd = Math.Max(Math.Abs(buf[o + 2] - mr), Math.Max(Math.Abs(buf[o + 1] - mgc), Math.Abs(buf[o] - mb)));
                int v = dd > 38 ? 1 : 0;
                mk[j * rw + i] = v; inkN += v; rowSum += v;
                I[(j + 1) * rw1 + (i + 1)] = I[j * rw1 + (i + 1)] + rowSum;
            }
        }
        if (inkN < 8) return none;
        int fill = inkN * 100 / (rw * rh);
        int k = (int)Math.Round(rh * 0.14);
        if (k < 2) k = 2;
        if (2 * k + 1 > Math.Min(rw, rh)) k = (Math.Min(rw, rh) - 1) / 2;
        if (k < 2) return new int[] { 0, fill };
        int need = (2 * k + 1) * (2 * k + 1), surv = 0;
        for (int j = k; j < rh - k; j++) {
            for (int i = k; i < rw - k; i++) {
                if (mk[j * rw + i] == 0) continue;
                int sm = I[(j + k + 1) * rw1 + (i + k + 1)] - I[(j - k) * rw1 + (i + k + 1)] - I[(j + k + 1) * rw1 + (i - k)] + I[(j - k) * rw1 + (i - k)];
                if (sm == need) surv++;
            }
        }
        return new int[] { surv * 100 / inkN, fill };
    }
    // Cheap fingerprint of the picture under a box (96 samples) and a comparison, used to skip rebuilds of still backgrounds.
    public static byte[] Sig(Bitmap f, int x, int y, int w, int h) {
        int x0 = Math.Max(0, x), y0 = Math.Max(0, y), x1 = Math.Min(f.Width, x + w), y1 = Math.Min(f.Height, y + h);
        if (x1 - x0 < 2 || y1 - y0 < 2) return new byte[0];
        BitmapData d = f.LockBits(new Rectangle(x0, y0, x1 - x0, y1 - y0), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int gw = 16, gh = 6, rw = x1 - x0, rh = y1 - y0, k = 0;
            byte[] s = new byte[gw * gh * 3];
            for (int j = 0; j < gh; j++) {
                for (int i = 0; i < gw; i++) {
                    int px = (i * (rw - 1)) / (gw - 1), py = (j * (rh - 1)) / (gh - 1);
                    int o = py * d.Stride + px * 4;
                    s[k++] = Marshal.ReadByte(d.Scan0, o);
                    s[k++] = Marshal.ReadByte(d.Scan0, o + 1);
                    s[k++] = Marshal.ReadByte(d.Scan0, o + 2);
                }
            }
            return s;
        } finally { f.UnlockBits(d); }
    }
    public static bool Differs(byte[] a, byte[] b, int thr) {
        if (a == null || b == null || a.Length == 0 || a.Length != b.Length) return true;
        int sum = 0, big = 0;
        for (int i = 0; i < a.Length; i++) {
            int dd = Math.Abs(a[i] - b[i]);
            sum += dd;
            if (dd > 12) big++;
        }
        return (sum / a.Length) >= thr || big >= 3;
    }
    // Like EdgeRoom, but to the LEFT of the box: free pixels before a strong vertical edge (button border, panel edge).
    public static int EdgeRoomLeft(Bitmap f, int x, int y, int w, int h, int maxExtra) {
        int W = f.Width, H = f.Height;
        int y0 = Math.Max(0, y), y1 = Math.Min(H, y + h);
        int xs = Math.Min(W - 3, x - 2), xe = Math.Max(0, x - maxExtra);
        if (y1 - y0 < 3 || xs <= xe) return maxExtra;
        BitmapData d = f.LockBits(new Rectangle(0, y0, W, y1 - y0), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try {
            int rows = y1 - y0;
            for (int cx = xs; cx >= xe; cx--) {
                int hits = 0;
                for (int j = 0; j < rows; j++) {
                    int o1 = j * d.Stride + cx * 4, o0 = j * d.Stride + (cx + 2) * 4;
                    int dm = 0;
                    for (int c = 0; c < 3; c++) {
                        int dd = Math.Abs(Marshal.ReadByte(d.Scan0, o1 + c) - Marshal.ReadByte(d.Scan0, o0 + c));
                        if (dd > dm) dm = dd;
                    }
                    if (dm > 40) hits++;
                }
                if (hits * 100 >= rows * 60) return Math.Max(0, x - (cx + 2) - 2);
            }
            return maxExtra;
        } finally { f.UnlockBits(d); }
    }
    // The border samples that estimate the background can sit on strokes of the text. Short runs that differ strongly
    // from the surrounding samples are replaced by a straight line between the good samples on either side.
    static void CleanProf(int[] a, int[] b, int[] c) {
        int n = a.Length;
        if (n < 9) return;
        int win = Math.Max(6, n / 8);
        int maxRun = Math.Max(8, n / 5);
        bool[] bad = new bool[n];
        int[] ta = new int[2 * win + 1], tb = new int[2 * win + 1], tc = new int[2 * win + 1];
        for (int i = 0; i < n; i++) {
            int lo = Math.Max(0, i - win), hi = Math.Min(n - 1, i + win), cn = hi - lo + 1;
            for (int k = 0; k < cn; k++) { ta[k] = a[lo + k]; tb[k] = b[lo + k]; tc[k] = c[lo + k]; }
            Array.Sort(ta, 0, cn); Array.Sort(tb, 0, cn); Array.Sort(tc, 0, cn);
            int ma = ta[cn / 2], mb = tb[cn / 2], mc = tc[cn / 2];
            int dd = Math.Max(Math.Abs(a[i] - ma), Math.Max(Math.Abs(b[i] - mb), Math.Abs(c[i] - mc)));
            if (dd > 26) bad[i] = true;
        }
        int s0 = 0;
        while (s0 < n) {
            if (!bad[s0]) { s0++; continue; }
            int e0 = s0;
            while (e0 < n && bad[e0]) e0++;
            if (e0 - s0 > maxRun) { s0 = e0; continue; }
            int l0 = s0 - 1, r0 = e0;
            for (int k = s0; k < e0; k++) {
                if (l0 >= 0 && r0 < n) {
                    double t = (k - l0) / (double)(r0 - l0);
                    a[k] = (int)Math.Round(a[l0] * (1 - t) + a[r0] * t);
                    b[k] = (int)Math.Round(b[l0] * (1 - t) + b[r0] * t);
                    c[k] = (int)Math.Round(c[l0] * (1 - t) + c[r0] * t);
                } else if (l0 >= 0) { a[k] = a[l0]; b[k] = b[l0]; c[k] = c[l0]; }
                else if (r0 < n) { a[k] = a[r0]; b[k] = b[r0]; c[k] = c[r0]; }
            }
            s0 = e0;
        }
    }
    // Exact copy of the picture under a box (no key colour), used for the parts of a label that held no Chinese text.
    static Bitmap RawCopy(Bitmap frame, int x, int y, int w, int h) {
        int W = frame.Width, H = frame.Height;
        Bitmap res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData rd = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        int rs = rd.Stride;
        byte[] ob = new byte[rs * h];
        int cx0 = Math.Max(0, x), cy0 = Math.Max(0, y), cx1 = Math.Min(W, x + w), cy1 = Math.Min(H, y + h);
        if (cx1 - cx0 >= 2 && cy1 - cy0 >= 2) {
            int fw = cx1 - cx0, fh = cy1 - cy0;
            BitmapData bd = frame.LockBits(new Rectangle(cx0, cy0, fw, fh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int stride = bd.Stride;
            byte[] buf = new byte[stride * fh];
            CopyRows(bd, buf, fh, fw);
            frame.UnlockBits(bd);
            for (int j = 0; j < h; j++) {
                int sy = y + j; if (sy < cy0) sy = cy0; if (sy > cy1 - 1) sy = cy1 - 1; sy -= cy0;
                for (int i = 0; i < w; i++) {
                    int sx = x + i; if (sx < cx0) sx = cx0; if (sx > cx1 - 1) sx = cx1 - 1; sx -= cx0;
                    int o = sy * stride + sx * 4, po = j * rs + i * 4;
                    int vb = buf[o], vg = buf[o + 1], vr = buf[o + 2];
                    if (vb > 254) vb = 254; if (vg > 254) vg = 254; if (vr > 254) vr = 254;
                    ob[po] = (byte)vb; ob[po + 1] = (byte)vg; ob[po + 2] = (byte)vr; ob[po + 3] = 255;
                }
            }
        } else {
            for (int j = 0; j < h; j++) {
                for (int i = 0; i < w; i++) { int po = j * rs + i * 4; ob[po] = 32; ob[po + 1] = 28; ob[po + 2] = 28; ob[po + 3] = 255; }
            }
        }
        Marshal.Copy(ob, 0, rd.Scan0, ob.Length);
        res.UnlockBits(rd);
        return res;
    }
    // Glass for a label: the picture behind the label stays exactly as it is, except for the area of the Chinese text
    // (tx,ty,tw,th, same coordinates as x,y), which is cleaned of strokes (background sampled from just outside that area).
    public static Bitmap MakeT(Bitmap frame, int x, int y, int w, int h, int tx, int ty, int tw, int th, int r, int tintPct) {
        if (w < 4 || h < 4) throw new ArgumentException("size");
        if (tw < 4 || th < 4) return MakeCore(frame, x, y, w, h, r, tintPct, 0);
        int mg = Math.Max(3, (int)Math.Round(th * 0.12));
        int ex = tx - mg, ey = ty - mg, ew = tw + 2 * mg, eh = th + 2 * mg;
        Bitmap core = MakeCore(frame, ex, ey, ew, eh, r, tintPct, 0);
        Bitmap res = null;
        try {
            res = RawCopy(frame, x, y, w, h);
            int px0 = Math.Max(ex, x), py0 = Math.Max(ey, y), px1 = Math.Min(ex + ew, x + w), py1 = Math.Min(ey + eh, y + h);
            if (px1 > px0 && py1 > py0) {
                int cwid = px1 - px0, chei = py1 - py0;
                BitmapData cd = core.LockBits(new Rectangle(px0 - ex, py0 - ey, cwid, chei), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                BitmapData rd2 = res.LockBits(new Rectangle(px0 - x, py0 - y, cwid, chei), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
                try {
                    byte[] line = new byte[cwid * 4];
                    for (int j = 0; j < chei; j++) {
                        Marshal.Copy(new IntPtr(cd.Scan0.ToInt64() + (long)j * cd.Stride), line, 0, line.Length);
                        Marshal.Copy(line, 0, new IntPtr(rd2.Scan0.ToInt64() + (long)j * rd2.Stride), line.Length);
                    }
                } finally { core.UnlockBits(cd); res.UnlockBits(rd2); }
            }
        } catch { if (res != null) res.Dispose(); core.Dispose(); throw; }
        core.Dispose();
        return res;
    }
    // Glass for the box (x,y,w,h) of the frame: the background behind the Chinese text is estimated from the box
    // border (smooth interpolation), every pixel that differs from it (the strokes, their edges) is replaced by the
    // surrounding picture, and the result is blurred lightly. Also measures the colour of the original ink.
    public static Bitmap Make(Bitmap frame, int x, int y, int w, int h, int r, int tintPct, int corner) {
        return MakeCore(frame, x, y, w, h, r, tintPct, corner);
    }
    static Bitmap MakeCore(Bitmap frame, int x, int y, int w, int h, int r, int tintPct, int corner) {
        if (w < 4 || h < 4) throw new ArgumentException("size");
        int W = frame.Width, H = frame.Height;
        int n = w * h;
        int[] R = new int[n], G = new int[n], B = new int[n];
        int cx0 = Math.Max(0, x), cy0 = Math.Max(0, y), cx1 = Math.Min(W, x + w), cy1 = Math.Min(H, y + h);
        if (cx1 - cx0 >= 2 && cy1 - cy0 >= 2) {
            int fw = cx1 - cx0, fh = cy1 - cy0;
            BitmapData bd = frame.LockBits(new Rectangle(cx0, cy0, fw, fh), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int stride = bd.Stride;
            byte[] buf = new byte[stride * fh];
            CopyRows(bd, buf, fh, fw);
            frame.UnlockBits(bd);
            for (int j = 0; j < h; j++) {
                int sy = y + j; if (sy < cy0) sy = cy0; if (sy > cy1 - 1) sy = cy1 - 1; sy -= cy0;
                for (int i = 0; i < w; i++) {
                    int sx = x + i; if (sx < cx0) sx = cx0; if (sx > cx1 - 1) sx = cx1 - 1; sx -= cx0;
                    int o = sy * stride + sx * 4; int q = j * w + i;
                    B[q] = buf[o]; G[q] = buf[o + 1]; R[q] = buf[o + 2];
                }
            }
        } else {
            for (int q = 0; q < n; q++) { R[q] = 28; G[q] = 28; B[q] = 32; }
        }
        int[][] P = new int[][] { R, G, B };
        int[][] Bg = new int[3][];
        int band = (w >= 8 && h >= 8) ? 2 : 1;
        int[][] topP = new int[3][], botP = new int[3][], lefP = new int[3][], rigP = new int[3][];
        for (int c = 0; c < 3; c++) {
            int[] p = P[c];
            int[] top0 = new int[w], bot0 = new int[w], lef0 = new int[h], rig0 = new int[h];
            for (int i = 0; i < w; i++) {
                int st = 0, sb = 0;
                for (int k = 0; k < band; k++) { st += p[k * w + i]; sb += p[(h - 1 - k) * w + i]; }
                top0[i] = st / band; bot0[i] = sb / band;
            }
            for (int j = 0; j < h; j++) {
                int sl = 0, sr = 0;
                for (int k = 0; k < band; k++) { sl += p[j * w + k]; sr += p[j * w + (w - 1 - k)]; }
                lef0[j] = sl / band; rig0[j] = sr / band;
            }
            topP[c] = top0; botP[c] = bot0; lefP[c] = lef0; rigP[c] = rig0;
        }
        // strokes that touch the sample border would otherwise be taken for background
        CleanProf(topP[0], topP[1], topP[2]); CleanProf(botP[0], botP[1], botP[2]);
        CleanProf(lefP[0], lefP[1], lefP[2]); CleanProf(rigP[0], rigP[1], rigP[2]);
        for (int c = 0; c < 3; c++) {
            int[] top = Smooth(topP[c]), bot = Smooth(botP[c]), lef = Smooth(lefP[c]), rig = Smooth(rigP[c]);
            double c00 = (top[0] + lef[0]) / 2.0, c10 = (top[w - 1] + rig[0]) / 2.0, c01 = (bot[0] + lef[h - 1]) / 2.0, c11 = (bot[w - 1] + rig[h - 1]) / 2.0;
            int[] bg = new int[n];
            for (int j = 0; j < h; j++) {
                double v = j / (double)(h - 1);
                for (int i = 0; i < w; i++) {
                    double u = i / (double)(w - 1);
                    double val = (1 - v) * top[i] + v * bot[i] + (1 - u) * lef[j] + u * rig[j]
                        - ((1 - u) * (1 - v) * c00 + u * (1 - v) * c10 + (1 - u) * v * c01 + u * v * c11);
                    int iv = (int)Math.Round(val); if (iv < 0) iv = 0; if (iv > 255) iv = 255;
                    bg[j * w + i] = iv;
                }
            }
            Bg[c] = bg;
        }
        // deviation of every pixel from the estimated background; the threshold follows the texture of the picture
        int[] dev = new int[n];
        int[] dhist = new int[256];
        for (int q = 0; q < n; q++) {
            int dq = Math.Max(Math.Abs(R[q] - Bg[0][q]), Math.Max(Math.Abs(G[q] - Bg[1][q]), Math.Abs(B[q] - Bg[2][q])));
            if (dq > 255) dq = 255;
            dev[q] = dq; dhist[dq]++;
        }
        int med = 0;
        { int accm = 0; for (int dl = 0; dl < 256; dl++) { accm += dhist[dl]; if (accm * 2 >= n) { med = dl; break; } } }
        int thr = Math.Max(22, (int)(1.8 * med) + 8);
        if (thr > 60) thr = 60;
        bool[] m0 = new bool[n];
        for (int tries = 0; tries < 4; tries++) {
            int c0 = 0;
            for (int q = 0; q < n; q++) { bool st0 = dev[q] > thr; m0[q] = st0; if (st0) c0++; }
            if (c0 * 100 <= n * 60) break;
            thr = (int)(thr * 1.4) + 4;
        }
        // soft edges, glow and shadow next to a stroke belong to it too (two rounds of growth through weaker pixels)
        int weakT = (thr * 55) / 100;
        bool[] ms = new bool[n];
        Array.Copy(m0, ms, n);
        for (int itn = 0; itn < 2; itn++) {
            bool[] nxt = (bool[])ms.Clone();
            for (int j = 0; j < h; j++) {
                for (int i = 0; i < w; i++) {
                    int q = j * w + i;
                    if (ms[q] || dev[q] <= weakT) continue;
                    bool nbr = false;
                    for (int dj = -1; dj <= 1 && !nbr; dj++) {
                        int jj = j + dj; if (jj < 0 || jj >= h) continue;
                        for (int di = -1; di <= 1; di++) {
                            int ii = i + di; if (ii < 0 || ii >= w) continue;
                            if (ms[jj * w + ii]) { nbr = true; break; }
                        }
                    }
                    if (nbr) nxt[q] = true;
                }
            }
            ms = nxt;
        }
        int dr = (h >= 34) ? 2 : 1;
        bool[] m = new bool[n];
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                bool hit = false;
                for (int dj = -dr; dj <= dr && !hit; dj++) {
                    int jj = j + dj; if (jj < 0 || jj >= h) continue;
                    for (int di = -dr; di <= dr; di++) {
                        int ii = i + di; if (ii < 0 || ii >= w) continue;
                        if (ms[jj * w + ii]) { hit = true; break; }
                    }
                }
                m[j * w + i] = hit;
            }
        }
        // colour of the original ink: average of the strongest 30% of the stroke pixels
        InkOk = false;
        int[] hist = new int[256];
        int tot = 0;
        for (int q = 0; q < n; q++) { if (m0[q]) { hist[dev[q]]++; tot++; } }
        if (tot >= 6 && tot * 100 <= n * 65) {
            int need = (tot * 30 + 99) / 100, acc = 0, cut = 255;
            for (int dl = 255; dl >= 0; dl--) { acc += hist[dl]; if (acc >= need) { cut = dl; break; } }
            long sr = 0, sg = 0, sbl = 0; int inkN = 0;
            for (int q = 0; q < n; q++) { if (m0[q] && dev[q] >= cut) { sr += R[q]; sg += G[q]; sbl += B[q]; inkN++; } }
            if (inkN > 0) { IR = (int)(sr / inkN); IG = (int)(sg / inkN); IB = (int)(sbl / inkN); InkOk = true; }
        }
        // fill every stroke pixel from the nearest clean pixels (along the shorter run, row or column)
        int[] Lh = new int[n], Rh = new int[n], Uv = new int[n], Dv = new int[n];
        for (int j = 0; j < h; j++) {
            int last = -1;
            for (int i = 0; i < w; i++) { if (!m[j * w + i]) last = i; Lh[j * w + i] = last; }
            last = -1;
            for (int i = w - 1; i >= 0; i--) { if (!m[j * w + i]) last = i; Rh[j * w + i] = last; }
        }
        for (int i = 0; i < w; i++) {
            int last = -1;
            for (int j = 0; j < h; j++) { if (!m[j * w + i]) last = j; Uv[j * w + i] = last; }
            last = -1;
            for (int j = h - 1; j >= 0; j--) { if (!m[j * w + i]) last = j; Dv[j * w + i] = last; }
        }
        int[] oR = new int[n], oG = new int[n], oB = new int[n];
        int INF = 1000000;
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int q = j * w + i;
                if (!m[q]) { oR[q] = R[q]; oG[q] = G[q]; oB[q] = B[q]; continue; }
                int hl = Lh[q], hr = Rh[q], vu = Uv[q], vd = Dv[q];
                int costH, costV;
                if (hl >= 0 && hr >= 0) costH = hr - hl; else if (hl >= 0) costH = 50 + 2 * (i - hl); else if (hr >= 0) costH = 50 + 2 * (hr - i); else costH = INF;
                if (vu >= 0 && vd >= 0) costV = vd - vu; else if (vu >= 0) costV = 50 + 2 * (j - vu); else if (vd >= 0) costV = 50 + 2 * (vd - j); else costV = INF;
                if (costH >= INF && costV >= INF) { oR[q] = Bg[0][q]; oG[q] = Bg[1][q]; oB[q] = Bg[2][q]; continue; }
                if (costH <= costV) {
                    if (hl >= 0 && hr >= 0) {
                        double t = (i - hl) / (double)(hr - hl); int pa = j * w + hl, pb = j * w + hr;
                        oR[q] = (int)(R[pa] * (1 - t) + R[pb] * t); oG[q] = (int)(G[pa] * (1 - t) + G[pb] * t); oB[q] = (int)(B[pa] * (1 - t) + B[pb] * t);
                    } else {
                        int pa = (hl >= 0) ? j * w + hl : j * w + hr;
                        oR[q] = R[pa]; oG[q] = G[pa]; oB[q] = B[pa];
                    }
                } else {
                    if (vu >= 0 && vd >= 0) {
                        double t = (j - vu) / (double)(vd - vu); int pa = vu * w + i, pb = vd * w + i;
                        oR[q] = (int)(R[pa] * (1 - t) + R[pb] * t); oG[q] = (int)(G[pa] * (1 - t) + G[pb] * t); oB[q] = (int)(B[pa] * (1 - t) + B[pb] * t);
                    } else {
                        int pa = (vu >= 0) ? vu * w + i : vd * w + i;
                        oR[q] = R[pa]; oG[q] = G[pa]; oB[q] = B[pa];
                    }
                }
            }
        }
        // only the repaired pixels (and a 1 px rim) are blurred and tinted, everything else stays exactly as on screen
        bool[] mz = new bool[n];
        bool allBlur = (r >= 3);      // strong blur: the whole text area is frosted, not only the repaired strokes
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                bool hz = false;
                for (int dj = -1; dj <= 1 && !hz; dj++) {
                    int jj = j + dj; if (jj < 0 || jj >= h) continue;
                    for (int di = -1; di <= 1; di++) {
                        int ii = i + di; if (ii < 0 || ii >= w) continue;
                        if (m[jj * w + ii]) { hz = true; break; }
                    }
                }
                mz[j * w + i] = hz || allBlur;
            }
        }
        int[] blR = oR, blG = oG, blB = oB;
        if (r > 0) {
            blR = (int[])oR.Clone(); blG = (int[])oG.Clone(); blB = (int[])oB.Clone();
            Blur(blR, w, h, r); Blur(blG, w, h, r); Blur(blB, w, h, r);
        }
        Bitmap res = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        BitmapData rd = res.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        int rs = rd.Stride;
        byte[] ob = new byte[rs * h];
        long sumR = 0, sumG = 0, sumB = 0; int cnt = 0;
        int cnr = Math.Max(0, Math.Min(corner, Math.Min(w, h) / 2));
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int po = j * rs + i * 4;
                bool outside = false;
                if (cnr > 0) {
                    int cx = -1, cy = -1;
                    if (i < cnr && j < cnr) { cx = cnr; cy = cnr; }
                    else if (i >= w - cnr && j < cnr) { cx = w - cnr - 1; cy = cnr; }
                    else if (i < cnr && j >= h - cnr) { cx = cnr; cy = h - cnr - 1; }
                    else if (i >= w - cnr && j >= h - cnr) { cx = w - cnr - 1; cy = h - cnr - 1; }
                    if (cx >= 0) { int ddx = i - cx, ddy = j - cy; if (ddx * ddx + ddy * ddy > cnr * cnr) outside = true; }
                }
                if (outside) { ob[po] = 255; ob[po + 1] = 0; ob[po + 2] = 255; ob[po + 3] = 255; continue; }
                int q = j * w + i;
                int rr = oR[q], gg = oG[q], bb = oB[q];
                if (mz[q]) {
                    rr = blR[q]; gg = blG[q]; bb = blB[q];
                    rr = (rr * (100 - tintPct) + Bg[0][q] * tintPct) / 100;
                    gg = (gg * (100 - tintPct) + Bg[1][q] * tintPct) / 100;
                    bb = (bb * (100 - tintPct) + Bg[2][q] * tintPct) / 100;
                }
                if (rr < 0) rr = 0; if (rr > 254) rr = 254;
                if (gg < 0) gg = 0; if (gg > 254) gg = 254;
                if (bb < 0) bb = 0; if (bb > 254) bb = 254;
                ob[po] = (byte)bb; ob[po + 1] = (byte)gg; ob[po + 2] = (byte)rr; ob[po + 3] = 255;
                sumR += rr; sumG += gg; sumB += bb; cnt++;
            }
        }
        Marshal.Copy(ob, 0, rd.Scan0, ob.Length);
        res.UnlockBits(rd);
        if (cnt > 0) { TR = (int)(sumR / cnt); TG = (int)(sumG / cnt); TB = (int)(sumB / cnt); } else { TR = 28; TG = 28; TB = 32; }
        Lum = (299 * TR + 587 * TG + 114 * TB) / 1000;
        return res;
    }
}
'@
    Add-Type -TypeDefinition $glass2Src -ReferencedAssemblies System.Drawing -ErrorAction Stop
    $script:Glass2Ok = $true
} catch { Write-Log ('glass2 unavailable, using the older glass: ' + $_.Exception.Message) }
Add-Type -TypeDefinition @"
using System;
using System.Threading;
using System.Runtime.InteropServices;
public static class HSKeys {
    public static int F7, F8, Quit;
    static int l7, l8, lq;
    static bool run, d7, d8, dE;
    delegate IntPtr LLProc(int code, IntPtr w, IntPtr l);
    [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
    [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, LLProc fn, IntPtr mod, uint tid);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
    [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string n);
    static LLProc proc = Hook;
    static bool Down(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
    static void Fire(ref int counter, ref int last) {
        int now = Environment.TickCount;
        if (unchecked(now - last) < 300) return;
        last = now; Interlocked.Increment(ref counter);
    }
    static IntPtr Hook(int code, IntPtr w, IntPtr l) {
        if (code >= 0) {
            int msg = (int)w; int vk = Marshal.ReadInt32(l);
            bool dn = (msg == 0x100 || msg == 0x104), up = (msg == 0x101 || msg == 0x105);
            if (vk == 0x76) { if (dn && !d7) { d7 = true; Fire(ref F7, ref l7); } else if (up) d7 = false; }
            else if (vk == 0x77) { if (dn && !d8) { d8 = true; Fire(ref F8, ref l8); } else if (up) d8 = false; }
            else if (vk == 0x23) { if (dn && !dE) { dE = true; Fire(ref Quit, ref lq); } else if (up) dE = false; }
        }
        return CallNextHookEx(IntPtr.Zero, code, w, l);
    }
    static void HookLoop() {
        try {
            string mn = System.Diagnostics.Process.GetCurrentProcess().MainModule.ModuleName;
            IntPtr h = SetWindowsHookEx(13, proc, GetModuleHandle(mn), 0);
            MSG m; while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { }
        } catch { }
    }
    static void PollLoop() {
        bool a = false, b = false, c = false, e = false;
        while (run) {
            bool na = Down(0x76), nb = Down(0x77), nc = Down(0x11) && Down(0x10) && Down(0x51), ne = Down(0x23);
            if (na && !a) Fire(ref F7, ref l7);
            if (nb && !b) Fire(ref F8, ref l8);
            if ((nc && !c) || (ne && !e)) Fire(ref Quit, ref lq);
            a = na; b = nb; c = nc; e = ne;
            Thread.Sleep(8);
        }
    }
    public static void Start() {
        if (run) return; run = true;
        Thread t = new Thread(PollLoop); t.IsBackground = true; t.Start();
        Thread h = new Thread(HookLoop); h.IsBackground = true; h.Start();
    }
    public static void Stop() { run = false; }
}
"@
[HSKeys]::Start()
$script:F7Seen = [HSKeys]::F7; $script:F8Seen = [HSKeys]::F8; $script:QSeen = [HSKeys]::Quit
$script:Notice = ''; $script:NoticeUntil = [DateTime]::MinValue
function Show-Notice([string]$t) { try { [System.Media.SystemSounds]::Asterisk.Play() } catch {}; Write-Log ('notice: ' + $t); $script:Notice = $t; $script:NoticeUntil = (Get-Date).AddSeconds(1.8); try { $script:Overlay.Invalidate() } catch {} }
$script:KeyLatch = @{}
function Test-KeyDown([int]$vk) {
    return (([KeyPoll]::GetAsyncKeyState($vk) -band 0x8000) -ne 0)
}
$script:KeyTimer = New-Object System.Windows.Forms.Timer
$script:KeyTimer.Interval = 30
$script:KeyTimer.Add_Tick({
    try {
        $n = [HSKeys]::F8; if ($n -ne $script:F8Seen) { $script:F8Seen = $n; Write-Log 'hotkey F8'; Toggle-Enabled }
        $n = [HSKeys]::F7; if ($n -ne $script:F7Seen) { $script:F7Seen = $n }      # F7 (debug overlay) is disabled
        $n = [HSKeys]::Quit; if ($n -ne $script:QSeen) { $script:QSeen = $n; Cleanup-And-Exit }
    } catch { Write-Log "keys: $_" }
})
$script:KeyTimer.Start()
Write-Log 'hotkeys polling F8 toggle / End close / Ctrl+Shift+Q close'
function Toggle-Enabled {
    $script:Settings.enabled = -not [bool]$script:Settings.enabled
    Save-Settings
    if ($script:Settings.enabled) { Show-Notice 'Starfire Lite: overlay ON' } else { Show-Notice 'Starfire Lite: overlay OFF' }
    if (-not $script:Settings.enabled) { $script:LastBlocks = @(); $script:Tracks.Clear(); $script:LastTextSig = $null; $script:Status = 'paused' }
    else { $script:Status = 'scanning'; $script:LastHash = $null }
    if ($script:Settings.enabled) { $script:ToggleItem.Text = 'Turn off   (F8)' } else { $script:ToggleItem.Text = 'Turn on   (F8)' }
    Update-Tray
    try { $script:Overlay.Invalidate() } catch {}
}

function Show-Debug {
    $lines = @()
    $lines += "Status: $($script:Status)"
    $lines += "Capture: $($script:Settings.captureMode)"
    $lines += "OCR: $($script:Settings.ocrLang)"
    $raw = $script:LastBlocks
    $n = 0
    if ($raw) { foreach ($b in $raw) { $n++ } }
    $lines += "Blocks held: $n"
    $lines += "Log: $script:LogPath"
    $lines += ""
    $i = 0
    if ($raw) {
        foreach ($b in $raw) {
            $i++
            if ($i -gt 8) { $lines += "..."; break }
            $en = ''
            try { $en = [string]$b.en } catch {}
            $lines += "$i. $en"
        }
    }
    $lines += ""
    $lines += "F8 on/off    End close"
    [System.Windows.Forms.MessageBox]::Show(($lines -join "`r`n"), 'Starfire Lite debug')
}

# ---------- OCR + translate (lazy) ----------
$script:AsTask = $null
function Ensure-WinRT {
    if ($script:OcrReady) { return $true }
    if ($script:OcrError) { return $false }
    try {
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $script:AsTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
            $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        })[0]
        $null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
        $null = [Windows.Storage.Streams.DataWriter, Windows.Storage.Streams, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        $null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
        $candidates = @('zh-Hans','zh-Hans-CN','zh-CN')
        $engine = $null
        $used = ''
        foreach ($tag in $candidates) {
            try {
                $lang = [Windows.Globalization.Language]::new($tag)
                if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)) {
                    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
                    if ($engine) { $used = $tag; break }
                }
            } catch {}
        }
        if (-not $engine) {
            try { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages(); $used = 'profile' } catch {}
        }
        if (-not $engine) {
            $script:OcrError = 'Chinese OCR pack is not installed. Right-click the H icon, then Install Chinese OCR packs.'
            $script:Status = 'OCR pack missing'
            Write-Log $script:OcrError
            return $false
        }
        $script:OcrEngine = $engine
        $script:OcrReady = $true
        Write-Log "OCR ready $used"
        return $true
    } catch {
        $script:OcrError = $_.Exception.Message
        $script:Status = 'OCR error'
        Write-Log "OCR init: $script:OcrError"
        return $false
    }
}
function Await-WinRT($op, [Type]$t) {
    $m = $script:AsTask.MakeGenericMethod($t)
    $task = $m.Invoke($null, @($op))
    $task.Wait()
    if ($task.IsFaulted) { throw $task.Exception.InnerException }
    return $task.Result
}
$script:WgcOn = $false; $script:WgcHwnd = [IntPtr]::Zero; $script:WgcFails = 0; $script:WgcNext = [DateTime]::MinValue
$script:WgcPool = $null; $script:WgcSess = $null; $script:WgcItem = $null; $script:WgcDev = $null
$script:WgcBuf = $null; $script:WgcW = 0; $script:WgcH = 0; $script:WgcHave = $false; $script:WgcLogged = $false
function Stop-Wgc {
    $script:WgcOn = $false; $script:WgcHave = $false
    foreach ($o in @($script:WgcSess, $script:WgcPool)) { if ($o) { try { $o.Dispose() } catch {} } }
    $script:WgcSess = $null; $script:WgcPool = $null; $script:WgcItem = $null; $script:WgcHwnd = [IntPtr]::Zero
}
function Start-Wgc {
    # start reading the game window through Windows window capture; false (and the old method is used) when not possible
    if (-not $script:WgcOk -or -not $script:OcrReady -or [string]$script:Settings.printCapture -eq 'off') { return $false }
    if (-not $script:Game -or $script:Game.hwnd -eq [IntPtr]::Zero) { return $false }
    if ($script:WgcOn -and $script:WgcHwnd -eq $script:Game.hwnd) { return $true }
    if ((Get-Date) -lt $script:WgcNext) { return $false }
    Stop-Wgc
    try {
        $null = [Windows.Graphics.Capture.GraphicsCaptureItem, Windows.Graphics, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Capture.Direct3D11CaptureFramePool, Windows.Graphics, ContentType = WindowsRuntime]
        if (-not $script:WgcDev) { $script:WgcDev = [StarWgc]::CreateDevice() }
        $script:WgcItem = [StarWgc]::CreateItem($script:Game.hwnd)
        $sz = $script:WgcItem.Size
        $script:WgcPool = [StarWgc]::CreatePool($script:WgcDev, $script:WgcItem)
        $script:WgcSess = $script:WgcPool.CreateCaptureSession($script:WgcItem)
        try { $script:WgcSess.IsCursorCaptureEnabled = $false } catch {}
        $border = 'on'
        try {
            $null = [Windows.Graphics.Capture.GraphicsCaptureAccess, Windows.Graphics, ContentType = WindowsRuntime]
            $null = Await-WinRT ([Windows.Graphics.Capture.GraphicsCaptureAccess]::RequestAccessAsync([Windows.Graphics.Capture.GraphicsCaptureAccessKind]::Borderless)) ([Windows.Security.Authorization.AppCapabilityAccess.AppCapabilityAccessStatus, Windows.Security, ContentType = WindowsRuntime])
        } catch {}
        try { $script:WgcSess.IsBorderRequired = $false; $border = 'off' } catch {}
        $script:WgcSess.StartCapture()
        $script:WgcHwnd = $script:Game.hwnd; $script:WgcOn = $true; $script:WgcFails = 0; $script:WgcW = [int]$sz.Width; $script:WgcH = [int]$sz.Height
        Write-Log ('window capture: ON (' + $script:WgcW + 'x' + $script:WgcH + ', border ' + $border + ') - the overlay is no longer hidden for scans')
        return $true
    } catch {
        Write-Log ('window capture: not possible (' + $_.Exception.Message + ')')
        Stop-Wgc; $script:WgcNext = (Get-Date).AddMinutes(2)
        return $false
    }
}
function Grab-Wgc($dst, $scr) {
    # newest picture of the game window -> dst (dst covers the screen rectangle $scr); false when not available
    if (-not (Start-Wgc)) { return $false }
    try {
        $f = $null
        for ($i = 0; $i -lt 8; $i++) {
            $n = $script:WgcPool.TryGetNextFrame()
            if ($null -eq $n) { break }
            if ($f) { try { $f.Dispose() } catch {} }
            $f = $n
        }
        if ($f) {
            # Windows only sends a new picture when the window changes; the last one is kept for the scans in between
            $cs = $f.ContentSize
            $sbm = $null
            try { $sbm = Await-WinRT ([StarWgc]::CopyAsync($f, [Windows.Graphics.Imaging.SoftwareBitmap])) ([Windows.Graphics.Imaging.SoftwareBitmap]) }
            finally { try { $f.Dispose() } catch {} }
            $pw = [int]$sbm.PixelWidth; $ph = [int]$sbm.PixelHeight
            if ($null -eq $script:WgcBuf -or $script:WgcBuf.Length -ne ($pw * $ph * 4)) { $script:WgcBuf = New-Object byte[] ($pw * $ph * 4) }
            $sbm.CopyToBuffer([System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions]::AsBuffer($script:WgcBuf))
            try { $sbm.Dispose() } catch {}
            $script:WgcPw = $pw; $script:WgcPh = $ph; $script:WgcHave = $true
            if ([int]$cs.Width -ne $script:WgcW -or [int]$cs.Height -ne $script:WgcH) {
                # the window changed size: make the buffers match the new size
                $script:WgcW = [int]$cs.Width; $script:WgcH = [int]$cs.Height
                try { [StarWgc]::Recreate($script:WgcPool, $script:WgcDev, $cs) } catch {}
            }
        }
        if (-not $script:WgcHave) { return $false }
        $org = [StarWgc]::FrameOrigin($script:Game.hwnd)
        $ok = [StarWgc]::Blit($script:WgcBuf, [int]$script:WgcPw, [int]$script:WgcPh, ([int]$scr.X - [int]$org.X), ([int]$scr.Y - [int]$org.Y), $dst)
        if (-not $ok) { return $false }
        $script:WgcFails = 0
        return $true
    } catch {
        $script:WgcFails = [int]$script:WgcFails + 1
        if ([int]$script:WgcFails -le 3) { Write-Log ('window capture: ' + $_.Exception.Message) }
        if ([int]$script:WgcFails -ge 5) { Write-Log 'window capture: off for 2 minutes after repeated errors'; Stop-Wgc; $script:WgcNext = (Get-Date).AddMinutes(2) }
        return $false
    }
}
function Add-SymRect($list, $r, [double]$scale, $rect) {
    # remember where something that is NOT being labelled sits (icons, check marks, numbers, boxes read as characters)
    try { [void]$list.Add(@{ x = [int]($rect.X + [double]$r.X / $scale); y = [int]($rect.Y + [double]$r.Y / $scale); w = [int]([double]$r.Width / $scale); h = [int]([double]$r.Height / $scale) }) } catch {}
}
$script:RejLogged = New-Object System.Collections.Hashtable
$script:Sym = @()
function Log-Reject([string]$why, [string]$text) {
    # one log line per distinct rejected text (max 300) so misses can be diagnosed from starfire.log
    try {
        if ($script:RejLogged.Count -ge 300) { return }
        $k = $why + '|' + $text
        if ($script:RejLogged.ContainsKey($k)) { return }
        $script:RejLogged[$k] = 1
        Write-Log ('reject [' + $why + ']: ' + $text)
    } catch {}
}
function Convert-CnNum([string]$s) {
    # Chinese numerals (一二三 ... 十 百 千 万 亿, 零 〇 两) -> number, or $null
    if ([string]::IsNullOrEmpty($s)) { return $null }
    $dg = @{ '零' = 0; '〇' = 0; '一' = 1; '二' = 2; '两' = 2; '三' = 3; '四' = 4; '五' = 5; '六' = 6; '七' = 7; '八' = 8; '九' = 9 }
    $total = 0.0; $sec = 0.0; $cur = 0.0
    foreach ($ch in $s.ToCharArray()) {
        $c = [string]$ch
        if ($dg.ContainsKey($c)) { $cur = [double]$dg[$c]; continue }
        if ($c -eq '十') { if ($cur -eq 0) { $cur = 1 }; $sec += $cur * 10; $cur = 0; continue }
        if ($c -eq '百') { if ($cur -eq 0) { $cur = 1 }; $sec += $cur * 100; $cur = 0; continue }
        if ($c -eq '千') { if ($cur -eq 0) { $cur = 1 }; $sec += $cur * 1000; $cur = 0; continue }
        if ($c -eq '万') { $sec += $cur; $cur = 0; if ($sec -eq 0) { $sec = 1 }; $total += $sec * 10000; $sec = 0; continue }
        if ($c -eq '亿') { $sec += $cur; $cur = 0; if ($sec -eq 0) { $sec = 1 }; $total += $sec * 100000000; $sec = 0; continue }
        return $null
    }
    return ($total + $sec + $cur)
}
function Get-NumberOnlyValue([string]$t) {
    # value of a text that is nothing but a number (digits, Chinese numerals, 万/亿 amounts); $null when it is not
    if ([string]::IsNullOrWhiteSpace($t)) { return $null }
    $k = ([regex]::Replace($t, '[\s　]', '')).Trim('.', ',', ':', '+', '-', '/', '%')
    if ($k.Length -eq 0) { return $null }
    if ($k -match '^[\d,\.]+$') { try { return [double]($k -replace ',', '') } catch { return $null } }
    $m = [regex]::Match($k, '^(\d+(?:,\d{3})*(?:\.\d+)?)([万亿])$')
    if ($m.Success) {
        $v = [double]($m.Groups[1].Value -replace ',', '')
        if ($m.Groups[2].Value -eq '万') { return $v * 10000 } else { return $v * 100000000 }
    }
    if ($k -match '^[零〇一二三四五六七八九十百千两万亿]+$') { return (Convert-CnNum $k) }
    return $null
}
function Format-BigNumber([double]$v) {
    $ci = [System.Globalization.CultureInfo]::InvariantCulture
    if ($v -ge 1000000000) { return [string]::Format($ci, '{0:0.##} billion', ($v / 1000000000)) }
    if ($v -ge 1000000) { return [string]::Format($ci, '{0:0.##} million', ($v / 1000000)) }
    return [string]::Format($ci, '{0:N0}', $v)
}
function Translate-Local([string]$k) {
    # win / loss streak badges: "3连胜" -> "3 Win Streak" (also when the OCR mangles 胜 into a look-alike: 牲 性 甡 月生)
    $mWs = [regex]::Match($k, '^\s*(\d{1,3})\s*连\s*(胜|牲|性|甡|月生|腾|姓)\s*$')
    if ($mWs.Success) { return ($mWs.Groups[1].Value + ' Win Streak') }
    $mLs = [regex]::Match($k, '^\s*(\d{1,3})\s*连\s*(败|贩|顺|收)\s*$')
    if ($mLs.Success) { return ($mLs.Groups[1].Value + ' Loss Streak') }
    # level fragments such as "3级" / "（3级）" / "3 级)" on reward rows: "Lv. 3", brackets kept
    $mLv = [regex]::Match($k, '^\s*([\(（]?)\s*(\d{1,3})\s*级\s*([\)）]?)\s*$')
    if ($mLv.Success) { $o1 = ''; if ($mLv.Groups[1].Value) { $o1 = '(' }; $c1 = ''; if ($mLv.Groups[3].Value) { $c1 = ')' }; return ($o1 + 'Lv. ' + $mLv.Groups[2].Value + $c1) }
    # ordinals such as 第一章 / 第三关 / 第五天: answered locally and instantly (Chapter 1, Stage 3, Day 5)
    $m = [regex]::Match($k, '^第\s*([零〇一二三四五六七八九十百千两\d]+)\s*(赛季|回合|章|关|天|局|名|话|节|周|期|阶|层|轮|幕|卷|集|季)$')
    if (-not $m.Success) { return $null }
    $num = $m.Groups[1].Value
    if ($num -match '^\d+$') { $v = [double]$num } else { $v = Convert-CnNum $num }
    if ($null -eq $v) { return $null }
    $w = ''
    switch ($m.Groups[2].Value) {
        '章' { $w = 'Chapter' } '关' { $w = 'Stage' } '天' { $w = 'Day' } '局' { $w = 'Game' } '名' { $w = 'Rank' }
        '话' { $w = 'Episode' } '节' { $w = 'Section' } '周' { $w = 'Week' } '期' { $w = 'Phase' } '阶' { $w = 'Tier' }
        '层' { $w = 'Floor' } '轮' { $w = 'Round' } '幕' { $w = 'Act' } '卷' { $w = 'Volume' } '集' { $w = 'Episode' } '回合' { $w = 'Round' }
        '赛季' { $w = 'Season' } '季' { $w = 'Season' }
    }
    if (-not $w) { return $null }
    return ($w + ' ' + [string][int]$v)
}
$script:CleanCache = New-Object System.Collections.Hashtable
function Clean-OcrText([string]$t) {
    # icons, bullets, arrows, box-drawing and private-use glyphs are symbols, not text
    if ([string]::IsNullOrEmpty($t)) { return '' }
    $hit = $script:CleanCache[$t]
    if ($null -ne $hit) { return $hit }
    $r = [regex]::Replace($t, '[\p{So}\p{Sk}\p{Co}\p{Cs}\p{Cn}←-⇿─-➿⬀-⯿■-◿︀-️⺀-⿟㇀-㇯　〃-〇〒〓〠〾〿]', ' ')
    $r = [regex]::Replace($r, '[^\u0000-\u024F\u2000-\u206F\u3000-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uFF00-\uFFEF]', ' ')
    $r = [regex]::Replace($r, '\s+', ' ').Trim()
    if ($script:CleanCache.Count -gt 4000) { $script:CleanCache = New-Object System.Collections.Hashtable }
    $script:CleanCache[$t] = $r
    return $r
}
# duel rank names (season ladder), optionally with their tier: 百川2阶, 九曲 3阶, 万界三 ...
# things that get a label of their own, apart from whatever they are written next to: character names, currencies, and
# season / challenge / event words that carry a number ("赛季3", "挑战 5/10"); the numbers themselves stay visible
$script:IsoNames = '张楚岚|冯宝宝|宝儿姐|王也|诸葛青|张灵玉|夏禾|柳妍妍|陆瑾|陆玲珑|巴伦|徐三|徐四|张之维|老天师|苑陶|张锡林|王震球|田晋中|夏柳青|王蔼|徐翔|吕良|王并|张怀义|涂君房|陈金魁|沈冲|吕慈|高宁|风莎燕|风正豪|无根生|窦梅|王子仲|杨烈|风星潼|贾正亮|吕恭|胡杰|马仙洪|郑子布|丁嶋安|小羽'
$script:IsoCur = '银鲤币|金鳞币|灵银币|冒险币|金币|铜币|抽奖券|绑定券|夺宝券|招募券|符券|点券|炁局通宝|通宝|海选积分|活动积分|段位积分|赛季积分|积分|成就点数|声望|体力|元宝|铜钱'
$script:RankRx = '(初隅|初露|三庭|三涧|六苑|六泽|九曲|九陌|百川|百国|千境|千泷|万渊|万界|卓越)(\s*[1-3一二三]\s*阶)?'
# brackets: what is inside a pair stays together - never split apart, never cut out of its brackets
$script:BrOpen = '【《（(「『〔［[〈'
$script:BrClose = '】》）)」』〕］]〉'
$script:BrOnlyRx = '^[【《（(「『〔［\[〈】》）)」』〕］\]〉\s]+$'
function Get-BracketSpans([string]$cs) {
    # @(start, end) of every outermost bracket pair in the text (end = index of the closing bracket)
    $out = New-Object System.Collections.Generic.List[object]; $st = -1; $dp = 0
    for ($q = 0; $q -lt $cs.Length; $q++) {
        $ch = $cs[$q]
        if ($script:BrOpen.IndexOf($ch) -ge 0) { if ($dp -eq 0) { $st = $q }; $dp++ }
        elseif ($script:BrClose.IndexOf($ch) -ge 0 -and $dp -gt 0) { $dp--; if ($dp -eq 0) { [void]$out.Add(@($st, $q)) } }
    }
    return ,$out
}
function Fit-ToBrackets($spans, [int]$a, [int]$n) {
    # a piece that lies inside a bracket pair grows to the whole pair (brackets included); a piece that crosses a bracket
    # edge cannot be cut out at all ($null)
    $b = $a + $n - 1
    foreach ($sp in $spans) {
        $s0 = [int]$sp[0]; $s1 = [int]$sp[1]
        if ($b -lt $s0 -or $a -gt $s1) { continue }
        if ($a -ge $s0 -and $b -le $s1) { return @($s0, ($s1 - $s0 + 1)) }
        if ($a -le $s0 -and $b -ge $s1) { continue }
        return $null
    }
    return @($a, $n)
}
$script:LookalikeHan = '一二三十丨丿乀乁乙乚人入八儿几口囗日曰目田由甲申回工土士干于了刀力又厂冂凵彐丶卜匕匚厶亠冖丁七九乃丷冫刂亻彳辶廴'
$script:SingleOk = '攻防击闪技招炁血魔金木水火土阴阳雷风术式力速甲乙丙丁战胜败赢升级星阶品位怒气体命元'
$script:RealCache = New-Object System.Collections.Hashtable
$script:RealN = -1
function Test-RealText([string]$t) {
    if ($script:RealN -ne $script:Dict.Count) { $script:RealCache = New-Object System.Collections.Hashtable; $script:RealN = $script:Dict.Count }
    $k = $script:RealCache[$t]
    if ($null -ne $k) { return [bool]$k }
    $v = [bool](Test-RealTextRaw $t)
    if ($script:RealCache.Count -gt 4000) { $script:RealCache = New-Object System.Collections.Hashtable }
    $script:RealCache[$t] = $v
    return $v
}
function Test-RealTextRaw([string]$t) {
    if ([string]::IsNullOrWhiteSpace($t)) { return $false }
    if ($t -match '^\s*第\s*[0-9０-９一二三四五六七八九十]{1,3}\s*$') { return $true }          # "第1": the ordinal in front of a unit (赛季, 章 ...), merged with it later
    $han = [regex]::Matches($t, '[\u4e00-\u9fff]').Count
    if ($han -lt 1) { return $false }
    $letters = [regex]::Matches($t, '[\p{L}]').Count
    if ($letters -lt 1) { return $false }
    if (($han / [double]$letters) -lt 0.5) { return $false }                 # mostly latin noise around a stray glyph
    $core = [regex]::Replace($t, '[^\u4e00-\u9fff]', '')
    # the same character repeated (rows of bars/dots/boxes read as 二二二 or 口口口)
    if ($core.Length -ge 3) {
        $cnts = @{}; $top = 0
        foreach ($c1 in $core.ToCharArray()) { $v1 = 1 + [int]$cnts[$c1]; $cnts[$c1] = $v1; if ($v1 -gt $top) { $top = $v1 } }
        if ($top -ge 3 -and ($top / [double]$core.Length) -ge 0.7) { return $false }
    }
    $known = $script:Dict.ContainsKey((Get-NormKey $t))
    if ($known) { return $true }
    # one stray character beside a run of digits / letters (a ring or icon next to a value read as '亿0 10C'): a number field, not text
    if ($core.Length -le 1 -and [regex]::Matches($t, '[0-9A-Za-z]').Count -ge 3) { return $false }
    # strokes and boxes that look like characters
    $allLook = $true
    foreach ($ch in $core.ToCharArray()) { if ($script:LookalikeHan.IndexOf($ch) -lt 0) { $allLook = $false; break } }
    if ($core.Length -eq 1 -and $script:SingleOk.IndexOf($core) -ge 0) { return $true }
    if ($allLook -and $core.Length -le 3) { return $false }
    if ($core.Length -eq 1 -and $letters -le 2) { return $false }       # a lone unknown character is an icon (known UI characters returned above)
    return $true
}
# ---------- ghost readings ----------
# Busy pictures (shadows, road markings, hair, fabric) are sometimes read by the OCR as a few Chinese characters mixed with
# junk. The game's own text never contains keyboard symbols, half a pair of brackets, or a lone "0" / stroke-letter wedged
# between Chinese characters - such readings are scored and either dropped (score 2+) or held back until read again (score 1).
$script:GhostMemo = New-Object System.Collections.Hashtable
function Get-GhostScore([string]$t) {
    if ([string]::IsNullOrEmpty($t)) { return 0 }
    $gv = $script:GhostMemo[$t]
    if ($null -ne $gv) { return [int]$gv }
    $sc = 2 * [regex]::Matches($t, '[@#$%^&*_|\\~=+<>`{}\[\]]').Count                             # keyboard / technical symbols
    foreach ($pr in @(@('《', '》'), @('「', '」'), @('（', '）'), @('【', '】'), @('『', '』'), @('“', '”'))) {
        if ($t.Split($pr[0]).Count -ne $t.Split($pr[1]).Count) { $sc++ }                          # a bracket / quote opened or closed without its partner
    }
    $sc += [regex]::Matches($t, '(?<![0-9０-９][\s]?)(?<=[一-鿿]\s?)[0Oo０](?=\s?[一-鿿])').Count   # a ring / circle read as a lone zero
    $sc += [regex]::Matches($t, '(?<=[一-鿿]\s?)[a-zIl](?=\s?[一-鿿])').Count                       # a stroke read as a lone small letter
    $sc += [regex]::Matches($t, '(?<=[一-鿿])\s?[\.,''`]\s?(?=[一-鿿])').Count                      # specks read as western dots / ticks inside Chinese
    if ($script:GhostMemo.Count -gt 4000) { $script:GhostMemo.Clear() }
    $script:GhostMemo[$t] = $sc
    return $sc
}
function Test-OfficialText([string]$t) { if ($script:Dict.ContainsKey((Get-NormKey $t))) { return $true }; return ($null -ne (Translate-Local ([string]$t).Trim())) }      # the game's own strings, including numbered titles such as 第1赛季 / 第三章
function Test-Cjk([string]$t) {
    if ([string]::IsNullOrWhiteSpace($t)) { return $false }
    return [regex]::IsMatch($t, '[\u4e00-\u9fff]')
}
function Translate-One([string]$text) {
    $q = [uri]::EscapeDataString($text)
    $urls = @(
        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=en&dt=t&dj=1&q=$q",
        "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=zh-CN&tl=en&dt=t&q=$q"
    )
    foreach ($url in $urls) {
        try {
            $resp = Invoke-RestMethod -Uri $url -Headers @{ 'User-Agent' = 'Mozilla/5.0' } -TimeoutSec 10
            $parts = New-Object System.Collections.Generic.List[string]
            if ($resp.sentences) {
                foreach ($s in @($resp.sentences)) { if ($s.trans) { [void]$parts.Add([string]$s.trans) } }
            } else {
                foreach ($seg in @($resp[0])) { if ($seg -and $seg[0]) { [void]$parts.Add([string]$seg[0]) } }
            }
            $dst = [string]::Join('', $parts.ToArray())
            if ($dst -and -not (Test-Cjk $dst)) { return $dst }
            if ($dst -and $dst -ne $text) { return $dst }
        } catch { Write-Log "google: $($_.Exception.Message)" }
    }
    try {
        $body = '[{"Text":"' + (($text -replace '\\','\\\\' -replace '"','\"' -replace "`r",'' -replace "`n",'\n')) + '"}]'
        $resp = Invoke-RestMethod -Uri 'https://edge.microsoft.com/translate/translatetext?from=zh-Hans&to=en&api-version=3.0' -Method Post -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -ContentType 'application/json; charset=utf-8' -Headers @{ 'User-Agent' = 'Mozilla/5.0' } -TimeoutSec 10
        $dst = [string]$resp[0].translations[0].text
        if ($dst) { return $dst }
    } catch { Write-Log "edge: $($_.Exception.Message)" }
    return $text
}
# ---------- v2: game dictionary + glossary + non-blocking translation ----------
Add-Type -AssemblyName System.Net.Http
try { [System.Net.ServicePointManager]::DefaultConnectionLimit = 16; [System.Net.ServicePointManager]::Expect100Continue = $false; [System.Net.ServicePointManager]::UseNagleAlgorithm = $false; [System.Net.ServicePointManager]::SecurityProtocol = ([System.Net.ServicePointManager]::SecurityProtocol -bor 3072) } catch {}
$script:Http = New-Object System.Net.Http.HttpClient
$script:Http.Timeout = [TimeSpan]::FromSeconds(6)
try { $script:Http.DefaultRequestHeaders.Add('User-Agent', 'Mozilla/5.0') } catch {}
# Translation services, tried in this order; a service that refuses (429 / errors) is rested for a while and the next one is used
$script:RouteNames = @('Microsoft', 'Google', 'Google 2', 'Lingva 1', 'Lingva 2', 'MyMemory')
$script:RouteN = $script:RouteNames.Count
$script:RouteUntil = New-Object 'int64[]' $script:RouteN
$script:RouteLogged = New-Object 'bool[]' $script:RouteN
$script:MsOk = $false
$script:MsParseTask = $null; $script:MsParseArr = $null
try {
    Add-Type -ReferencedAssemblies ([System.Net.Http.HttpClient].Assembly.Location) -ErrorAction Stop -TypeDefinition @'
using System;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
public static class StarMs {
    const string UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0";
    static string Js(string s) {
        StringBuilder b = new StringBuilder("\"");
        foreach (char c in s) {
            if (c == '"') b.Append("\\\"");
            else if (c == '\\') b.Append("\\\\");
            else if (c < 32) b.Append("\\u").Append(((int)c).ToString("x4"));
            else b.Append(c);
        }
        return b.Append('"').ToString();
    }
    // Edge's free web-page translator: many texts in one request, one answer per text in the same order
    public static async Task<string> TrMany(HttpClient c, string[] texts) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < texts.Length; i++) { if (i > 0) sb.Append(','); sb.Append(Js(texts[i] ?? "")); }
        sb.Append(']');
        HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, "https://edge.microsoft.com/translate/translatetext?from=zh-Hans&to=en&isEnterpriseClient=false");
        req.Headers.TryAddWithoutValidation("User-Agent", UA);
        req.Content = new StringContent(sb.ToString(), Encoding.UTF8, "application/json");
        HttpResponseMessage resp = await c.SendAsync(req).ConfigureAwait(false);
        string body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);
        if (!resp.IsSuccessStatusCode) throw new HttpRequestException("Microsoft " + ((int)resp.StatusCode).ToString() + " " + resp.ReasonPhrase);
        return body;
    }
}
'@
    $script:MsOk = $true
} catch { Write-Log ('microsoft translator unavailable: ' + $_.Exception.Message) }
function Start-Req($ent) {
    return $script:Http.GetStringAsync([string]$ent.url)
}
$script:Pending = @{}
$script:FailedAt = @{}
$script:NeedRedraw = $false
$script:DictHits = 0
$script:ContrastPass = $true
$script:ScanN = 0

$script:NormMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal)
function Get-NormKey([string]$t) {
    if ([string]::IsNullOrEmpty($t)) { return '' }
    $nm = $script:NormMemo[$t]
    if ($null -ne $nm) { return $nm }
    if ($script:NormMemo.Count -gt 4000) { $script:NormMemo.Clear() }
    $nm = Get-NormKey0 $t
    $script:NormMemo[$t] = $nm
    return $nm
}
function Get-NormKey0([string]$t) {
    $t = [regex]::Replace($t, '<[^>]+>', '')
    # keep only letters/digits (incl. CJK): bullets, arrows, OCR noise and punctuation never block a match
    return [regex]::Replace($t, '[^\p{L}\p{N}]', '')
}
$script:FuzzyBuckets = $null; $script:FuzzyCount = -1; $script:FuzzyCache = @{}
function Get-FuzzyHit([string]$nk) {
    if ($script:FuzzyCache.ContainsKey($nk)) { return $script:FuzzyCache[$nk] }
    if ($script:FuzzyCount -ne $script:Dict.Count) {
        $script:FuzzyBuckets = @{}
        foreach ($dk in $script:Dict.Keys) {
            $L = $dk.Length
            if ($L -lt 4 -or $L -gt 11 -or $dk -match '\d') { continue }
            if (-not $script:FuzzyBuckets.ContainsKey($L)) { $script:FuzzyBuckets[$L] = New-Object System.Collections.Generic.List[string] }
            $script:FuzzyBuckets[$L].Add($dk)
        }
        $script:FuzzyCount = $script:Dict.Count
        $script:FuzzyCache = @{}
    }
    $hit = $null; $n = 0
    foreach ($L in @(($nk.Length - 1), $nk.Length, ($nk.Length + 1))) {
        if (-not $script:FuzzyBuckets.ContainsKey($L)) { continue }
        foreach ($dk in $script:FuzzyBuckets[$L]) {
            if ([StarContrast]::Within1($nk, $dk)) { $hit = $dk; $n++; if ($n -gt 1) { break } }
        }
        if ($n -gt 1) { break }
    }
    $res = $null
    if ($n -eq 1) { $res = $script:Dict[$hit] }      # only when exactly one dictionary entry is that close
    if ($script:FuzzyCache.Count -gt 3000) { $script:FuzzyCache = @{} }
    $script:FuzzyCache[$nk] = $res
    return $res
}
$script:Dict = @{}
$script:Glossary = New-Object System.Collections.Generic.List[object]
function Load-Dictionaries {
    $dp = Join-Path $script:DataDir 'dictionary.tsv'
    if (Test-Path $dp) {
        try {
            foreach ($ln in [System.IO.File]::ReadAllLines($dp, [System.Text.Encoding]::UTF8)) {
                $i = $ln.IndexOf("`t"); if ($i -lt 1) { continue }
                $cn = $ln.Substring(0, $i).Replace('\n', "`n").Replace('\t', "`t")
                $en = $ln.Substring($i + 1).Replace('\n', "`n").Replace('\t', "`t")
                if ($en -match '\{[^}]*\}') { continue }
                $k = Get-NormKey $cn
                if ($k.Length -ge 2 -and -not $script:Dict.ContainsKey($k)) { $script:Dict[$k] = ($en -replace '<[^>]+>', '') }
            }
        } catch { Write-Log "dict: $_" }
    }
    $gp = Join-Path $script:DataDir 'glossary.csv'
    $builtin = @'
cn,en
异人,Hidden Ones
异人之下,Under the Strange (The Hidden Ones)
炁,Qi (炁)
炁局,Qi Arena
法器,Artifact
法器仓库,Artifact Storage
三坛神将,Three-Altar Divine Generals
卷地风来,Wind Sweeps the Ground
天女散花,Heavenly Maiden Scatters Flowers
金光覆映,Golden Light Overlay
万海归寂,Ten Thousand Seas Return to Silence
两仪协斗,Liangyi Joint Battle
演武大赛,Martial Arts Tournament
身外身,Doppelganger
分身,Doppelganger
幻影,Phantom
化身,Avatar
张灵玉,Zhang Lingyu
洪文斌,Hong Wenbin
李高峰,Li Gaofeng
保存,Save
描述,Description
通关总时长,Total Clear Time
匹配对手中,Matching opponent...
再来一杯,Another Round
麦克风权限说明,Microphone Permission Notice
该玩法主题未解锁。,This game mode theme is not yet unlocked.
内容太简略啦，请详细描述,Too brief! Please describe in more detail.
震字·落雷,Zhen Sigil: Falling Thunder
巽字·风绳,Xun Sigil: Wind Rope
八门搬运·瞬形,Eight Gates Shift: Instant Form
剩余敌人数量:{diren}/13,Enemies Remaining: {diren}/13
冯宝宝,Feng Baobao
张楚岚,Zhang Chulan
王也,Wang Ye
诸葛青,Zhuge Qing
夏禾,Xia He
吕良,Lu Liang
张锡林,Zhang Xilin
张怀义,Zhang Huaiyi
陆玲珑,Lu Linglong
马仙洪,Ma Xianhong
风星潼,Feng Xingtong
张之维,Zhang Zhiwei
全性,Quanxing
哪都通,Nadutong
龙虎山,Mount Longhu
天师府,Celestial Masters' Mansion
八奇技,Eight Secret Arts
甲申之乱,Jiashen Rebellion
双全手,Double-Perfect Hands
风后奇门,Fenghou Qimen
神明灵,Divine Spirit Art
金光咒,Golden Light Mantra
三十六贼,Thirty-Six Thieves
罗天大醮,Luotian Grand Ritual
炁体源流,Qi Body Origin
睚眦,Yazi
霸下,Bixi
蒲牢,Pulao
狻猊,Suanni
囚牛,Qiuniu
嘲风,Chaofeng
阳雷,Yang Thunder
阴雷,Yin Thunder
雷蚀,Thunder Erosion
炁刃,Qi Blade
迅雷模式,Thunderbolt Mode
阴阳调和,Yin-Yang Harmony
主动援助技,Active Assist Skill
被动援助技,Passive Assist Skill
极限闪避,Perfect Dodge
普通攻击,Basic Attack
强制脱出,Break Away
强制取消,Forced Cancel
游云步,Drifting Cloud Step
云步游踪,Cloud Step Trail
八门残影,Eight Gates Afterimage
五雷符,Five-Thunder Talisman
垫步追击,Skip-Step Pursuit
双劲相催,Twin Force Surge
二门流火,Second Gate: Flowing Fire
快刀斩乱麻,Swift Blade Cuts the Knot
猛虎硬敲山,Mighty Tiger Strikes the Mountain
金海擒龙,Golden Sea Dragon Capture
苍潭,Azure Pool
暴风压制,Storm Suppression
我已发送招募邀请,I have sent a recruitment invite
迎推刺,Greeting Push Thrust
玉兔蹬山,Jade Rabbit Kicks the Mountain
游蚓攫魂,Wandering Worm Soul Snatch
破片手雷,Frag Grenade
战术压制进度,Tactical Suppression Progress
瑶光覆映,Alkaid Overlay
金光增益,Golden Light Buff
回沙踏,Sand-Return Stomp
黑火雷,Black Fire Thunder
通天箓,Heaven-Reaching Register
绝影幻刃,Shadowless Phantom Blade
阳雷贯体,Yang Thunder Pierce
阳雷天降,Yang Thunder Descent
尸气爆发,Corpse Qi Burst
遁地麒麟,Earth-Burrowing Qilin
哐哐锤,Clang Hammer
麒麟探力,Qilin Force Probe
海底捞月,Fishing the Moon from the Sea
三方战斗,Three-Way Battle
八神力·九地,Eight Divine Powers: Nine Earths
斗盈周天,Dou Ying Celestial Cycle
金光覆体,Golden Light Shroud
电光追斩,Lightning Pursuit Slash
浮固十字固,Floating Cross Lock
飞鹞击云,Hawk Strikes the Clouds
青龙探首,Azure Dragon Lowers Its Head
百相测试,Hundred Forms Test
强化术法,Enhance Technique
爆破预备,Blast Ready
金光印记,Golden Light Mark
玄澒诀,Mysterious Mercury Art
蝎子甩尾,Scorpion Tail Whip
探索哪都通,Explore Nadutong
炁化三玄,Qi Transforms the Three Mysteries
超级疾走兔爷,Super Dashing Rabbit Lord
疾走兔爷,Dashing Rabbit Lord
怒雷万钧,Wrathful Thunder
蛊毒爆发,Gu Poison Burst
逆势突围,Breakout Against the Odds
猛龙过江,Mighty Dragon Crosses the River
贪狼灭形,Greedy Wolf Annihilation
鬼哭神嚎,Ghosts Wail and Gods Howl
虎啸金弧,Tiger Roar Golden Arc
超级哐哐锤,Super Clang Hammer
超级哔哔枪,Super Bibi Gun
哔哔枪,Bibi Gun
游龙入海,Dragon Enters the Sea
赤弋流星,Crimson Meteor
凤穿花,Phoenix Through Flowers
哭坟状态,Graveside Wail State
极速连斩,Rapid Slash Chain
飞身十字固,Flying Cross Lock
金针入地,Golden Needle into Earth
踏石锤山,Stone-Stomp Mountain Hammer
麒麟飞踢,Qilin Flying Kick
月落西海,Moon Sets in the Western Sea
飞花穿掌,Flying Flower Palm
支线关,Side Stage
单兵突围,Lone Breakout
金光拳风,Golden Light Fist Wind
雷池覆海,Thunder Pool Overturns the Sea
火性失和,Fire Nature Disharmony
终极试炼,Ultimate Trial
鱼龙舞,Fish-Dragon Dance
野马分鬃,Wild Horse Parts the Mane
灵蛇吐信,Spirit Snake Flicks Its Tongue
阳五雷·掌心雷,Yang Five Thunders: Palm Thunder
阴五雷·掌心雷,Yin Five Thunders: Palm Thunder
追风逐月,Chase Wind and Moon
武道值,Martial Dao Points
金光护体,Golden Light Guard
开山一击,Mountain-Splitting Strike
战意昂扬,Soaring Fighting Spirit
蒲牢振音,Pulao Resonance
天降祥麟,Auspicious Qilin Descends
九地承锋,Nine Earths Receive the Edge
文曲天裁,Wenqu Heavenly Verdict
台星应变,Taixing Adaptation
推云踏浪,Push Clouds Tread Waves
踏破苍穹,Stomp the Firmament
翻江走海,Overturn Rivers Race Seas
拘灵遣将,Bind Spirits Dispatch Generals
龙纽白玉印,Dragon-Knob White Jade Seal
清代龙虎道袍,Qing Dynasty Dragon-Tiger Daoist Robe
罗氏张天师像轴,Luo's Celestial Master Zhang Portrait Scroll
缺角魔方,Corner-Missing Rubik's Cube
微波炉盘子,Microwave Plate
铁骑啸山林图,Iron Cavalry Roars Through Mountains Painting
签名桃木剑,Signed Peachwood Sword
玉衡流火,Yuheng Flowing Fire
天玑燎原,Tianji Prairie Fire
金光重拳,Golden Light Heavy Punch
逆生三重,Reverse Growth Triple
传度日,Ordination Day
险招,Sinister Skill
终局会武大赛,Endgame Martial Tournament
觅宝之路,Treasure Hunt Road
碎石裂碑,Rock-Splitting Stele Smash
迷魂引路,Soul-Luring Path
魂归九泉,Soul Returns to the Nine Springs
神魂颠倒,Spirit Reversal
太冲震恚,Taichong Wrathful Quake
穿云拍案,Cloud-Piercing Table Slam
云手崩拳,Cloud Hands Crushing Fist
八门搬运,Eight Gates Shift
代掌门,Acting Sect Leader
即时概率,Live Odds
炼器效果,Forging Effect
百宝袋,Treasure Pouch
符券,Talisman Voucher
隐私保护指引,Privacy Policy Guide
天下会武,Martial Tournament
迎门顶肘,Door-Greeting Elbow
金刚捣碓,Vajra Pounds the Mortar
天枢镇岳,Tianshu Mountain Suppression
崩旋,Burst Spin
繁花,Blossoms
千蝶,Thousand Butterflies
玄鳞游,Dark Scale Swim
棍花,Staff Flourish
血飨,Blood Feast
'@
    if ($true) {
        try {
            $rows = @()
            if (Test-Path $gp) { $rows += @(Import-Csv -Path $gp -Encoding UTF8) }
            $rows += @(ConvertFrom-Csv $builtin)
            $rows = $rows | Where-Object { $_.cn -and $_.en -and $_.cn -notmatch '[{}]' }
            foreach ($r in ($rows | Sort-Object { $_.cn.Length } -Descending)) { $script:Glossary.Add(@{ cn = [string]$r.cn; en = [string]$r.en }) | Out-Null }
        } catch { Write-Log "glossary: $_" }
    }
    try {
        $uiCsv = @'
cn,en
暴击率,Crit Rate
暴击伤害,Crit Damage
破势能力,Momentum Break
破势能力加成,Momentum Break Bonus
破势,Momentum Break
破势值,Momentum Break Value
破防率,Defense Break Rate
生命,Life
攻击,Attack
防御,Defense
技能,Skills
总览,Overview
概览,Overview
佩玉,Jade Pendant
玉佩,Jade Pendant
法器,Artifact
登阶,Ascension
突破,Breakthrough
外观,Appearance
时装,Outfit
全屏,Full Screen
全部,All
主页,Main Page
主界面,Main Menu
说明,Info
援助,Assist
援助技,Assist Skill
谋略,Strategy
异人,Hidden One
异人试炼,Hidden One Trial
试炼之路,Trial Road
试炼,Trial
异人命稿,Hidden One Manuscript
筛选,Filter
等级,Level
年龄,Age
确认,Confirm
取消,Cancel
返回,Back
保存,Save
设置,Settings
商店,Shop
任务,Quests
背包,Inventory
招募,Recruit
炁局,Qi Arena
炁局商店,Qi Arena Shop
法器仓库,Artifact Storage
演武大赛,Martial Arts Tournament
身外身,Doppelganger
分身,Doppelganger
幻影,Phantom
化身,Avatar
张楚岚,Zhang Chulan
冯宝宝,Feng Baobao
诸葛青,Zhuge Qing
王也,Wang Ye
'@
        foreach ($r in (ConvertFrom-Csv $uiCsv)) { $k = Get-NormKey $r.cn; if ($k.Length -ge 1) { $script:Dict[$k] = [string]$r.en } }
    } catch { Write-Log "builtin dict: $_" }
    try {
        $shortTsv = @'
阵容方案	Lineup Presets
战斗录像	Battle Replays
切磋排行	Leaderboard
永久限购	Permanent purchase limit
赛季限购	Season purchase limit
已售罄	Sold out
玩法奖励	Mode Rewards
新人解锁	Newcomer Unlocks
新手解锁	Newcomer Unlocks
初露	Dew
初露1阶	Dew I
初露1	Dew I
初露2阶	Dew II
初露2	Dew II
初露3阶	Dew III
初露3	Dew III
初露一	Dew I
初露二	Dew II
初露三	Dew III
三涧	Three Streams
三涧1阶	Three Streams I
三涧1	Three Streams I
三涧2阶	Three Streams II
三涧2	Three Streams II
三涧3阶	Three Streams III
三涧3	Three Streams III
三涧一	Three Streams I
三涧二	Three Streams II
三涧三	Three Streams III
六泽	Six Marshes
六泽1阶	Six Marshes I
六泽1	Six Marshes I
六泽2阶	Six Marshes II
六泽2	Six Marshes II
六泽3阶	Six Marshes III
六泽3	Six Marshes III
六泽一	Six Marshes I
六泽二	Six Marshes II
六泽三	Six Marshes III
九曲	Nine Bends
九曲1阶	Nine Bends I
九曲1	Nine Bends I
九曲2阶	Nine Bends II
九曲2	Nine Bends II
九曲3阶	Nine Bends III
九曲3	Nine Bends III
九曲一	Nine Bends I
九曲二	Nine Bends II
九曲三	Nine Bends III
百川	Hundred Rivers
百川1阶	Hundred Rivers I
百川1	Hundred Rivers I
百川2阶	Hundred Rivers II
百川2	Hundred Rivers II
百川3阶	Hundred Rivers III
百川3	Hundred Rivers III
百川一	Hundred Rivers I
百川二	Hundred Rivers II
百川三	Hundred Rivers III
千泷	Thousand Torrents
千泷1阶	Thousand Torrents I
千泷1	Thousand Torrents I
千泷2阶	Thousand Torrents II
千泷2	Thousand Torrents II
千泷3阶	Thousand Torrents III
千泷3	Thousand Torrents III
千泷一	Thousand Torrents I
千泷二	Thousand Torrents II
千泷三	Thousand Torrents III
万渊	Ten-Thousand Depths
万渊1阶	Ten-Thousand Depths I
万渊1	Ten-Thousand Depths I
万渊2阶	Ten-Thousand Depths II
万渊2	Ten-Thousand Depths II
万渊3阶	Ten-Thousand Depths III
万渊3	Ten-Thousand Depths III
万渊一	Ten-Thousand Depths I
万渊二	Ten-Thousand Depths II
万渊三	Ten-Thousand Depths III
初隅	Corner
初隅1阶	Corner I
初隅1	Corner I
初隅2阶	Corner II
初隅2	Corner II
初隅3阶	Corner III
初隅3	Corner III
初隅一	Corner I
初隅二	Corner II
初隅三	Corner III
三庭	Three Courts
三庭1阶	Three Courts I
三庭1	Three Courts I
三庭2阶	Three Courts II
三庭2	Three Courts II
三庭3阶	Three Courts III
三庭3	Three Courts III
三庭一	Three Courts I
三庭二	Three Courts II
三庭三	Three Courts III
六苑	Six Gardens
六苑1阶	Six Gardens I
六苑1	Six Gardens I
六苑2阶	Six Gardens II
六苑2	Six Gardens II
六苑3阶	Six Gardens III
六苑3	Six Gardens III
六苑一	Six Gardens I
六苑二	Six Gardens II
六苑三	Six Gardens III
九陌	Nine Roads
九陌1阶	Nine Roads I
九陌1	Nine Roads I
九陌2阶	Nine Roads II
九陌2	Nine Roads II
九陌3阶	Nine Roads III
九陌3	Nine Roads III
九陌一	Nine Roads I
九陌二	Nine Roads II
九陌三	Nine Roads III
百国	Hundred Realms
百国1阶	Hundred Realms I
百国1	Hundred Realms I
百国2阶	Hundred Realms II
百国2	Hundred Realms II
百国3阶	Hundred Realms III
百国3	Hundred Realms III
百国一	Hundred Realms I
百国二	Hundred Realms II
百国三	Hundred Realms III
千境	Thousand Domains
千境1阶	Thousand Domains I
千境1	Thousand Domains I
千境2阶	Thousand Domains II
千境2	Thousand Domains II
千境3阶	Thousand Domains III
千境3	Thousand Domains III
千境一	Thousand Domains I
千境二	Thousand Domains II
千境三	Thousand Domains III
万界	Ten-Thousand Worlds
万界1阶	Ten-Thousand Worlds I
万界1	Ten-Thousand Worlds I
万界2阶	Ten-Thousand Worlds II
万界2	Ten-Thousand Worlds II
万界3阶	Ten-Thousand Worlds III
万界3	Ten-Thousand Worlds III
万界一	Ten-Thousand Worlds I
万界二	Ten-Thousand Worlds II
万界三	Ten-Thousand Worlds III
浩海	Vast Sea
太虚	Grand Void
初晓	First Light
初学	Novice
入门	Initiate
熟手	Skilled
通彻	Thorough
得真	True Grasp
如意	Effortless
入神	Transcendent
天成	Perfected
凡人歌·承	Song of Mortals: Continuation
凡人歌·绽	Song of Mortals: Bloom
凡人歌·归	Song of Mortals: Return
长歌	Long Song
烬歌	Ember Song
丹歌惊鸿	Cinnabar Song Startled Swan
歌单	Playlist
新建歌单	New Playlist
应用歌单	Apply Playlist
加入歌单	Add to Playlist
胜利专属歌单	Victory Playlist
段位奖励	Rank Rewards
段位	Rank
异人突破·金	Hidden One Breakthrough: Metal
法器突破·金	Artifact Breakthrough: Metal
异人武学·金	Hidden One Martial Arts: Metal
异人突破·木	Hidden One Breakthrough: Wood
法器突破·木	Artifact Breakthrough: Wood
异人武学·木	Hidden One Martial Arts: Wood
异人突破·水	Hidden One Breakthrough: Water
法器突破·水	Artifact Breakthrough: Water
异人武学·水	Hidden One Martial Arts: Water
异人突破·火	Hidden One Breakthrough: Fire
法器突破·火	Artifact Breakthrough: Fire
异人武学·火	Hidden One Martial Arts: Fire
异人突破·土	Hidden One Breakthrough: Earth
法器突破·土	Artifact Breakthrough: Earth
异人武学·土	Hidden One Martial Arts: Earth
冯宝宝援助技	Feng Baobao Assist Skill
呼唤队友换手	Call Teammate to Tag In
平招	Normal Move
单体输出	Single-Target Damage
群体输出	AoE Damage
控制型	Control
羁绊	Bond
防御型	Defense
爆发输出	Burst Damage
增益型	Support
持续输出	Sustained Damage
切磋段位奖励	Sparring Rank Rewards
切磋胜场奖励	Sparring Win Rewards
尘途百炼备战	Dusty Road Training Prep
特辑商店	Collection Shop
娱乐模式总览	Entertainment Modes Overview
赛事报名界面	Tournament Sign-Up
择吉月历	Auspicious Calendar
佩玉兑换	Jade Pendant Exchange
登阶商城	Rank-Up Mall
装束商店	Outfit Shop
活动集合页	Events Hub
异呼百应活动	Rally Event
新人签到活动	Newcomer Check-In Event
七曜之礼活动	Seven Luminaries Gift Event
十方之礼活动	Ten Directions Gift Event
太极宗师	Taichi Grandmaster
异人演练	Hidden One Drills
上新签到	New Arrivals Check-In
陆宅谜局	Lu Residence Puzzle
入世演卦	Divination Entering the World
武器大师	Weapon Master
术法训练	Technique Training
对战狂欢	Battle Carnival
合力讨伐	Joint Subjugation
八门翻翻乐	Eight Gates Flip Game
木桩瞬斩	Dummy Flash Slash
乐斗开启	Brawl Begins
冒险启航	Adventure Begins
初显身手	First Show of Skill
终极挑战	Ultimate Challenge
毒瘴求生	Poison Miasma Survival
绝对火力	Absolute Firepower
青云有道	Azure Cloud Way
脱尘入世	Leaving Dust Entering the World
大显萌威	Cute Might
雷界斗场	Thunder Realm Arena
同生共命	Shared Fate
四方争魁	Four-Way Contest
预创角活动	Pre-Registration Event
高校特权	University Privilege
镇心伏魔	Calm the Heart Subdue Demons
香云引路	Fragrant Cloud Guide
新年小队	New Year Squad
武行收纳	Martial Storage
元宵点灯	Lantern Festival Lighting
共祝新年	Celebrating the New Year
新春迎吉	Spring Festival Fortune
演武大会	Martial Convention
宗师试炼	Grandmaster Trial
拼好花	Flower Puzzle
镜像战场	Mirror Battlefield
竞速猎场	Speed Hunting Ground
红包乱斗	Red Packet Brawl
演武集市	Martial Market
迎福纳吉	Welcome Blessings
演武冲分	Martial Score Rush
阴阳自守	Yin-Yang Self-Guard
八面玲珑	Smooth Operator
一念成魔	One Thought to Demon
新春折扣	Spring Festival Sale
偶遇顶流	Meeting a Superstar
通宝乱斗	Tongbao Brawl
千变法门	Thousand Changes Art
刀锋上新活动	Blade New Arrivals Event
瑞霭上新活动	Auspicious Mist New Arrivals Event
彼岸傀寻臻	Far Shore Puppet Rarity Hunt
随机装束商店	Random Outfit Shop
诸葛青首购礼	Zhuge Qing First Purchase Gift
新人特惠	Newcomer Deal
密室寻凶活动	Secret Room Murder Hunt Event
影尘旧事	Shadows of the Past
物资收集	Supply Collection
冒险等级奖励	Adventure Level Rewards
异能大乱斗	Superpower Brawl
全民赛	Open Tournament
异人专精	Hidden One Mastery
切磋商店	Sparring Shop
罗天醮场	Luotian Ritual Arena
雪夜戏楼	Snowy Night Theater
午后球场	Afternoon Court
洛书武场	Luoshu Martial Ground
碧水渡台	Jade Water Ferry Stage
凡人歌	Song of Mortals
已拥有该装束	You already own this outfit
赛季已结束	Season ended
关卡未解锁	Stage locked
难度未解锁	Difficulty locked
非法请求	Invalid request
奖励已被领取	Reward already claimed
活动已结束	Event ended
暂无公告内容	No announcements
请输入内容	Please enter text
无保存权限	No save permission
分享失败	Share failed
复活失败	Revive failed
不可拾取	Cannot be picked up
无相机权限	No camera permission
该录像已存在	This replay already exists
校验服异常	Verification server error
校验服繁忙	Verification server busy
校验服超时	Verification server timed out
碧游村	Biyou Village
陆家	Lu Family
散人	Free Agent
武当	Wudang
武侯派	Wuhou Sect
主攻	Main Attacker
金性异人	Metal-Nature Hidden One
木性异人	Wood-Nature Hidden One
水性异人	Water-Nature Hidden One
火性异人	Fire-Nature Hidden One
土性异人	Earth-Nature Hidden One
阴性异人	Yin-Nature Hidden One
阳性异人	Yang-Nature Hidden One
防御力加成	Defense Bonus
生命百分比	HP %
攻击百分比	Attack %
防御力百分比	Defense %
失和能力	Disharmony Ability
失和能力加成	Disharmony Ability Bonus
失和精益	Disharmony Mastery
金性伤害提升	Metal Damage Boost
木性伤害提升	Wood Damage Boost
水性伤害提升	Water Damage Boost
火性伤害提升	Fire Damage Boost
土性伤害提升	Earth Damage Boost
未知类型	Unknown Type
基础货币	Basic Currency
商店兑换	Shop Exchange
基础物品	Basic Item
时装配饰	Outfit Accessory
账号头像	Profile Avatar
账号头像框	Avatar Frame
账号名片	Profile Card
账号称号	Profile Title
账号印鉴	Profile Seal
系统音乐	System Music
战斗场景	Battle Stage
胜利音乐	Victory Music
可选礼包	Selectable Pack
随机成品装备	Random Finished Gear
异人专精徽章	Hidden One Mastery Badge
装备物品	Equipment Item
活动道具	Event Item
通行证等级	Pass Level
异人突破材料	Hidden One Breakthrough Material
佩玉升级	Jade Pendant Upgrade
法器突破材料	Artifact Breakthrough Material
法器经验	Artifact EXP
手动自选礼包	Choose-Your-Own Pack
手动礼包	Choice Pack
折扣卡	Discount Card
基础棍式	Basic Staff Form
基础刀式	Basic Blade Form
横斩	Horizontal Slash
炉火重击	Furnace Fire Smash
长舞棍花	Long Staff Flourish
技能材料	Skill Material
无辜	Innocent
惊吓	Startled
得意	Smug
点赞	Thumbs Up
擦汗	Wipe Sweat
偷笑	Snicker
开心	Happy
笑哭	Laugh Cry
你好	Hello
无聊	Bored
困惑	Confused
真棒	Awesome
委屈	Aggrieved
作揖	Bow
凝视	Stare
茄子	Cheese
一般飘过如花	Ru Hua Floats By
突然出现	Sudden Appearance
干得漂亮	Well Done
来搞事吧	Let's Stir Up Trouble
承让承让	You Flatter Me
鬼鬼祟祟	Sneaking
我得意的笑	My Smug Laugh
打完收工	Done Fighting Time to Clock Out
死亡一指	Deadly Finger
你瞅啥	What Are You Looking At
要优雅	Stay Elegant
烧起来了	It's On Fire
发型不能乱	Mind the Hair
就是如此丝滑	Smooth as Silk
过两招	Spar a Few Moves
武德充沛	Full of Martial Virtue
器多不压身	Many Tools No Burden
晴天霹雳	Bolt from the Blue
无语	Speechless
水逆退散	Begone Bad Luck
大锤八十	Hammer Eighty
喝彩	Cheer
鼓励	Encourage
调侃	Tease
申请下场	Request Tag Out
让我继续作战	Let Me Keep Fighting
我不能上场	I Can't Go In
申请出战	Request to Fight
你还是太慢咯	You're Still Too Slow
你还是太急了	You're Too Hasty
你莫慌嘞	Don't Panic
第六阶段	Stage 6
第七阶段	Stage 7
第八阶段	Stage 8
第九阶段	Stage 9
第十阶段	Stage 10
第十一阶段	Stage 11
第十二阶段	Stage 12
炼锋	Tempered Edge
蔓刃	Creeping Blade
寒渊	Frost Abyss
赤炎	Crimson Flame
镇岳	Mountain Guard
破窍	Orifice Breaker
蚀脉	Meridian Erosion
乱神	Spirit Havoc
震魄	Soul Quake
摧元	Vital Shatter
实力冲榜	Climb the Rankings
活跃拉满	Max Activity
切磋高玩	Sparring Expert
资深大佬	Veteran
聊天吹水	Chatty
广结善缘	Friendly
新手友好	Newbie Friendly
互帮互助	Mutual Help
团员	Member
会长	President
任务奖励补发	Quest Reward Reissue
周结算奖励	Weekly Settlement Rewards
重置头像说明	Avatar Reset Notice
重置昵称说明	Nickname Reset Notice
举报受理说明	Report Received Notice
举报核实通知	Report Verified Notice
道具领取通知	Item Claim Notice
赛季奖励补发	Season Reward Reissue
惊喜折扣返利	Surprise Discount Rebate
充值返还邮件	Top-Up Refund Mail
旗开得胜	Victory at First Strike
四人混战	4-Player Brawl
海选赛	Qualifiers
五人混战	5-Player Brawl
大吉	Great Fortune
中吉	Good Fortune
小吉	Minor Fortune
精简资源	Lite Resources
活动资源包	Event Resource Pack
视频质量包	Video Quality Pack
核心资源包	Core Resource Pack
冒险第二章	Adventure Chapter 2
冒险第三章	Adventure Chapter 3
冒险其他玩法	Other Adventure Modes
切磋资源包	Sparring Resource Pack
核心资源	Core Resources
装束资源	Outfit Resources
活动资源	Event Resources
画质资源	Graphics Resources
养成目标	Growth Goals
佩玉经验	Jade Pendant EXP
周期试炼	Cycle Trial
基础投技	Basic Throw
垫步	Skip Step
反击的反击	Counter to Counter
势均力敌	Evenly Matched
撞墙反弹	Wall Bounce
双重压制	Double Suppression
垫步的技巧	Skip Step Technique
新增教学关	New Tutorial Stage
摸金玩法	Treasure Raiding
更新版本可见	Visible After Update
废弃道具	Deprecated Item
化身币	Avatar Coin
行动特许	Action Permit
清道夫夺宝券	Scavenger Treasure Ticket
彼岸傀寻臻券	Far Shore Puppet Hunt Ticket
彼岸傀宝契	Far Shore Puppet Treasure Contract
祈福签文	Blessing Slip
佩玉精粹	Jade Pendant Essence
佩玉晶萃	Jade Pendant Crystal
改名卡	Rename Card
行动力补给	Action Point Refill
特辑经验	Collection EXP
历练心得	Experience Notes
再战币	Rematch Coin
修身手札	Self-Cultivation Notes
修身要记	Self-Cultivation Essentials
修身秘传	Self-Cultivation Secrets
经验真经	EXP Scripture
金鳞月卡	Golden Scale Monthly Card
银鲤月卡	Silver Carp Monthly Card
切磋特辑	Sparring Collection
冒险特辑	Adventure Collection
薛幡	Xue Fan
巴伦	Baron
苑陶	Yuan Tao
憨蛋儿	Hancock
诸葛观	Zhuge Guan
诸葛升	Zhuge Sheng
荣山	Rong Shan
凌九	Ling Jiu
陆瑾	Lu Jin
如花	Ru Hua
田晋中	Tian Jinzhong
徐三	Xu San
徐四	Xu Si
夏柳青	Xia Liuqing
杜哥	Brother Du
徐翔	Xu Xiang
祁五	Qi Wu
莫白	Mo Bai
王蔼	Wang Ai
吕慈	Lu Ci
卞旻	Bian Min
郑孟平	Zheng Mengping
诸葛萌	Zhuge Meng
赵小美	Zhao Xiaomei
陈大彪	Chen Dabiao
狗娃子	Gouwazi
钟强	Zhong Qiang
史昆	Shi Kun
何西	He Xi
刀疤	Scarface
柳妍妍	Liu Yanyan
回炁	Qi Recovery
耗炁	Qi Cost
冷却	Cooldown
冷却时间	Cooldown
伤害	Damage
消耗	Cost
锁敌模式	Lock-On Mode
总通宝	Total Tongbao
通宝	Tongbao
炁局通宝	Qi Arena Tongbao
匹配时间	Match Time
登阶卡	Rank-Up Card
房间编号	Room Number
用于异人	Used for Hidden Ones
第一赛季	Season 1
周限购	Weekly Limit
折扣限购	Discount Limit
排名	Rank
积分	Points
剩余时间	Time Left
本局试题	This Round's Question
机制教学	Mechanics Tutorial
长按	Hold
短按	Tap
事业	Career
健康	Health
财富	Wealth
感情	Romance
人际	Relationships
四件套	4-Piece Set
可佩戴	Wearable
实力要求	Power Requirement
持有数量	Owned
完成进度	Progress
关键敌情	Key Enemy Intel
难度	Difficulty
提示	Hint
练习异人	Practice Hidden One
击败	Defeat
乱金柝	Chaos Gold Clapper
迅雷之形	Form of Swift Thunder
神机如花阵	Divine Mechanism Blossom Array
水银泻地	Mercury Spills on the Ground
不摇碧莲	Unshaken Jade Lotus
怒夫三拳	Wrathful Triple Fists
锤砰砰	Thump-Thump Hammer
九地之力	Power of the Nine Earths
氓魂	Rogue Soul
念力搬运	Telekinetic Shift
阴雷遮蔽	Yin Thunder Shroud
金币重击	Gold Coin Smash
隐身符	Invisibility Talisman
热毒镖	Heat-Poison Dart
寒毒镖	Cold-Poison Dart
撼地追雀	Earth-Shaking Sparrow Chase
天王托塔	Heavenly King Holds the Pagoda
幻身一刺	Phantom Body Thrust
净心咒	Heart-Purifying Mantra
五雷镇秽	Five Thunders Suppress Filth
螭吻	Chiwen
金光遏煞	Golden Light Quells Evil
蛇仙出洞	Snake Immortal Leaves the Den
傀儡索命	Puppet's Life Claim
进步搬拦捶	Step-Forward Deflect-Parry Punch
后旋斩	Back-Spin Slash
链锯斩	Chainsaw Slash
尸蛊封禁	Corpse Gu Seal
一炮双响	Double Boom
磁场展开	Magnetic Field Deploy
斩仙飞刀	Immortal-Slaying Flying Knife
输血	Blood Transfusion
克隆	Clone
向队友输血	Transfuse Blood to Teammate
复制队友增益	Copy Teammate Buff
炁局已解锁	Qi Arena Unlocked
奖励待领取	Reward Ready to Claim
术法值待领取	Technique Points Ready to Claim
新关卡待挑战	New Stage Available
新武器解锁	New Weapon Unlocked
新主线剧情	New Main Story
新剧情已解锁	New Story Unlocked
新事件已解锁	New Event Unlocked
双人匹配对战	2-Player Matched Battle
三人匹配对战	3-Player Matched Battle
领取纪念卡	Claim Commemorative Card
全新特辑	New Collection
新冒险玩法	New Adventure Mode
赛季商店上新	Season Shop New Arrivals
海选报名中	Qualifier Sign-Up Open
海选赛进行中	Qualifiers In Progress
赛事直播中	Tournament Live
风起季	Rising Wind Season
风起	Rising Wind
赛季限定寻臻	Season-Limited Rarity Hunt
娱乐玩法	Entertainment Modes
热斗开场	Hot Brawl Opening
修改账号名称	Change Account Name
提升异人等级	Raise Hidden One Level
提升法器等级	Raise Artifact Level
提升技能等级	Raise Skill Level
提升佩玉等级	Raise Jade Pendant Level
初始角色	Starting Character
尚未获得佩玉	Jade Pendant not owned
尚未获得法器	Artifact not owned
感谢惠顾	Thank You for Playing
胜利动作	Victory Pose
回合胜利	Round Victory
终局胜利	Final Victory
绝技制胜	Victory by Ultimate Skill
音效表现	Sound Effects
常驻特效	Permanent Effect
异人边框	Hidden One Frame
命稿表现	Manuscript Display
战斗表现	Combat Display
特殊海报	Special Poster
装束造型	Outfit Style
语音彩蛋	Voice Easter Egg
前腰饰	Front Waist Accessory
后腰饰	Back Waist Accessory
肩部	Shoulders
头部	Head
主体	Body
内衬	Lining
包边	Trim
缀饰	Ornament
纹饰	Pattern
随机法器	Random Artifact
随机配饰宝箱	Random Accessory Chest
随机奇品法器	Random Rare Artifact
随机珍品法器	Random Precious Artifact
随机玄品法器	Random Mystic Artifact
奇品	Rare
珍品	Precious
玄品	Mystic
法器突破宝箱	Artifact Breakthrough Chest
登阶宝箱	Rank-Up Chest
冒险日常宝箱	Adventure Daily Chest
掉分保护卡	Score Loss Protection Card
掉段保护卡	Rank Drop Protection Card
双倍得分卡	Double Score Card
强化铁砧	Enhancement Anvil
银元宝	Silver Ingot
金元宝	Gold Ingot
铜钱串	String of Copper Coins
全信物	All Tokens
信物点	Token Points
辅弼	Fubi
火贪	Huotan
禄马	Luma
武破	Wupo
昌曲	Changqu
阳梁	Yangliang
辅弼试炼	Fubi Trial
火贪试炼	Huotan Trial
禄马试炼	Luma Trial
初窥世相	Glimpse of the World
微显识能	Faint Insight
崭露声名	Rising Fame
洞明世理	Clear Understanding
览遍众生	Seen All Beings
人间证道	Attaining the Dao
辅助	Support
加油	Go
默认头像框	Default Avatar Frame
金行研武	Metal Phase Martial Study
金行残篇	Metal Phase Fragment
金行密卷	Metal Phase Secret Scroll
金行原典	Metal Phase Original Canon
金行铸件	Metal Phase Casting
金行铸模	Metal Phase Mold
金行铸魂	Metal Phase Soul Casting
金炁朴印	Metal Qi Plain Seal
金炁精印	Metal Qi Refined Seal
金炁真印	Metal Qi True Seal
木行研武	Wood Phase Martial Study
木行残篇	Wood Phase Fragment
木行密卷	Wood Phase Secret Scroll
木行原典	Wood Phase Original Canon
木行铸件	Wood Phase Casting
木行铸模	Wood Phase Mold
木行铸魂	Wood Phase Soul Casting
木炁朴印	Wood Qi Plain Seal
木炁精印	Wood Qi Refined Seal
木炁真印	Wood Qi True Seal
水行研武	Water Phase Martial Study
水行残篇	Water Phase Fragment
水行密卷	Water Phase Secret Scroll
水行原典	Water Phase Original Canon
水行铸件	Water Phase Casting
水行铸模	Water Phase Mold
水行铸魂	Water Phase Soul Casting
水炁朴印	Water Qi Plain Seal
水炁精印	Water Qi Refined Seal
水炁真印	Water Qi True Seal
火行研武	Fire Phase Martial Study
火行残篇	Fire Phase Fragment
火行密卷	Fire Phase Secret Scroll
火行原典	Fire Phase Original Canon
火行铸件	Fire Phase Casting
火行铸模	Fire Phase Mold
火行铸魂	Fire Phase Soul Casting
火炁朴印	Fire Qi Plain Seal
火炁精印	Fire Qi Refined Seal
火炁真印	Fire Qi True Seal
土行研武	Earth Phase Martial Study
土行残篇	Earth Phase Fragment
土行密卷	Earth Phase Secret Scroll
土行原典	Earth Phase Original Canon
土行铸件	Earth Phase Casting
土行铸模	Earth Phase Mold
土行铸魂	Earth Phase Soul Casting
土炁朴印	Earth Qi Plain Seal
土炁精印	Earth Qi Refined Seal
土炁真印	Earth Qi True Seal
一折卡	90% Off Card
二折卡	80% Off Card
三折卡	70% Off Card
四折卡	60% Off Card
五折卡	50% Off Card
六折卡	40% Off Card
七折卡	30% Off Card
八折卡	20% Off Card
九折卡	10% Off Card
炼锋蓝色包	Tempered Edge Blue Pack
炼锋紫色包	Tempered Edge Purple Pack
炼锋橙色包	Tempered Edge Orange Pack
蔓刃蓝色包	Creeping Blade Blue Pack
蔓刃紫色包	Creeping Blade Purple Pack
蔓刃橙色包	Creeping Blade Orange Pack
寒渊蓝色包	Frost Abyss Blue Pack
寒渊紫色包	Frost Abyss Purple Pack
寒渊橙色包	Frost Abyss Orange Pack
赤炎蓝色包	Crimson Flame Blue Pack
赤炎紫色包	Crimson Flame Purple Pack
赤炎橙色包	Crimson Flame Orange Pack
镇岳蓝色包	Mountain Guard Blue Pack
镇岳紫色包	Mountain Guard Purple Pack
镇岳橙色包	Mountain Guard Orange Pack
破窍蓝色包	Orifice Breaker Blue Pack
破窍紫色包	Orifice Breaker Purple Pack
破窍橙色包	Orifice Breaker Orange Pack
蚀脉蓝色包	Meridian Erosion Blue Pack
蚀脉紫色包	Meridian Erosion Purple Pack
蚀脉橙色包	Meridian Erosion Orange Pack
乱神蓝色包	Spirit Havoc Blue Pack
乱神紫色包	Spirit Havoc Purple Pack
乱神橙色包	Spirit Havoc Orange Pack
震魄蓝色包	Soul Quake Blue Pack
震魄紫色包	Soul Quake Purple Pack
震魄橙色包	Soul Quake Orange Pack
摧元蓝色包	Vital Shatter Blue Pack
摧元紫色包	Vital Shatter Purple Pack
摧元橙色包	Vital Shatter Orange Pack
专精一阶	Mastery Tier 1
专精二阶	Mastery Tier 2
专精三阶	Mastery Tier 3
专精四阶	Mastery Tier 4
专精五阶	Mastery Tier 5
卷地风来秘籍	Wind Sweeps the Ground Manual
热毒镖秘籍	Heat-Poison Dart Manual
寒毒镖秘籍	Cold-Poison Dart Manual
撼地追雀秘籍	Earth-Shaking Sparrow Chase Manual
乱金柝秘籍	Chaos Gold Clapper Manual
迅雷之形秘籍	Form of Swift Thunder Manual
水银泻地秘籍	Mercury Spills on the Ground Manual
天王托塔秘籍	Heavenly King Holds the Pagoda Manual
幻身一刺秘籍	Phantom Body Thrust Manual
净心咒秘籍	Heart-Purifying Mantra Manual
不摇碧莲秘籍	Unshaken Jade Lotus Manual
怒夫三拳秘籍	Wrathful Triple Fists Manual
五雷镇秽秘籍	Five Thunders Suppress Filth Manual
螭吻秘籍	Chiwen Manual
金海擒龙秘籍	Golden Sea Dragon Capture Manual
锤砰砰秘籍	Thump-Thump Hammer Manual
金光遏煞秘籍	Golden Light Quells Evil Manual
九地之力秘籍	Power of the Nine Earths Manual
氓魂秘籍	Rogue Soul Manual
后旋斩秘籍	Back-Spin Slash Manual
链锯斩秘籍	Chainsaw Slash Manual
尸蛊封禁秘籍	Corpse Gu Seal Manual
一炮双响秘籍	Double Boom Manual
磁场展开秘籍	Magnetic Field Deploy Manual
斩仙飞刀秘籍	Immortal-Slaying Flying Knife Manual
薛幡奇品装束	Xue Fan Rare Outfit
薛幡珍品装束	Xue Fan Precious Outfit
薛幡胜利动作	Xue Fan Victory Pose
巴伦奇品装束	Baron Rare Outfit
巴伦珍品装束	Baron Precious Outfit
巴伦胜利动作	Baron Victory Pose
苑陶奇品装束	Yuan Tao Rare Outfit
苑陶珍品装束	Yuan Tao Precious Outfit
苑陶胜利动作	Yuan Tao Victory Pose
荣山奇品装束	Rong Shan Rare Outfit
荣山珍品装束	Rong Shan Precious Outfit
荣山胜利动作	Rong Shan Victory Pose
凌九奇品装束	Ling Jiu Rare Outfit
凌九珍品装束	Ling Jiu Precious Outfit
凌九胜利动作	Ling Jiu Victory Pose
天下会武	Martial Tournament
争锋之路	Road of Contention
三才轮战	Three-Talent Rotation
七日签到	7-Day Check-in
新手历程	Beginner's Journey
切磋模式	Sparring Mode
冒险模式	Adventure Mode
冒险声望	Adventure Reputation
冒险地图	Adventure Map
异人招募	Hidden Ones Recruitment
练习场	Practice Ground
身外身	Doppelganger
战斗教学	Combat Tutorial
决斗技巧	Duel Techniques
多人广场	Multiplayer Plaza
账号信息	Account Info
时装预览	Outfit Preview
试炼之路	Trial Road
赛季任务	Season Quests
奇珍商店	Rarities Shop
日常商店	Daily Shop
折扣商店	Discount Shop
快捷兑换	Quick Exchange
异人商店	Hidden Ones Shop
玩家升级	Player Level-up
异人档案	Hidden Ones Archive
娱乐模式	Entertainment Mode
日常任务	Daily Quests
阶段任务	Stage Quests
冒险任务	Adventure Quests
限时成就	Timed Achievements
快速对决	Quick Duel
连携对决	Tag Duel
连携争锋	Tag Clash
赛事房间	Tournament Room
自建房间	Custom Room
世界频道	World Channel
私聊频道	Private Chat
小队频道	Squad Channel
附近频道	Nearby Channel
广场聊天	Plaza Chat
升级成功	Level-up Successful
激活成功	Activated
防御力	Defense
暴击率	Crit Rate
暴击伤害	Crit Damage
破防率	Guard Break Rate
防御穿透	Defense Penetration
生命加成	HP Bonus
攻击加成	Attack Bonus
异人碎片	Hidden One Shards
异人经验	Hidden One EXP
武学材料	Martial Arts Materials
消耗品	Consumables
随机礼包	Random Gift Pack
新手礼包	Starter Pack
普通攻击	Normal Attack
防御反击	Counter
强制取消	Forced Cancel
行动力	Action Points
切磋积分	Sparring Points
冒险积分	Adventure Points
日常积分	Daily Points
账号经验	Account EXP
赛季经验	Season EXP
冒险经验	Adventure EXP
成长之路	Road of Growth
修身之路	Path of Self-Cultivation
研武之路	Path of Martial Study
觅宝之路	Path of Treasure Hunting
挑战之路	Road of Challenge
初阶试炼	Beginner Trial
第一阶段	Stage 1
第二阶段	Stage 2
第三阶段	Stage 3
第四阶段	Stage 4
第五阶段	Stage 5
冒险等级	Adventure Level
主线剧情	Main Story
下载中心	Download Center
异人上新	New Hidden One
基础装束	Basic Outfit
个性动作	Emotes
语音表现	Voice Lines
入场表现	Entrance
战斗特效	Combat Effects
账号展示	Profile Display
默认名片	Default Card
默认称号	Default Title
银鲤币	Silver Carp Coin
金鳞币	Golden Scale Coin
演武币	Martial Coin
狂欢币	Carnival Coin
特辑奖券	Collection Ticket
熟练度	Proficiency
副会长	Vice President
新手包	Starter Bundle
冒险资源	Adventure Resources
下载资源	Download Resources
每日打卡	Daily Check-in
本周	This Week
已领取	Received
已结束	Ended
活跃度	Activity
今日活跃度	Today's Activity
聊天	Chat
剧情	Story
主线	Main Story
武学	Martial Arts
特辑	Special Feature
收藏	Favorites
好友	Friends
成就	Achievements
充值	Top Up
基础	Basic
未知	Unknown
凡品	Common
奇品	Uncommon
珍品	Rare
玄品	Epic
绝品	Legendary
装备	Equipment
表情	Emotes
全选	Select All
短按	Tap
长按	Hold
进攻	Attack
援护	Support
复活	Revive
体力	Stamina
绝技	Ultimate
倒地	Knocked Down
顺序	Order
符券	Talisman Voucher
积分	Points
历程	Journey
铜币	Copper Coins
银币	Silver Coins
道具	Items
限时	Limited Time
冒险	Adventure
切磋	Sparring
头饰	Headwear
耳饰	Earrings
面饰	Face Accessory
胸饰	Chest Accessory
颈饰	Necklace
背饰	Back Accessory
肩饰	Shoulder Accessory
腿饰	Leg Accessory
臂饰	Arm Accessory
上衣	Top
内搭	Inner Layer
下装	Bottoms
杂饰	Misc. Accessories
鞋子	Shoes
外套	Outerwear
披风	Cape
饰品	Accessories
长袜	Socks
事件	Events
挑战	Challenge
待定	Pending
邮件	Mail
商店	Shop
活动	Events
教学	Tutorial
特权	Privileges
门票	Ticket
任务	Quests
仓库	Storage
广场	Plaza
订阅	Subscribe
公告	Announcements
设置	Settings
对决	Duel
客服	Support
其他	Other
赛季	Season
新手	Beginner
下载	Download
频道	Channel
更多	More
商城	Store
圈子	Community
更换	Change
海报	Poster
归位	Reset Position
功能	Features
日常	Daily
礼包	Gift Pack
娱乐	Entertainment
赛事	Tournaments
招募	Recruit
装束	Outfit
热销	Best Sellers
月历	Calendar
确认	Confirm
取消	Cancel
退出	Exit
确定	OK
否	No
是	Yes
重试	Retry
保存	Save
前往	Go To
装配	Equip
回收	Recycle
购买	Buy
解锁	Unlock
玩法	Game Mode
部位	Slot
概率	Odds
无	None
站立	Standing
普攻	Basic Attack
技能	Skills
一档	Tier 1
二档	Tier 2
三档	Tier 3
四档	Tier 4
五档	Tier 5
六档	Tier 6
七档	Tier 7
均衡	Balanced
激进	Aggressive
谨慎	Cautious
前	Front
后	Back
左	Left
右	Right
关闭	Close
全部	All
头像	Avatar
名片	Profile Card
称号	Title
开麦	Mic On
闭麦	Mic Off
开始	Start
按住	Hold
打断	Interrupt
播报	Broadcast
同意	Agree
否认	Deny
离开	Leave
照片	Photo
书籍	Book
地图	Map
观察	Observe
带走	Take
接受	Accept
答应	Agree
不是	No
认识	Know Them
知道	Know
没有	None
会	Yes
不会	No
效果	Effect
武器	Weapon
保护	Protection
增强	Boost
隐身	Stealth
追踪	Tracking
穿透	Pierce
回溯	Rewind
宝箱	Treasure Chest
打开	Open
测试	Test
动作	Action
简单	Easy
普通	Normal
困难	Hard
珍玩	Curios
乐器	Instrument
蜡烛	Candle
丹药	Elixir
剪刀	Scissors
决赛	Finals
助威	Cheer
护体	Guard
金身	Golden Body
内功	Inner Power
胜利	Victory
和局	Draw
完胜	Flawless Win
选择	Select
暂无	None Yet
领取	Claim
刷新	Refresh
返回	Back
观战	Spectate
得胜	Won
落败	Lost
险胜	Narrow Win
惜败	Narrow Loss
惨败	Crushing Defeat
菜单	Menu
展开	Expand
收起	Collapse
其它	Other
我方	Ally
敌方	Enemy
详情	Details
继续	Continue
配饰	Accessories
卸下	Unequip
染色	Dye
选人	Select Character
登场	Enter
世界	World
私聊	Private Chat
语音	Voice
更新	Update
跳过	Skip
安装	Install
类型	Type
品质	Quality
修复	Repair
播放	Play
暂停	Pause
和	And
周一	Monday
周二	Tuesday
周三	Wednesday
周四	Thursday
周五	Friday
周六	Saturday
周日	Sunday
日	Day
圆形	Circle
矩形	Rectangle
证据	Evidence
线索	Clues
高清	High Definition
低清	Low Definition
等级	Level
套装	Set
建议	Suggestions
问题	Issues
视频	Video
图片	Image
替换	Replace
洗练	Refine
在线	Online
旋转	Rotate
穿戴	Wear
清空	Clear
突破	Breakthrough
粘贴	Paste
再战	Rematch
清理	Clean Up
跳转	Jump To
分享	Share
新建	New
减少	Reduce
邀请	Invite
编辑	Edit
下阵	Remove from Lineup
换位	Swap Position
上阵	Add to Lineup
交换	Swap
添加	Add
查看	View
删除	Delete
上传	Upload
浏览	Browse
搜索	Search
切换	Switch
加入	Join
赠礼	Gift
重置	Reset
移出	Remove
专辑	Album
徽章	Badge
上午	AM
下午	PM
标签	Tag
收集	Collect
极难	Extreme
易	Easy
难	Hard
满	Full
获取	Obtain
使用	Use
背包	Inventory
藏品	Collectibles
价值	Value
重量	Weight
进入	Enter
合成	Craft
分解	Dismantle
锁定	Lock
失败	Failed
奖励	Rewards
默认	Default
出战	Deploy
卡牌	Cards
增益	Buffs
平台	Platform
首通	First Clear
方案	Preset
静音	Mute
流畅	Smooth
中等	Medium
超高	Very High
极致	Ultra
低	Low
中	Medium
高	High
极高	Very High
窗口	Windowed
亮度	Brightness
汉语	Chinese
英语	English
日语	Japanese
韩语	Korean
自动	Auto
质量	Quality
平衡	Balanced
性能	Performance
显存	VRAM
键鼠	Keyboard & Mouse
手柄	Controller
键盘	Keyboard
分钟	Minutes
开启	Enable
天	Days
时	Hours
分	Minutes
兑换	Redeem
改名	Rename
补领	Claim Missed
拥有	Owned
品级	Grade
价格	Price
本日	Today
本周	This Week
本月	This Month
伤害	Damage
激活	Activate
提示	Tips
准备	Ready
选手	Players
观众	Spectators
裁判	Referee
重启	Restart
图鉴	Collection
说明	Info
举报	Report
描述	Description
开	On
关	Off
练习	Practice
复位	Reset
共享	Shared
可赠	Giftable
绑定	Bound
级	Lv.
精选	Featured
典藏	Treasured
试用	Trial
翻页	Next Page
攻略	Guide
专精	Mastery
外观	Appearance
常用	Frequently Used
介绍	Introduction
置顶	Pin
发送	Send
升级	Level Up
获得	Obtained
筛选	Filter
匹配	Matchmaking
房间	Room
对比	Compare
推荐	Recommended
专属	Exclusive
双倍	Double
生存	Survival
消耗	Cost
提交	Submit
状态	Status
精炼	Refine
离线	Offline
拒绝	Decline
游戏	Game
系统	System
通知	Notifications
安全	Security
注销	Log Out
回退	Revert
剩余	Remaining
关卡	Stage
追忆	Recollection
开通	Activate
续期	Renew
排名	Ranking
胜率	Win Rate
星级	Star Rating
场次	Matches
层数	Floors
奖杯	Trophy
账号	Account
编队	Squad
秒	sec
升星	Star Up
属性	Attributes
次	Times
限定	Limited
难度	Difficulty
今日	Today
当前	Current
图册	Album
携带	Carry
达到	Reached
成长	Growth
扫荡	Sweep
备战	Prepare
得分	Score
用时	Time
对手	Opponent
胜场	Wins
己方	Ally
轮次	Round
击败	Defeated
阵容	Lineup
导入	Import
换装	Change Outfit
段位	Rank
玩家	Player
数量	Quantity
内容	Content
活跃	Active
暗淡	Dim
明亮	Bright
进阶	Advance
技巧	Tips
研习	Study
规则	Rules
百科	Encyclopedia
卸载	Uninstall
姓名	Name
正在	In Progress
赠送	Send Gift
合计	Total
上新	New Arrivals
失误	Miss
完美	Perfect
场景	Scene
奖池	Prize Pool
小时	Hours
限购	Purchase Limit
序号	No.
回忆	Memories
次数	Count
首战	First Battle
加速	Speed Up
求赠	Request Gift
现金	Cash
连击	Combo
金币	Gold
完成	Complete
常驻	Permanent
返利	Rebate
豪华	Deluxe
开放	Open
全局	Global
队内	Team
精简	Simplified
容量	Capacity
战况	Battle Status
请战	Challenge
时停	Time Stop
日记	Diary
上交	Hand In
视角	Camera
护盾	Shield
还原	Restore
目标	Target
发饰	Hair Accessory
进度	Progress
歌单	Playlist
音乐	Music
标题	Title
禁用	Disabled
月	Month
回看	Replay
宗师	Grandmaster
已选	Selected
智能	Smart
自由	Free
适中	Moderate
拥挤	Crowded
我的	Mine
报名	Sign Up
赛程	Schedule
每日	Daily
推车	Push Cart
开门	Open Door
上香	Offer Incense
询问	Ask
对话	Talk
移动	Move
拿取	Take
逃离	Escape
交谈	Talk
猎物	Prey
万	10K
亿	100M
个	pcs
'@
        foreach ($ln in ($shortTsv -split "`r?`n")) {
            $i = $ln.IndexOf("`t"); if ($i -lt 1) { continue }
            $k = Get-NormKey $ln.Substring(0, $i); if ($k.Length -ge 1) { $script:Dict[$k] = $ln.Substring($i + 1).Trim() }
        }
    } catch { Write-Log "short dict: $_" }
    # glossary.csv rows double as exact-match overrides (user entries win)
    foreach ($g in $script:Glossary) { $k = Get-NormKey $g.cn; if ($k.Length -ge 1) { $script:Dict[$k] = $g.en } }
    Write-Log "dictionary $($script:Dict.Count) entries, glossary $($script:Glossary.Count) terms"
}
Load-Dictionaries

function Protect-Glossary([string]$text) {
    $map = @{}; $n = 0
    # numbers are never translated: protect them (digits as written; 万 / 亿 amounts only converted from a million up)
    $sb = New-Object System.Text.StringBuilder
    $pos = 0; $nn = 0
    foreach ($mm in [regex]::Matches($text, '\d+(?:,\d{3})*(?:\.\d+)?[万亿]?')) {
        [void]$sb.Append($text.Substring($pos, $mm.Index - $pos))
        $tokn = 'Xr' + $nn + 'Z'
        $final = $mm.Value
        $um = [regex]::Match($mm.Value, '^(\d+(?:,\d{3})*(?:\.\d+)?)([万亿])$')
        if ($um.Success) {
            $vv = [double]($um.Groups[1].Value -replace ',', '')
            if ($um.Groups[2].Value -eq '万') { $vv = $vv * 10000 } else { $vv = $vv * 100000000 }
            if ($vv -ge 1000000) { $final = Format-BigNumber $vv }
        }
        $map[$tokn] = $final; $nn++
        [void]$sb.Append($tokn)
        $pos = $mm.Index + $mm.Length
    }
    [void]$sb.Append($text.Substring($pos))
    $text = $sb.ToString()
    foreach ($g in $script:Glossary) {
        if ($text.Contains($g.cn)) {
            $tok = 'Xq' + $n + 'Z'
            $text = $text.Replace($g.cn, $tok)
            $map[$tok] = $g.en; $n++
        }
    }
    return @{ text = $text; map = $map }
}
function Restore-Glossary([string]$text, $map) {
    foreach ($tok in $map.Keys) {
        $rx = [regex]::Escape($tok)
        if ([regex]::IsMatch($text, $rx, 'IgnoreCase')) { $text = [regex]::Replace($text, $rx, [string]$map[$tok].Replace('$', '$$'), 'IgnoreCase') }
        elseif ($tok.StartsWith('Xr')) { $text = $text + ' ' + [string]$map[$tok] }       # the translator dropped a number: put it back
    }
    return $text
}
function Apply-OfficialTsv([string]$path) {
    $n = 0; $script:LocalMemoN = -1
    foreach ($ln in [System.IO.File]::ReadAllLines($path, [System.Text.Encoding]::UTF8)) {
        $i = $ln.IndexOf("`t"); if ($i -lt 1) { continue }
        $k = Get-NormKey ($ln.Substring(0, $i).Replace('\n', "`n"))
        $en = $ln.Substring($i + 1).Replace('\n', "`n")
        if ($k.Length -ge 2 -and $en) { $script:Dict[$k] = $en; $n++ }
    }
    return $n
}
function Load-OfficialTsv {
    $op = Join-Path $script:DataDir 'official.tsv'
    if (Test-Path $op) { try { $c = Apply-OfficialTsv $op; Write-Log "official strings loaded: $c" } catch { Write-Log "official: $($_.Exception.Message)" } }
}
Load-OfficialTsv
try {
    $liteDict = Join-Path $PSScriptRoot 'starfire-lite-dict.tsv'
    if (Test-Path $liteDict) {
        $before = $script:Dict.Count
        foreach ($ln in [System.IO.File]::ReadAllLines($liteDict, [System.Text.Encoding]::UTF8)) {
            $i = $ln.IndexOf("`t"); if ($i -lt 1) { continue }
            $k = Get-NormKey $ln.Substring(0, $i)
            if ($k.Length -ge 2 -and -not $script:Dict.ContainsKey($k)) { $script:Dict[$k] = $ln.Substring($i + 1) }      # never overrides the built-in dictionary or your glossary
        }
        $script:LocalMemoN = -1
        Write-Log ('lite dictionary: ' + ($script:Dict.Count - $before) + ' terms added, ' + $script:Dict.Count + ' in total')
    } else { Write-Log 'lite dictionary: starfire-lite-dict.tsv not found next to StarfireLite.ps1' }
} catch { Write-Log ('lite dictionary: ' + $_.Exception.Message) }
function Import-OfficialStrings {
    # If the game folder (or the data folder) holds an English string table next to the Chinese one, pair them by key
    # hash. Those are the game's own words, so they replace machine translation for every exact match.
    $script:OfficialTried = $true
    try {
        $dirs = @($script:DataDir)
        try { $gpath = (Get-Process -Id ([int]$script:Game.pid) -ErrorAction Stop).Path; if ($gpath) { $dirs += (Split-Path $gpath -Parent) } } catch {}
        $files = @()
        foreach ($d in $dirs) { $files += @(Get-ChildItem -Path $d -Recurse -Depth 8 -Filter 'I18NTranslation_*.bytes' -ErrorAction SilentlyContinue) }
        if ($files.Count -eq 0) { Write-Log 'official strings: no I18NTranslation_*.bytes found in the game folder'; return }
        foreach ($f in $files) { Write-Log ('official strings: found ' + $f.FullName) }
        $cnF = $files | Where-Object { $_.Name -match '_CN\.bytes$' } | Select-Object -First 1
        $enF = $files | Where-Object { $_.Name -match '_(EN|en|EN-US|en-US|English|ENG)\.bytes$' } | Select-Object -First 1
        if (-not $enF) { $enF = $files | Where-Object { $_.Name -notmatch '_CN\.bytes$' -and $_.Name -notmatch '_(TW|ZH|zh|JP|KR|JA|KO)' } | Select-Object -First 1 }
        if (-not $cnF -or -not $enF) { Write-Log 'official strings: need both a _CN and an English .bytes file'; return }
        $cn = [StarBytes]::Read($cnF.FullName); $en = [StarBytes]::Read($enF.FullName)
        $lines = New-Object System.Collections.Generic.List[string]
        foreach ($key in $cn.Keys) {
            if (-not $en.ContainsKey($key)) { continue }
            $c = [string]$cn[$key]; $e = [string]$en[$key]
            if (-not (Test-Cjk $c)) { continue }
            if ($e -match '[\u4e00-\u9fff]' -or $c -match '\{[^}]*\}' -or $e -match '\{[^}]*\}') { continue }
            $c = ($c -replace '<[^>]+>', '').Replace("`r", '').Replace("`n", '\n').Replace("`t", ' ')
            $e = ($e -replace '<[^>]+>', '').Replace("`r", '').Replace("`n", '\n').Replace("`t", ' ')
            if ($c.Trim().Length -lt 2 -or -not $e.Trim()) { continue }
            [void]$lines.Add($c + "`t" + $e)
        }
        $op = Join-Path $script:DataDir 'official.tsv'
        [System.IO.File]::WriteAllLines($op, $lines.ToArray(), (New-Object System.Text.UTF8Encoding($false)))
        $c2 = Apply-OfficialTsv $op
        $script:LastTextSig = $null; $script:LastHash = $null
        Write-Log ("official strings: " + $c2 + ' pairs from ' + $enF.Name)
    } catch { Write-Log "official import: $($_.Exception.Message)" }
}
$script:KnownMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal); $script:KnownMemoN = -1
function Test-KnownText([string]$t) {
    if ([string]::IsNullOrEmpty($t)) { return $false }
    $kv = $script:KnownMemo[$t]
    if ($true -eq $kv) { return $true }
    $nNow = [int]$script:Dict.Count + [int]$script:Cache.Count
    if ($nNow -ne $script:KnownMemoN) { $script:KnownMemoN = $nNow; foreach ($kk in @($script:KnownMemo.Keys)) { if ($script:KnownMemo[$kk] -ne $true) { $script:KnownMemo.Remove($kk) } } }
    elseif ($false -eq $kv) { return $false }
    if ($script:KnownMemo.Count -gt 3000) { $script:KnownMemo.Clear() }
    $r = Test-KnownText0 $t
    $script:KnownMemo[$t] = [bool]$r
    return [bool]$r
}
function Test-KnownText0([string]$t) {
    if ($script:Cache.ContainsKey($t.Trim())) { return $true }
    if ($null -ne (Translate-Local $t.Trim())) { return $true }
    return $script:Dict.ContainsKey((Get-NormKey $t))
}
function Start-Translate([string]$key, [int]$tries) {
    # $tries = index of the service to use (see RouteNames); services that are resting are skipped
    $nowS = [int64]$script:Clk.ElapsedMilliseconds
    if ($tries -lt 0) { $tries = 0 }
    while ($tries -lt $script:RouteN -and (($tries -eq 0 -and -not $script:MsOk) -or $nowS -lt [int64]$script:RouteUntil[$tries])) { $tries++ }
    if ($tries -ge $script:RouteN) { $script:FailedAt[$key] = Get-Date; return }       # every service is resting: ask again in a little while
    $prot = Protect-Glossary $key
    $q = [uri]::EscapeDataString($prot.text)
    $alt = $null
    switch ($tries) {
        0 { $url = 'ms:' }
        1 { $url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=en&dt=t&dj=1&q=$q"
            $alt = "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=zh-CN&tl=en&dt=t&q=$q" }     # hedge: a second route if the first is slow
        2 { $url = "https://translate.google.com/translate_a/single?client=gtx&sl=zh-CN&tl=en&dt=t&dj=1&q=$q" }
        3 { $url = "https://lingva.ml/api/v1/zh/en/$q" }
        4 { $url = "https://lingva.lunar.icu/api/v1/zh/en/$q" }
        default { $url = "https://api.mymemory.translated.net/get?langpair=zh-CN%7Cen&q=$q" }
    }
    $ent = @{ task = $null; task2 = $null; url = $url; alt = $alt; txt = [string]$prot.text; map = $prot.map; tries = $tries; bi = 0; at = $nowS; t0 = [int64]0 }
    $script:Pending[$key] = $ent
    # Microsoft requests are sent in batches by Poll-Translations; the others fire at once while there is room
    if ($tries -ne 0 -and [int]$script:InflightN -lt 4) {
        try { $ent.task = Start-Req $ent; $ent.t0 = $nowS; $script:InflightN = 1 + [int]$script:InflightN } catch { Write-Log "request: $($_.Exception.Message)" }
    }
}
function Parse-MsAt($task, [int]$i) {
    # one answer of a Microsoft batch: [{ "translations": [{ "text": ... }] }, ...]
    try {
        if (-not [object]::ReferenceEquals($task, $script:MsParseTask)) {
            if (-not $script:Ser) { Add-Type -AssemblyName System.Web.Extensions; $script:Ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $script:Ser.MaxJsonLength = 10485760 }
            $script:MsParseArr = $script:Ser.DeserializeObject([string]$task.Result)
            $script:MsParseTask = $task
        }
        $arr = $script:MsParseArr
        if ($null -eq $arr -or $i -ge $arr.Length) { return $null }
        $e = $arr[$i]
        if ($e -is [System.Collections.IDictionary] -and $e.ContainsKey('translations')) {
            foreach ($tr0 in $e['translations']) { if ($tr0 -is [System.Collections.IDictionary] -and $tr0['text']) { return [string]$tr0['text'] } }
        }
        return $null
    } catch { return $null }
}
$script:InflightN = 0
function Parse-GTrans([string]$json) {
    # JavaScriptSerializer is far faster than ConvertFrom-Json on the UI thread
    try {
        if (-not $script:Ser) { Add-Type -AssemblyName System.Web.Extensions; $script:Ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $script:Ser.MaxJsonLength = 10485760 }
        $o = $script:Ser.DeserializeObject($json)
        $parts = New-Object System.Collections.Generic.List[string]
        if ($o -is [System.Collections.IDictionary] -and $o.ContainsKey('translation')) {
            if ($o['translation']) { [void]$parts.Add([string]$o['translation']) }
        } elseif ($o -is [System.Collections.IDictionary] -and $o.ContainsKey('responseData')) {
            $rd = $o['responseData']
            if ($rd -is [System.Collections.IDictionary] -and $rd['translatedText']) { [void]$parts.Add([string]$rd['translatedText']) }
        } elseif ($o -is [object[]] -and $o.Length -gt 0 -and $o[0] -is [System.Collections.IDictionary] -and $o[0].ContainsKey('translations')) {
            foreach ($tr0 in $o[0]['translations']) { if ($tr0 -is [System.Collections.IDictionary] -and $tr0['text']) { [void]$parts.Add([string]$tr0['text']) } }
        } elseif ($o -is [System.Collections.IDictionary]) {
            foreach ($s2 in $o['sentences']) { if ($s2 -is [System.Collections.IDictionary] -and $s2['trans']) { [void]$parts.Add([string]$s2['trans']) } }
        } else {
            foreach ($seg in $o[0]) { if ($seg -and $seg[0]) { [void]$parts.Add([string]$seg[0]) } }
        }
        return [string]::Join('', $parts.ToArray())
    } catch { return $null }
}
function Test-TaskOk($t) { return ($null -ne $t -and $t.IsCompleted -and -not $t.IsFaulted -and -not $t.IsCanceled) }
function Poll-Translations {
    Check-SelfTest
    if ($script:Pending.Count -eq 0 -and -not $script:NeedRedraw) { $script:InflightN = 0; if ($script:CacheDirty -ge 25 -and (([int64][Environment]::TickCount - [int64]$script:CacheSavedAt) -gt 20000)) { Save-Cache }; return }
    $now = [int64]$script:Clk.ElapsedMilliseconds
    $queued = New-Object System.Collections.Generic.List[string]
    $tset = @{}
    foreach ($pk in @($script:Pending.Keys)) {
        $pv = $script:Pending[$pk]
        if ($null -eq $pv.task) { [void]$queued.Add([string]$pk) }
        elseif (-not $pv.task.IsCompleted) { $tset[$pv.task] = 1 }        # a Microsoft batch is one request for many texts
    }
    $inflight = $tset.Count
    $script:InflightN = $inflight
    if ($queued.Count -gt 0) {
        # texts that are no longer on screen (OCR noise, labels already gone) are not worth a request
        $want = $null
        if ($queued.Count -gt 6) {
            $want = @{}
            foreach ($tk in $script:Tracks) { if ($tk.text) { $want[([string]$tk.text).Trim()] = 1 } }
            foreach ($lb in @($script:LastBlocks)) { if ($lb -and $lb.src) { $want[([string]$lb.src).Trim()] = 1 } }
        }
        $queued.Sort([Comparison[string]]{ param($x, $y) $x.Length.CompareTo($y.Length) })
        $started = 0
        $msKeys = New-Object System.Collections.Generic.List[string]; $msChars = 0
        foreach ($qk in $queued) {
            $qp = $script:Pending[$qk]
            if ($null -eq $qp -or $null -ne $qp.task) { continue }
            if ($null -ne $want -and -not $want.ContainsKey($qk) -and ($now - [int64]$qp.at) -gt 1000) { $script:Pending.Remove($qk); continue }
            $r = [int]$qp.tries
            if ($now -lt [int64]$script:RouteUntil[$r]) { $script:Pending.Remove($qk); Start-Translate $qk ($r + 1); continue }      # that service is resting: use the next one
            if ($r -eq 0) {
                if ($msKeys.Count -lt 40 -and ($msChars + ([string]$qp.txt).Length) -le 4000) { [void]$msKeys.Add($qk); $msChars += ([string]$qp.txt).Length }
                continue
            }
            if ($inflight -ge 5 -or $started -ge 3) { continue }
            try { $qp.task = Start-Req $qp; $qp.t0 = $now; $inflight++; $started++ } catch { Write-Log "request: $($_.Exception.Message)" }
        }
        if ($msKeys.Count -gt 0 -and $inflight -lt 6) {
            $txts = New-Object System.Collections.Generic.List[string]
            foreach ($mk in $msKeys) { [void]$txts.Add([string]$script:Pending[$mk].txt) }
            try {
                $mt = [StarMs]::TrMany($script:Http, $txts.ToArray())
                for ($mi = 0; $mi -lt $msKeys.Count; $mi++) { $me = $script:Pending[$msKeys[$mi]]; $me.task = $mt; $me.bi = $mi; $me.t0 = $now }
                $inflight++
            } catch { Write-Log "request: $($_.Exception.Message)"; $script:RouteUntil[0] = $now + 30000 }
        }
        $script:InflightN = $inflight
    }
    foreach ($k in @($script:Pending.Keys)) {
        $p = $script:Pending[$k]
        if ($null -eq $p -or $null -eq $p.task) { continue }
        $r = [int]$p.tries
        $win = $null
        if (Test-TaskOk $p.task) { $win = $p.task } elseif (Test-TaskOk $p.task2) { $win = $p.task2 }
        if ($null -eq $win) {
            $d1 = $p.task.IsCompleted; $d2 = ($null -eq $p.task2) -or $p.task2.IsCompleted
            if (-not ($d1 -and $d2)) {
                # slow answer: ask a second route in parallel, whichever comes back first wins
                if ($null -eq $p.task2 -and $p.alt -and -not $d1 -and ($now - [int64]$p.t0) -ge 2500) {
                    try { $p.task2 = $script:Http.GetStringAsync([string]$p.alt) } catch {}
                }
                continue
            }
        }
        $dst = $null
        if ($null -ne $win) {
            if ($r -eq 0) { $dst = Parse-MsAt $win ([int]$p.bi) }
            else {
                try { $dst = Parse-GTrans ([string]$win.Result) } catch { Write-Log "parse: $($_.Exception.Message)" }
            }
        } else {
            $script:TrFail = 1 + [int]$script:TrFail
            $err = ''
            try { $err = [string]$p.task.Exception.InnerException.Message } catch {}
            $script:TrErr = $err
            # one log line per service and minute is enough
            if (-not $script:FailLogAt) { $script:FailLogAt = New-Object 'int64[]' $script:RouteN }
            if (($now - [int64]$script:FailLogAt[$r]) -gt 60000) { $script:FailLogAt[$r] = $now; Write-Log ('translate failed (' + $script:RouteNames[$r] + '): ' + $err) }
            # rest the service: briefly when it says "too many requests", longer when it seems to be down
            if ($err -match '429|Too Many') { if ($r -le 2) { $rest = 10000 } else { $rest = 30000 } }
            elseif ($r -ge 3) { $rest = 120000 } else { $rest = 15000 }
            if (($now + $rest) -gt [int64]$script:RouteUntil[$r]) { $script:RouteUntil[$r] = $now + $rest }
        }
        if ($dst) {
            if (-not $script:RouteLogged[$r]) { $script:RouteLogged[$r] = $true; Write-Log ('translator ok (' + $script:RouteNames[$r] + '): ' + $dst) }
            $dst = Clean-Names (Restore-Glossary $dst $p.map)
            $script:Cache[$k] = $dst; $script:CacheDirty++; $script:TrOk = 1 + [int]$script:TrOk
            $script:Pending.Remove($k); $script:NeedRedraw = $true
        } else {
            $script:Pending.Remove($k)
            Start-Translate $k ($r + 1)                 # next service (marks the text as failed for a while when none is left)
        }
    }
    if ($script:NeedRedraw) {
        $script:NeedRedraw = $false
        foreach ($b in @($script:LastBlocks)) {
            if ($b -and [string]::IsNullOrWhiteSpace([string]$b.en)) {
                $k = ([string]$b.src).Trim()
                if ($script:Cache.ContainsKey($k)) { $b.en = (Clean-Names ([string]$script:Cache[$k])); try { Layout-Block $b $script:FrameBmp $script:FrameRect } catch {} }
            }
        }
        try { $script:Overlay.Invalidate() } catch {}
    }
    if ($script:CacheDirty -ge 25 -and (([int64][Environment]::TickCount - [int64]$script:CacheSavedAt) -gt 20000)) { Save-Cache }
}
function Start-SelfTest {
    try {
        $script:SelfTask = $null       # Starfire Lite: offline, no online self-test
        $script:SelfAt = Get-Date
    } catch { Write-Log "selftest start: $($_.Exception.Message)" }
}
function Check-SelfTest {
    if (-not $script:SelfTask) { return }
    if (-not $script:SelfTask.IsCompleted) { if (((Get-Date) - $script:SelfAt).TotalSeconds -gt 12) { Write-Log 'selftest: no answer from translate.googleapis.com in 12 s'; $script:SelfTask = $null }; return }
    try {
        if ($script:SelfTask.IsFaulted) { Write-Log ('selftest FAILED: ' + [string]$script:SelfTask.Exception.InnerException.Message) }
        else { Write-Log ('selftest ok: ' + (Parse-GTrans ([string]$script:SelfTask.Result))) }
    } catch { Write-Log "selftest: $($_.Exception.Message)" }
    $script:SelfTask = $null
}
function Format-NumPart([string]$p) {
    # "6（1 3）" -> "6 (1/3)": brackets as plain ( ), a slash the OCR lost between two numbers in brackets is put back
    $p = $p.Replace([string][char]0xFF08, '(').Replace([string][char]0xFF09, ')').Trim()
    $p = [regex]::Replace($p, '\(\s*(\d+)\s+(\d+)\s*\)?$', '($1/$2)')
    $p = [regex]::Replace($p, '(\d)\(', '$1 (')
    return $p
}
function Translate-Batch([string[]]$texts) {
    # Never blocks: returns what is known now, queues the rest. Poll-Translations fills the gaps.
    $out = @{}
    foreach ($t in $texts) {
        if ([string]::IsNullOrWhiteSpace($t)) { continue }
        $k = $t.Trim()
        if (-not (Test-Cjk $k)) { $out[$k] = $k; continue }
        $nvv = Get-NumberOnlyValue $k
        if ($null -ne $nvv) { if ($nvv -ge 1000000) { $out[$k] = Format-BigNumber $nvv } else { $out[$k] = $k }; continue }     # numbers are not translated unless they reach the millions
        if ($script:LocalMemoN -ne $script:Dict.Count -or $null -eq $script:LocalMemo -or $script:LocalMemo.Count -gt 6000) { $script:LocalMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal); $script:LocalMemoN = $script:Dict.Count }
        if ($script:LocalMemo.ContainsKey($k)) { $out[$k] = $script:LocalMemo[$k]; $script:DictHits++; continue }
        $nk = Get-NormKey $k
        if ($script:Dict.ContainsKey($nk)) { $out[$k] = $script:Dict[$nk]; $script:LocalMemo[$k] = $out[$k]; $script:DictHits++; continue }
        $lt = Translate-Local $k
        if ($lt) { $out[$k] = $lt; $script:LocalMemo[$k] = $lt; $script:DictHits++; continue }
        if ($nk.Length -ge 4 -and $nk.Length -le 11 -and $nk -notmatch '\d') {
            $fz = Get-FuzzyHit $nk
            if ($fz) { $out[$k] = $fz; $script:LocalMemo[$k] = $fz; $script:DictHits++; continue }
        }
        # "0援助" / "等级 10" style: keep the number part, translate the label from the dictionary
        $m = [regex]::Match($k, '^([\d\s\.\:/%+\-x\u00d7()\uff08\uff09]*)([^\d()\uff08\uff09]*?)([\d\s\.\:/%+\-x\u00d7()\uff08\uff09]*)$')
        if ($m.Success -and $m.Groups[2].Value.Trim().Length -ge 1) {
            $ck = Get-NormKey $m.Groups[2].Value
            if ($script:Dict.ContainsKey($ck)) {
                $n1 = Format-NumPart $m.Groups[1].Value; $n3 = Format-NumPart $m.Groups[3].Value
                $out[$k] = (($n1 + ' ' + $script:Dict[$ck] + ' ' + $n3).Trim())
                $script:LocalMemo[$k] = $out[$k]
                $script:DictHits++; continue
            }
        }
        # a game word whose last character is hidden (icon, glow, edge of a button): "玩法奖" -> 玩法奖励, when only one word fits
        if ($nk.Length -ge 3 -and $nk -match '^[\u4e00-\u9fff]+$') {
            if ($script:PrefixN -ne $script:Dict.Count -or $null -eq $script:PrefixIdx) {
                $script:PrefixIdx = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal); $script:PrefixN = $script:Dict.Count
                foreach ($dk in @($script:Dict.Keys)) {
                    $dks = [string]$dk
                    if ($dks.Length -ge 4 -and $dks.Length -le 10 -and $dks -match '^[\u4e00-\u9fff]+$') {
                        $pk = $dks.Substring(0, $dks.Length - 1)
                        if ($script:Dict.ContainsKey($pk)) { continue }
                        if ($script:PrefixIdx.ContainsKey($pk)) { $script:PrefixIdx[$pk] = '' } else { $script:PrefixIdx[$pk] = $dks }
                    }
                }
            }
            $full = $script:PrefixIdx[$nk]
            if ($full) { $out[$k] = $script:Dict[$full]; $script:LocalMemo[$k] = $out[$k]; $script:DictHits++; continue }
            # ... or whose first character is hidden ("容方案" -> 阵容方案), when only one word fits
            if ($nk.Length -ge 3) {
                if ($script:SuffixN -ne $script:Dict.Count -or $null -eq $script:SuffixIdx) {
                    $script:SuffixIdx = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal); $script:SuffixN = $script:Dict.Count
                    foreach ($dk in @($script:Dict.Keys)) {
                        $dks = [string]$dk
                        if ($dks.Length -ge 4 -and $dks.Length -le 10 -and $dks -match '^[\u4e00-\u9fff]+$') {
                            $sk = $dks.Substring(1)
                            if ($script:Dict.ContainsKey($sk)) { continue }
                            if ($script:SuffixIdx.ContainsKey($sk)) { $script:SuffixIdx[$sk] = '' } else { $script:SuffixIdx[$sk] = $dks }
                        }
                    }
                }
                $full2 = $script:SuffixIdx[$nk]
                if ($full2) { $out[$k] = $script:Dict[$full2]; $script:LocalMemo[$k] = $out[$k]; $script:DictHits++; continue }
            }
        }
        if ($script:Cache.ContainsKey($k)) { $out[$k] = $script:Cache[$k]; continue }
        if ($script:Pending.ContainsKey($k)) { continue }
        if ($script:FailedAt.ContainsKey($k) -and ((Get-Date) - $script:FailedAt[$k]).TotalSeconds -lt 30) { continue }
        if ($k.Length -le 8) {
            # very short phrases are unreliable without context: log them so they can be added to glossary.csv
            try { if (-not $script:UnkLogged) { $script:UnkLogged = @{} }; if (-not $script:UnkLogged.ContainsKey($k)) { $script:UnkLogged[$k] = 1; Add-Content -Path (Join-Path $script:DataDir 'unknown-short.txt') -Value $k -Encoding UTF8 } } catch {}
        }
        # Starfire Lite 1.1: the game's own terms come from the dictionaries above; everything else goes to the online
        # translators as backup (Microsoft -> Google -> Google 2 -> Lingva x2 -> MyMemory), and is saved so it is only asked once
        Start-Translate $k 0
    }
    foreach ($ok0 in @($out.Keys)) {
        try { $out[$ok0] = Fix-Canon ([string]$ok0) ([string]$out[$ok0]) } catch {}
        try { $out[$ok0] = Fix-Counter ([string]$ok0) ([string]$out[$ok0]) } catch {}
        try { $out[$ok0] = Fix-LeftoverHan ([string]$out[$ok0]) } catch {}
        try { $out[$ok0] = Fix-Brackets ([string]$ok0) ([string]$out[$ok0]) } catch {}
    }
    return $out
}
# an online translation sometimes leaves a Chinese character in the English ("Protection卡 Settings"): such leftovers are
# translated from the dictionary, or from a short list of common single characters, so no Chinese is left in a label
$script:HanOne = @{ '卡' = 'Card'; '阶' = 'Tier'; '星' = 'Star'; '级' = 'Level'; '段' = 'Rank'; '分' = 'Points'; '币' = 'Coins'; '券' = 'Ticket'; '包' = 'Pack'; '箱' = 'Chest'; '奖' = 'Reward'; '战' = 'Battle'; '技' = 'Skill'; '招' = 'Move'; '式' = 'Form'; '套' = 'Set'; '装' = 'Outfit'; '图' = 'Map'; '场' = 'Arena'; '局' = 'Match'; '队' = 'Team'; '胜' = 'Win'; '败' = 'Loss'; '天' = 'Day'; '次' = 'Times'; '个' = ''; '的' = ''; '了' = '' }
# one wording for the same game phrase, whatever route the translation took (dictionary, prefix completion, or an online
# translator for a slightly misread variant): 玩法奖励 is always "Mode Rewards", never "Game Mode Rewards" / "Gameplay Rewards"
function Fix-Canon([string]$cn, [string]$en) {
    $c = ($cn -replace '\s', '')
    # the menu decides some words: in the ranked lobby 玩法奖励 is "Duel Rewards" and 匹配 stays "Matchmaking"; in the sparring menu
    # (tabs 排位赛 / 匹配 / 娱乐 / 房间) 匹配 is "Casual" and 娱乐 is "Fun"; 玩法奖励 is "Mode Rewards" anywhere else
    $ranked = ([string]$script:CtxName -eq 'ranked'); $spar = ([string]$script:CtxName -eq 'spar')
    $rw = 'Mode Rewards'; if ($ranked) { $rw = 'Duel Rewards' }
    # one wording whatever route the translation took (also a slightly misread variant, 玩氵去奖励, and what an online translator made of it)
    if ($c -match '^玩[法氵].{0,2}[奖獎].{0,2}$' -and $c.Length -le 7) { return $rw }
    if ($c -match '^玩[法氵].{0,2}[奖獎]' -and $en -match '(?i)game ?mode rewards?|gameplay rewards?|play(?: for)? rewards?|game rewards?|mode rewards?|duel rewards?') { return ($en -replace '(?i)game ?mode rewards?|gameplay rewards?|play(?: for)? rewards?|game rewards?|mode rewards?|duel rewards?', $rw) }
    $h = ($cn -replace '[^\u4e00-\u9fff]', '')
    if ($h -eq '匹配') { if ($spar) { return 'Casual' }; return 'Matchmaking' }
    if ($h -eq '娱乐' -and $spar) { return 'Fun' }
    # a misread character in front of 匹配 once came out as "coward match"
    if ($h.Length -eq 3 -and $h.EndsWith('匹配') -and -not $script:Dict.ContainsKey((Get-NormKey $h))) { if ($spar) { return 'Casual' }; return 'Matchmaking' }
    return $en
}
function Fix-Brackets([string]$cn, [string]$en) {
    # a text wholly inside brackets keeps them in English: 【X】 -> [X], 《X》 / 「X」 -> "X", （X） -> (X)
    if ([string]::IsNullOrWhiteSpace($en)) { return $en }
    $c = $cn.Trim(); $e = $en.Trim()
    $m = [regex]::Match($c, '^([【《（(「『〔［\[])[^【】《》（）()「」『』〔〕［］\[\]]+([】》）)」』〕］\]])$')
    if (-not $m.Success) { return $en }
    $e = $e.Trim('[', ']', '(', ')', '"', "'", '“', '”', '«', '»', ' ')
    switch ($m.Groups[1].Value) {
        { $_ -in '【', '〔', '［', '[' } { return '[' + $e + ']' }
        { $_ -in '（', '(' } { return '(' + $e + ')' }
        default { return '"' + $e + '"' }
    }
}
function Fix-LeftoverHan([string]$en) {
    if ([string]::IsNullOrEmpty($en) -or -not [regex]::IsMatch($en, '[\u4e00-\u9fff]')) { return $en }
    $r = [regex]::Replace($en, '[\u4e00-\u9fff]+', {
        param($m)
        $v = $m.Value
        $nk = Get-NormKey $v
        if ($script:Dict.ContainsKey($nk)) { return ' ' + [string]$script:Dict[$nk] + ' ' }
        $o = ''
        foreach ($ch in $v.ToCharArray()) { $w = $script:HanOne[[string]$ch]; if ($null -ne $w) { if ($w) { $o += ' ' + $w + ' ' } } else { $o += [string]$ch } }
        return $o
    })
    return ([regex]::Replace($r, '\s{2,}', ' ')).Trim()
}
function Fix-Counter([string]$src, [string]$en) {
    # the source ends in a counter "N（A/B）" (the OCR often loses the slash or a bracket): show it as "N (A/B)"
    if ([string]::IsNullOrEmpty($en)) { return $en }
    $m = [regex]::Match($src, '(\d+)\s*[\(\uff08]?\s*(\d{1,4})\s*[/\uff0f\s]\s*(\d{1,4})\s*[\)\uff09]\s*$')
    if (-not $m.Success) { $m = [regex]::Match($src, '(\d+)\s*[\(\uff08]\s*(\d{1,4})\s*[/\uff0f\s]\s*(\d{1,4})\s*[\)\uff09]?\s*$') }
    if (-not $m.Success) { return $en }
    $a = $m.Groups[1].Value; $b = $m.Groups[2].Value; $c = $m.Groups[3].Value
    $pat = [regex]::Escape($a) + '\s*[\(\uff08]?\s*' + [regex]::Escape($b) + '\s*[/\uff0f\s]?\s*' + [regex]::Escape($c) + '\s*[\)\uff09]?'
    $fixed = ([regex]$pat).Replace($en, ($a + ' (' + $b + '/' + $c + ')'), 1)
    return $fixed
}
function Get-FrameHash($bmp) {
    if ($script:Glass2Ok) { try { return [StarGlass2]::Hash($bmp) } catch { Write-Log ('hash: ' + $_.Exception.Message) } }
    # 40x24 sample grid, 4 bits per channel
    $sb = New-Object System.Text.StringBuilder
    $sx = [Math]::Max(8, [int]($bmp.Width / 40))
    $sy = [Math]::Max(8, [int]($bmp.Height / 24))
    for ($y = 0; $y -lt $bmp.Height; $y += $sy) {
        for ($x = 0; $x -lt $bmp.Width; $x += $sx) {
            $c = $bmp.GetPixel($x, $y)
            [void]$sb.Append(('{0:X1}{1:X1}{2:X1}' -f ([int]$c.R -shr 4), ([int]$c.G -shr 4), ([int]$c.B -shr 4)))
        }
    }
    return $sb.ToString()
}
function Test-FrameChanged([string]$a, [string]$b) {
    if ($script:Glass2Ok -and $a -and $a.Contains(';')) { try { return [StarGlass2]::Changed($a, $b) } catch { return $true } }
    if (-not $a -or -not $b -or $a.Length -ne $b.Length) { return $true }
    $diff = 0
    for ($i = 0; $i -lt $a.Length; $i += 3) {
        if ($a[$i] -ne $b[$i] -or $a[$i+1] -ne $b[$i+1] -or $a[$i+2] -ne $b[$i+2]) { $diff++ }
    }
    return ($diff -ge 8)
}
$script:DirectOcr = $true
$script:DirectLogged = $false
function Get-OcrResult($bmpIn) {
    if ($script:DirectOcr) {
        # fast path: hand the raw pixels to the OCR engine (no BMP encode / decode)
        try {
            $raw = [StarRaw]::Bytes($bmpIn)
            $buf = [System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions]::AsBuffer($raw)
            $sb0 = [Windows.Graphics.Imaging.SoftwareBitmap]::CreateCopyFromBuffer($buf, [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [int]$bmpIn.Width, [int]$bmpIn.Height, [Windows.Graphics.Imaging.BitmapAlphaMode]::Ignore)
            $r0 = Await-WinRT ($script:OcrEngine.RecognizeAsync($sb0)) ([Windows.Media.Ocr.OcrResult])
            try { $sb0.Dispose() } catch {}
            if (-not $script:DirectLogged) { $script:DirectLogged = $true; Write-Log 'ocr: direct pixel path active' }
            return $r0
        } catch {
            $script:DirectOcr = $false
            Write-Log ('ocr: direct pixel path unavailable, using bitmap decode (' + $_.Exception.Message + ')')
        }
    }
    $ms = New-Object System.IO.MemoryStream
    $bmpIn.Save($ms, [System.Drawing.Imaging.ImageFormat]::Bmp)
    $bytes = $ms.ToArray(); $ms.Dispose()
    $ras = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
    $writer = [Windows.Storage.Streams.DataWriter]::new($ras.GetOutputStreamAt(0))
    $writer.WriteBytes($bytes)
    $null = Await-WinRT ($writer.StoreAsync()) ([uint32])
    $writer.DetachStream() | Out-Null
    $ras.Seek(0)
    $dec = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $fmt = [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8
    $alpha = [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied
    $sb = $null
    try {
        $sb = Await-WinRT ($dec.GetSoftwareBitmapAsync($fmt, $alpha)) ([Windows.Graphics.Imaging.SoftwareBitmap])
    } catch {
        $sb = Await-WinRT ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $sb = [Windows.Graphics.Imaging.SoftwareBitmap]::Convert($sb, $fmt, $alpha)
    }
    return (Await-WinRT ($script:OcrEngine.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult]))
}
function Get-RegionColor($bmp, $x, $y, $w, $h) {
    $x = [int]$x; $y = [int]$y; $w = [int]$w; $h = [int]$h
    $rs = 0; $gs = 0; $bs = 0; $n = 0
    $xs = @(($x - 4), ($x + $w + 4), ($x + [int]($w / 2)), ($x + [int]($w / 2)))
    $ys = @(($y + [int]($h / 2)), ($y + [int]($h / 2)), ($y - 4), ($y + $h + 4))
    for ($i = 0; $i -lt 4; $i++) {
        $px = [int]$xs[$i]
        $py = [int]$ys[$i]
        if ($px -lt 0) { $px = 0 }
        if ($py -lt 0) { $py = 0 }
        if ($px -ge $bmp.Width) { $px = $bmp.Width - 1 }
        if ($py -ge $bmp.Height) { $py = $bmp.Height - 1 }
        $c = $bmp.GetPixel($px, $py)
        $rs += [int]$c.R; $gs += [int]$c.G; $bs += [int]$c.B; $n++
    }
    if ($n -eq 0) { return @{ r = 28; g = 28; b = 32 } }
    return @{ r = [int]($rs / $n); g = [int]($gs / $n); b = [int]($bs / $n) }
}
# ---------- v2: attach to the game ----------
$script:Game = $null
$script:GameSeen = $false
$script:GoneTicks = 0
$script:HideOverlay = $true
$script:LastRect = $null
$script:LastScanMs = 0
$script:Clk = [System.Diagnostics.Stopwatch]::StartNew()
$script:Perf = @{ reuse = 0; fresh = 0; snap = 0; shift = 0; glyph = 0; icon = 0 }
$script:LayMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal)
function Get-GameInfo {
    $name = [string]$script:Settings.gameProcess
    if ([string]::IsNullOrWhiteSpace($name)) { return $null }
    $procs = @(Get-Process -Name $name -ErrorAction SilentlyContinue)
    if ($procs.Count -eq 0) { return $null }
    foreach ($p in $procs) {
        try { $p.Refresh(); if ($p.MainWindowHandle -ne [IntPtr]::Zero) { return @{ pid = $p.Id; hwnd = $p.MainWindowHandle } } } catch {}
    }
    return @{ pid = $procs[0].Id; hwnd = [IntPtr]::Zero }
}
function Get-GameClientRect {
    $gi = $script:Game
    if (-not $gi -or $gi.hwnd -eq [IntPtr]::Zero) { return $null }
    if ([HSNative]::IsIconic($gi.hwnd)) { return $null }
    $rc = New-Object HSNative+RECT
    if (-not [HSNative]::GetClientRect($gi.hwnd, [ref]$rc)) { return $null }
    $pt = New-Object HSNative+POINT
    if (-not [HSNative]::ClientToScreen($gi.hwnd, [ref]$pt)) { return $null }
    $w = $rc.Right - $rc.Left; $h = $rc.Bottom - $rc.Top
    if ($w -lt 200 -or $h -lt 200) { return $null }
    return New-Object System.Drawing.Rectangle $pt.X, $pt.Y, $w, $h
}
$script:GameElevated = $false
function Test-GameElevated($pid2) {
    if ($script:IsAdmin) { return $false }
    try { $p = [System.Diagnostics.Process]::GetProcessById([int]$pid2); $null = $p.MainModule; return $false } catch { return $true }
}
function Update-GameState {
    $script:Game = Get-GameInfo
    $fgPid = [uint32]0
    try { [HSNative]::GetWindowThreadProcessId([HSNative]::GetForegroundWindow(), [ref]$fgPid) | Out-Null } catch {}
    $was = $script:HideOverlay
    if ($script:Game) {
        if (-not $script:ElevChecked -or $script:ElevPid -ne $script:Game.pid) { $script:ElevPid = $script:Game.pid; $script:ElevChecked = $true; $script:GameElevated = Test-GameElevated $script:Game.pid; if ($script:GameElevated) { Write-Log 'game runs elevated: start Starfire Lite as administrator' } }
        $script:GameSeen = $true; $script:GoneTicks = 0
        if (-not $script:OfficialTried) { Import-OfficialStrings }
        $script:HideOverlay = ($script:Settings.captureMode -eq 'game' -and [int]$fgPid -ne [int]$script:Game.pid)
    } else {
        $script:HideOverlay = ($script:Settings.captureMode -eq 'game')
        if ($script:GameSeen) {
            $script:GoneTicks++
            if ($script:GoneTicks -ge 3 -and $script:Settings.exitWithGame -and $script:Settings.captureMode -eq 'game') { Write-Log 'game closed - exiting'; Cleanup-And-Exit; return }
        } elseif ($script:Settings.captureMode -eq 'game') { $script:Status = 'waiting for ' + $script:Settings.gameProcess }
    }
    if ($was -ne $script:HideOverlay) { try { $script:Overlay.Invalidate() } catch {} }
}
function Toggle-Debug {
    return                                      # disabled in released builds
    $script:Settings.debug = -not [bool]$script:Settings.debug
    Save-Settings
    if ($script:Settings.debug) { Show-Notice 'Starfire Lite: debug ON' } else { Show-Notice 'Starfire Lite: debug OFF' }
    try { if ($script:Settings.debug) { $script:DebugItem.Text = 'Debug overlay: ON   (F7)' } else { $script:DebugItem.Text = 'Debug overlay: off   (F7)' } } catch {}
    try { $script:Overlay.Invalidate() } catch {}
}
function Toggle-ExitWithGame {
    $script:Settings.exitWithGame = -not [bool]$script:Settings.exitWithGame
    Save-Settings
}
function Get-CaptureRect {
    $mode = [string]$script:Settings.captureMode
    if ($mode -eq 'game') { return (Get-GameClientRect) }
    if ($mode -eq 'region' -and $script:Settings.region) {
        $r = $script:Settings.region
        return New-Object System.Drawing.Rectangle ([int]$r.x), ([int]$r.y), ([int]$r.w), ([int]$r.h)
    }
    if ($mode -eq 'activewindow') {
        try {
            $hwnd = [HSNative]::GetForegroundWindow()
            $my = [System.Diagnostics.Process]::GetCurrentProcess().Id
            $wp = [uint32]0
            [HSNative]::GetWindowThreadProcessId($hwnd, [ref]$wp) | Out-Null
            if ($wp -ne $my -and [HSNative]::IsWindowVisible($hwnd)) {
                $rc = New-Object HSNative+RECT
                if ([HSNative]::GetWindowRect($hwnd, [ref]$rc)) {
                    $w = $rc.Right - $rc.Left; $h = $rc.Bottom - $rc.Top
                    if ($w -gt 200 -and $h -gt 200) { return New-Object System.Drawing.Rectangle $rc.Left, $rc.Top, $w, $h }
                }
            }
        } catch {}
    }
    $v = [System.Windows.Forms.SystemInformation]::VirtualScreen
    return New-Object System.Drawing.Rectangle $v.X, $v.Y, $v.Width, $v.Height
}
# ---------- v1.1: text tracking so labels stay seated and only move when the text really moves ----------
$script:TtcErr = 0
$script:Tracks = New-Object System.Collections.Generic.List[object]
$script:LastMoved = 0
$script:MotionBoost = 0
$script:Unconf = 0
$script:SameStreak = 0
function Get-TextSim([string]$a, [string]$b) {
    if (-not $a -or -not $b) { return 0.0 }
    $common = 0
    foreach ($ch in $a.ToCharArray()) { if ($b.IndexOf($ch) -ge 0) { $common++ } }
    return ($common / [double][Math]::Max($a.Length, $b.Length))
}
$script:MeasBmp = New-Object System.Drawing.Bitmap 8, 8
$script:MeasG = [System.Drawing.Graphics]::FromImage($script:MeasBmp)
try { $script:MeasG.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit } catch {}
$script:FrameBmp = $null; $script:FrameRect = $null; $script:GlassAt = $null
function Get-TextScale([string]$src, [int]$lines, [double]$em) {
    # short phrases and big menu text are set larger than the Chinese glyphs, long descriptions smaller
    $n = ([regex]::Replace($src, '\s', '')).Length
    $k = 0.86
    if ($lines -ge 4 -or $n -gt 60) { $k = 0.56 }
    elseif ($lines -ge 2 -or $n -gt 24) { $k = 0.62 }
    elseif ($n -le 3) { $k = 0.80 }
    elseif ($n -le 6) { $k = 0.77 }
    elseif ($n -le 12) { $k = 0.72 }
    else { $k = 0.66 }
    return $k
}
function Build-Glass($b, $bmp, $rect) {
    if (-not $script:Settings.glass -or -not $bmp -or -not $rect) { return }
    if ([int]$b.lw -le 0) { return }
    $rad = [int]$script:Settings.glassBlur; if ($rad -lt 0) { $rad = 0 }; if ($rad -gt 8) { $rad = 8 }
    $tintP = [int]$script:Settings.glassTint
    $gx = ([int]$b.lx - $rect.X); $gy = ([int]$b.ly - $rect.Y)
    if ($script:Glass2Ok) {
        # flat square box: strokes removed by filling from the surrounding picture, then a light blur
        if ([int]$b.tw -gt 0) {
            # only the area of the Chinese text is cleaned; the rest of the label shows the picture exactly as it is
            $ng = [StarGlass2]::MakeT($bmp, $gx, $gy, [int]$b.lw, [int]$b.lh, ([int]$b.tx - $rect.X), ([int]$b.ty - $rect.Y), [int]$b.tw, [int]$b.th, $rad, $tintP)
        } else {
            $ng = [StarGlass2]::Make($bmp, $gx, $gy, [int]$b.lw, [int]$b.lh, $rad, $tintP, 0)
        }
        $b.gR = [StarGlass2]::TR; $b.gG = [StarGlass2]::TG; $b.gB = [StarGlass2]::TB; $b.gLum = [StarGlass2]::Lum
        if ([StarGlass2]::InkOk) { $b.iR = [StarGlass2]::IR; $b.iG = [StarGlass2]::IG; $b.iB = [StarGlass2]::IB; $b.iOk = $true }
    } else {
        $ng = [StarGlass]::Make($bmp, $gx, $gy, [int]$b.lw, [int]$b.lh, $rad, 12, 0)
        $b.gR = [StarGlass]::TR; $b.gG = [StarGlass]::TG; $b.gB = [StarGlass]::TB; $b.gLum = [StarGlass]::Lum
    }
    $old = $b.glass; $b.glass = $ng; $b.gT = [int64]$script:Clk.ElapsedMilliseconds
    if ($old) { try { $old.Dispose() } catch {} }
}
function Wrap-Words([string]$text, $f, [double]$maxW) {
    # greedy wrap on word boundaries only; a word wider than maxW stays whole on its own row (never split)
    $big = New-Object System.Drawing.SizeF ([single]4000), ([single]200)
    if ($maxW -ge 100000) {
        # single-row probe: one measurement is enough
        $one = $script:MeasG.MeasureString($text, $f, $big)
        return @{ text = $text; n = 1; w = [double]$one.Width; h = [double]$one.Height; lw = 0.0 }
    }
    $words = @($text -split '\s+' | Where-Object { $_.Length -gt 0 })
    $rows = New-Object System.Collections.Generic.List[string]
    $cur = ''; $curW = 0.0; $maxRow = 0.0; $longest = 0.0
    foreach ($wd in $words) {
        $ww = [double]$script:MeasG.MeasureString($wd, $f, $big).Width
        if ($ww -gt $longest) { $longest = $ww }
        if ($cur -eq '') { $cur = $wd; $curW = $ww; continue }
        $try = $cur + ' ' + $wd
        $tw = [double]$script:MeasG.MeasureString($try, $f, $big).Width
        if ($tw -le $maxW) { $cur = $try; $curW = $tw }
        else {
            [void]$rows.Add($cur); if ($curW -gt $maxRow) { $maxRow = $curW }
            $cur = $wd; $curW = $ww
        }
    }
    if ($cur -ne '') { [void]$rows.Add($cur); if ($curW -gt $maxRow) { $maxRow = $curW } }
    $joined = ($rows.ToArray()) -join "`n"
    $h = [double]$script:MeasG.MeasureString($joined, $f, (New-Object System.Drawing.SizeF ([single]4000), ([single]1200))).Height
    return @{ text = $joined; n = $rows.Count; w = $maxRow; h = $h; lw = $longest }
}
$script:FontCache = @{}
$script:FitMemo = @{}
function Get-BoldFont([single]$pt) {
    # the same few sizes (8.5 - 22 px in half steps) are used all the time: keep the fonts instead of creating one per measurement / paint
    $fk = ([double]$pt).ToString('0.0', [System.Globalization.CultureInfo]::InvariantCulture)
    if ($script:FontCache.ContainsKey($fk)) { return $script:FontCache[$fk] }
    if ($script:FontCache.Count -ge 80) { foreach ($fo in @($script:FontCache.Values)) { try { $fo.Dispose() } catch {} }; $script:FontCache = @{} }
    $nf0 = New-Object System.Drawing.Font 'Segoe UI', ([single]$fk), ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
    $script:FontCache[$fk] = $nf0
    return $nf0
}
function Get-Fit([string]$text, [single]$pt, [double]$maxW) {
    $mk = ([double]$pt).ToString('0.0', [System.Globalization.CultureInfo]::InvariantCulture) + '|' + [int][Math]::Min($maxW, 1000000) + '|' + $text
    if ($script:FitMemo.ContainsKey($mk)) { return $script:FitMemo[$mk] }
    if ($script:FitMemo.Count -gt 1500) { $script:FitMemo = @{} }
    $r0 = Wrap-Words $text (Get-BoldFont $pt) $maxW
    $script:FitMemo[$mk] = $r0
    return $r0
}
function Layout-Block($b, $bmp, $rect) {
    $text = [string]$b.en
    if ([string]::IsNullOrWhiteSpace($text)) { return }
    $text = ($text -replace '\s*[\r\n]+\s*', ' ').Trim()
    $em = [double]$b.em; if ($em -lt 6) { $em = 14.0 }
    $pad = [int]$b.pad
    $padH = [Math]::Max(2, [int][Math]::Round($pad * 0.6)); $padV = $pad
    $cx = [int]$b.x; $cy = [int]$b.y
    $cw = [int][Math]::Max(8, [int]$b.w); $ch = [int][Math]::Max(10, [int]$b.h)      # the Chinese text box
    # an icon that the OCR box swallowed (the gate in front of "房间"): when the box is clearly wider than the text needs and
    # its first / last bright block is a separate icon-sized shape, the label works on the text only - so the glass and the
    # centred label do not sit over the icon
    if ($script:MaskOk -and $bmp -and $rect -and [int]$b.lines -le 1 -and $cw -ge (1.8 * $ch)) {
        try {
            $srcT = ([string]$b.src).Trim()
            $symEnd = ($srcT.Length -gt 1 -and ($srcT -match '^[^\u4e00-\u9fffA-Za-z0-9]' -or $srcT -match '[^\u4e00-\u9fffA-Za-z0-9]$'))      # the OCR read the icon as a symbol character
            $exw = 0.0; $nHan0 = 0
            foreach ($c0 in $srcT.ToCharArray()) {
                if ([int]$c0 -ge 0x4E00 -and [int]$c0 -le 0x9FFF) { $exw += 1.0; $nHan0++ }
                elseif ([char]::IsLetterOrDigit($c0)) { $exw += 0.55 }
                elseif (-not [char]::IsWhiteSpace($c0) -and -not $symEnd) { $exw += 0.55 }      # with an icon read as symbols, those symbols are the icon, not text width
            }
            $exw = $exw * $ch
            $iconCut = $false
            $exMin = 0.7; if ($symEnd) { $exMin = 0.45 }
            if ($exw -gt 0 -and ($cw - $exw) -ge ($exMin * $ch)) {
                $gm0 = [int][Math]::Max(8, [Math]::Round(0.45 * $ch)); if ($symEnd) { $gm0 = [int][Math]::Max(4, [Math]::Round(0.2 * $ch)) }
                $sg0 = [StarMask]::ColumnSegs($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $gm0)
                $ns = [int]($sg0.Length / 2)
                if ($ns -ge 2) {
                    $iconMax = 1.6 * $ch
                    $a0 = [int]$sg0[0]; $a1 = [int]$sg0[1]; $z0 = [int]$sg0[2 * ($ns - 1)]; $z1 = [int]$sg0[2 * ($ns - 1) + 1]
                    $newL = 0; $newR = $cw
                    if (($a1 - $a0 + 1) -le $iconMax -and ($z1 - [int]$sg0[2] + 1) -ge (0.6 * $exw)) { $newL = [Math]::Max(0, [int]$sg0[2] - 2) }
                    if ($ns -ge 2 -and ($z1 - $z0 + 1) -le $iconMax -and ([int]$sg0[2 * ($ns - 2) + 1] - $newL + 1) -ge (0.6 * $exw)) { $newR = [Math]::Min($cw, [int]$sg0[2 * ($ns - 2) + 1] + 3) }
                    if (($newL -gt 0 -or $newR -lt $cw) -and ($newR - $newL) -ge (0.6 * $exw)) { $cx = $cx + $newL; $cw = $newR - $newL; $iconCut = $true }
                }
            }
            # the column scan found no clean split (white text: icon and letters equally bright): the text is the Han characters only,
            # one line height each, on the side away from the symbols the OCR made of the icon
            if (-not $iconCut -and $symEnd -and $nHan0 -ge 1 -and $srcT -notmatch '[A-Za-z0-9]') {
                $lead = ($srcT -match '^[^\u4e00-\u9fff]'); $trail = ($srcT -match '[^\u4e00-\u9fff]$')
                $tw0 = [int][Math]::Round($nHan0 * 1.08 * $ch)
                if ($lead -xor $trail) {
                    if (($cw - $tw0) -ge (0.45 * $ch)) {
                        if ($lead) { $cx = $cx + ($cw - $tw0) }
                        $cw = $tw0
                        $script:Perf.icon = [int]$script:Perf.icon + 1
                    }
                }
            }
        } catch {}
    }
    # icons / pips / check boxes beside the text that the OCR never read: measured once, on the box as read, so that neither the
    # growth to the ink below nor the glass can run into them
    $ndN = [int][Math]::Min(140, [Math]::Max(24, [Math]::Round(2.2 * $ch))); $ngL = $ndN; $ngR = $ndN; $grL = 0; $grR = 0
    if ($script:MaskOk -and $bmp -and $rect) {
        try {
            $ngL = [int][StarMask]::NeighborGap($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $ndN, -1)
            $ngR = [int][StarMask]::NeighborGap($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $ndN, 1)
        } catch { $ngL = $ndN; $ngR = $ndN }
    }
    # the OCR rectangle is often a little tighter than the real strokes: grow it to the ink that is actually on screen
    if ($script:Glass2Ok -and $bmp -and $rect) {
        try {
            $mgx = [int][Math]::Max(4, [Math]::Round($ch * 0.45)); $mgy = [int][Math]::Max(4, [Math]::Round($ch * 0.3))
            $ib = [StarGlass2]::InkBounds($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $mgx, $mgy)
            if ($ib -and $ib.Length -eq 4) {
                # never grow into something else that was scanned (icons, other text)
                $gL = 100000; $gR = 100000; $gT = 100000; $gB = 100000
                $vm0 = [Math]::Max(2, [int][Math]::Round(0.15 * $ch)); $hm0 = [Math]::Max(2, [int][Math]::Round(0.15 * $cw))
                foreach ($lst0 in @($script:Obst, $script:Sym)) {
                    foreach ($o0 in @($lst0)) {
                        if ($null -eq $o0) { continue }
                        $ox0 = [int]$o0.x; $oy0 = [int]$o0.y; $ow0 = [int]$o0.w; $oh0 = [int]$o0.h
                        if ($ow0 -le 0 -or $oh0 -le 0) { continue }
                        $ix0 = [Math]::Min($ox0 + $ow0, $cx + $cw) - [Math]::Max($ox0, $cx)
                        $iy0 = [Math]::Min($oy0 + $oh0, $cy + $ch) - [Math]::Max($oy0, $cy)
                        if ($ix0 -gt 0 -and $iy0 -gt 0 -and (($ix0 * $iy0) -gt (0.5 * $ow0 * $oh0))) { continue }
                        if (($oy0 -lt ($cy + $ch - $vm0)) -and (($oy0 + $oh0) -gt ($cy + $vm0))) {
                            if ($ox0 -ge ($cx + $cw - 2)) { $gR = [Math]::Min($gR, $ox0 - ($cx + $cw) - 1) }
                            elseif (($ox0 + $ow0) -le ($cx + 2)) { $gL = [Math]::Min($gL, $cx - ($ox0 + $ow0) - 1) }
                        }
                        if (($ox0 -lt ($cx + $cw - $hm0)) -and (($ox0 + $ow0) -gt ($cx + $hm0))) {
                            if ($oy0 -ge ($cy + $ch - 2)) { $gB = [Math]::Min($gB, $oy0 - ($cy + $ch) - 1) }
                            elseif (($oy0 + $oh0) -le ($cy + 2)) { $gT = [Math]::Min($gT, $cy - ($oy0 + $oh0) - 1) }
                        }
                    }
                }
                $d0 = [Math]::Min([int]$ib[0], [Math]::Max(0, $gL)); $d1 = [Math]::Min([int]$ib[1], [Math]::Max(0, $gT))
                $d2 = [Math]::Min([int]$ib[2], [Math]::Max(0, $gR)); $d3 = [Math]::Min([int]$ib[3], [Math]::Max(0, $gB))
                if ($ngL -lt $ndN) { $d0 = [Math]::Min($d0, [Math]::Max(0, $ngL - 5)) }
                if ($ngR -lt $ndN) { $d2 = [Math]::Min($d2, [Math]::Max(0, $ngR - 5)) }
                $grL = $d0; $grR = $d2
                $cx = $cx - $d0; $cy = $cy - $d1; $cw = $cw + $d0 + $d2; $ch = $ch + $d1 + $d3
            }
        } catch {}
    }
    $b.tx = $cx; $b.ty = $cy; $b.tw = $cw; $b.th = $ch          # the area of the Chinese text (cleaned of strokes in the glass)
    $padB = $padV + [Math]::Max(2, [int][Math]::Round($ch * 0.11))       # a little more below: glow / shadow under bright (gold) text peeked out
    $single = ([int]$b.lines -le 1)
    $vs2 = [System.Windows.Forms.SystemInformation]::VirtualScreen
    # keep clear of everything else that was scanned (other text, icons, check marks, numbers, boxes read as characters)
    $bx = $cx - $padH; $by = $cy - $padV; $bRight = $cx + $cw + $padH; $bBot = $cy + $ch + $padB
    $rightMax = [double]$vs2.Right; $leftMin = [double]$vs2.Left; $topMin = [double]$vs2.Top; $botMax = [double]$vs2.Bottom
    foreach ($lst in @($script:Obst, $script:Sym)) {
        foreach ($o in @($lst)) {
            if ($null -eq $o) { continue }
            $ox = [int]$o.x; $oy = [int]$o.y; $ow = [int]$o.w; $oh = [int]$o.h
            if ($ow -le 0 -or $oh -le 0) { continue }
            if ($ox -gt ($bRight + 700) -or ($ox + $ow) -lt ($bx - 120)) { continue }
            $ix = [Math]::Min($ox + $ow, $cx + $cw) - [Math]::Max($ox, $cx)
            $iy = [Math]::Min($oy + $oh, $cy + $ch) - [Math]::Max($oy, $cy)
            if ($ix -gt 0 -and $iy -gt 0 -and (($ix * $iy) -gt (0.5 * $ow * $oh))) { continue }       # part of this very label
            $vm = [Math]::Max(2, [int][Math]::Round(0.15 * $ch))                                   # only things level with the text itself block the sides
            $vOver = ($oy -lt ($cy + $ch - $vm)) -and (($oy + $oh) -gt ($cy + $vm))
            $hOver = ($ox -lt $bRight) -and (($ox + $ow) -gt $bx)
            if ($vOver) {
                if ($ox -ge ($cx + $cw - 2)) { if (($ox - 2) -lt $rightMax) { $rightMax = $ox - 2 } }
                elseif (($ox + $ow) -le ($cx + 2)) { if (($ox + $ow + 2) -gt $leftMin) { $leftMin = $ox + $ow + 2 } }
            }
            if ($hOver) {
                if (($oy + $oh) -le ($cy + 2)) { if (($oy + $oh + 1) -gt $topMin) { $topMin = $oy + $oh + 1 } }
                elseif ($oy -ge ($cy + $ch - 2)) { if (($oy - 1) -lt $botMax) { $botMax = $oy - 1 } }
            }
        }
    }
    # icons / pips / check boxes beside the text (measured above): the label's glass and room end 5 px before them
    $leftMinO = $leftMin; $rightMaxO = $rightMax          # limits set by scanned text / symbols only (a missed character is no icon)
    if ($ngL -lt $ndN) { $leftMin = [Math]::Max($leftMin, [double]($cx - [Math]::Max(0, $ngL - $grL) + 5)) }
    if ($ngR -lt $ndN) { $rightMax = [Math]::Min($rightMax, [double]($cx + $cw + [Math]::Max(0, $ngR - $grR) - 5)) }
    if ($leftMin -gt $bx) { $bx = [int][Math]::Min($cx, $leftMin) }
    if ($rightMax -lt $bRight) { $bRight = [int][Math]::Max($cx + $cw, $rightMax) }
    if ($topMin -gt $by) { $by = [int][Math]::Min($cy, $topMin) }
    if ($botMax -lt $bBot) { $bBot = [int][Math]::Max($cy + $ch, $botMax) }
    # gold glow / calligraphy right next to the label (Martial Tournament title): the glass covers it. Done here, once per
    # layout, because layouts are reused while the text sits still (changing the block every scan made labels shift)
    if ($script:MaskOk -and $bmp -and $rect -and ([double]$ch / [Math]::Max(1, [int]$b.lines)) -ge 14 -and $single) {
        try {
            $cap0 = [int][Math]::Round(0.4 * [double]$ch)
            $ge = [StarMask]::InkExtent($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $cap0, 120, 35)
            if ($ge -and $ge.Length -ge 4) {
                $bx = [int][Math]::Max([Math]::Max($leftMin, $bx - [int]$ge[2]), $bx - $cap0)
                $bRight = [int][Math]::Min([Math]::Min($rightMax, $bRight + [int]$ge[3]), $bRight + $cap0)
                $by = [int][Math]::Max([Math]::Max($topMin, $by - [int]$ge[0]), $by - $cap0)
                $bBot = [int][Math]::Min([Math]::Min($botMax, $bBot + [int]$ge[1]), $bBot + $cap0)
            }
        } catch {}
    }
    # a character of the original the OCR box left out (the 天 beside 下会武): glyph-sized ink right next to the label, on either
    # side, is covered too - unless another scanned text / symbol is in the way. Kept with the layout, so it stays put.
    $nHanB = ([regex]::Matches([string]$b.src, '[\u4e00-\u9fff]')).Count
    if ($script:MaskOk -and $bmp -and $rect -and $single -and $nHanB -ge 3) {      # short flags and buttons (匹配, 说明) never: their sides are the button
        try {
            $fg0 = [int][Math]::Max(3, $ch / 3)
            $gr = [StarMask]::GlyphReach($bmp, ($bx - $rect.X), ($cy - $rect.Y), ($bRight - $bx), $ch, [int][Math]::Round(1.4 * [double]$ch), $fg0)
            if ($gr -and $gr.Length -ge 2 -and ([int]$gr[0] -gt 0 -or [int]$gr[1] -gt 0)) {
                $eL = [int][Math]::Min([int]$gr[0], [Math]::Max(0.0, $bx - $leftMinO))
                $eR = [int][Math]::Min([int]$gr[1], [Math]::Max(0.0, $rightMaxO - $bRight))
                if ($eL -gt 0 -or $eR -gt 0) {
                    $bx = $bx - $eL; $bRight = $bRight + $eR
                    # the covered characters are Chinese text too: cleaned out of the glass (else they show through, frosted)
                    $b.tx = [int]$b.tx - $eL; $b.tw = [int]$b.tw + $eL + $eR
                    try {
                        $vx = [StarMask]::InkExtent($bmp, ([int]$b.tx - $rect.X), ($cy - $rect.Y), [int]$b.tw, $ch, [int][Math]::Round(0.6 * [double]$ch), 120, 35)
                        if ($vx -and $vx.Length -ge 2) {
                            $uT = [int][Math]::Min([int]$vx[0], [Math]::Max(0.0, $by - $topMin)); $uB = [int][Math]::Min([int]$vx[1], [Math]::Max(0.0, $botMax - $bBot))
                            if ($uT -gt 0) { $by = $by - $uT }
                            if ($uB -gt 0) { $bBot = $bBot + $uB }
                            $b.ty = [int]$b.ty - $uT; $b.th = [int]$b.th + $uT + $uB
                        }
                    } catch {}
                    $script:Perf.glyph = [int]$script:Perf.glyph + 1
                    Write-Log ("extend: '" + $text + "' left=" + $eL + " right=" + $eR)
                }
            }
        } catch {}
    }
    $bw = $bRight - $bx; $bh = $bBot - $by
    $room = [Math]::Max(0.0, $rightMax - $bRight)
    $roomU = [Math]::Max(0.0, [double]($by - $topMin)); $roomD = [Math]::Max(0.0, $botMax - $bBot)
    # a button border / check box / panel edge to the right also ends the free room
    if ($script:Glass2Ok -and $bmp -and $rect -and $room -gt 0) {
        try {
            $er = [StarGlass2]::EdgeRoom($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, [int][Math]::Min($room + ($bRight - $cx - $cw), 700))
            $edgeRoom = [double]$er - ($bRight - $cx - $cw)
            if ($edgeRoom -lt $room) { $room = [Math]::Max(0.0, $edgeRoom) }
        } catch {}
    }
    # text centred on a button: with a button border found on BOTH sides at about the same distance, a label that has to
    # stretch grows evenly to both sides (and stays centred) instead of only to the right
    $ctr = $false; $symRoom = 0.0
    if ($script:Glass2Ok -and $bmp -and $rect) {
        try {
            $maxE = 520
            $erL = [int][StarGlass2]::EdgeRoomLeft($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $maxE)
            $erR = [int][StarGlass2]::EdgeRoom($bmp, ($cx - $rect.X), ($cy - $rect.Y), $cw, $ch, $maxE)
            if ($erL -lt $maxE -and $erR -lt $maxE -and $erL -ge 3 -and $erR -ge 3) {
                $totW = $erL + $erR + $cw
                if ([Math]::Abs($erL - $erR) -le (0.12 * $totW + 4) -and $totW -le 900) {
                    $ctr = $true
                    $roomLeft = [Math]::Min([Math]::Max(0.0, $bx - $leftMin), [double]($erL - $padH))
                    $symRoom = [Math]::Max(0.0, [Math]::Min($room, $roomLeft))
                }
            }
        } catch { $ctr = $false }
    }
    $nWords = @($text -split '\s+' | Where-Object { $_.Length -gt 0 }).Count
    # sizing: 85% of the glyph size, 11-22 px
    $basePt = [double][Math]::Min(22, [Math]::Max(11, $em * 0.85))
    $minPt = 10.0
    $floorPt = [Math]::Max($minPt, $basePt * 0.75)
    $pt = [single]$basePt
    $fit = $null; $ok = $false; $dw = $bw
    $screenCap = [Math]::Min(620, $vs2.Width - 20)
    if ($single) {
        # the box keeps the Chinese width. Only when the text cannot fit even after shrinking a little does the
        # box stretch to the RIGHT, by exactly what is needed (never beyond the free room, never to the left)
        if ($nWords -le 1) { $grow = [Math]::Min([Math]::Max($bw * 1.2, 90), $screenCap) } else { $grow = [Math]::Min([Math]::Max($bw * 1.6, 150), $screenCap) }      # one Chinese row stays one English row whenever there is free room
        if ($ctr) { $oneMax = $bw + [Math]::Min($grow, 2.0 * $symRoom) } else { $oneMax = $bw + [Math]::Min($grow, $room) }
        # smaller type is preferred over a second row: shrink down to half the normal size before wrapping
        $oneMin = [Math]::Max(8.5, $basePt * 0.5)
        for ($t = 0; $t -lt 80; $t++) {
            $fit = Get-Fit $text $pt 1000000
            $need = [Math]::Ceiling($fit.w) + 6
            if ($fit.h -le ($bh * 1.3) -or $pt -le $floorPt) {
                if ($need -le $bw) { $ok = $true; $dw = $bw; break }
                if ($pt -le $floorPt -and $need -le $oneMax) { $ok = $true; $dw = [int]$need; break }
            }
            if ($pt -le $oneMin) { break }
            $pt = [single]($pt - 0.5)
        }
    }
    if (-not $ok) {
        # wrap between words at the box width; shrink until the longest word fits, then (last resort) stretch right
        # first choice: no more English rows than the Chinese had (two at most for a one-row label), shrinking the type
        # to about 60 % if needed; only when that is impossible are extra rows used
        $maxRows = [Math]::Max(1, [int]$b.lines); if ($single) { $maxRows = 2 }
        $rowMin = [Math]::Max(8.5, $basePt * 0.6)
        $found = $false
        if ($single) { $pt = [single][Math]::Min($basePt, $floorPt) } else { $pt = [single]$basePt }
        for ($t = 0; $t -lt 80; $t++) {
            $fit = Get-Fit $text $pt ($bw - 8)
            $wordOk = (($fit.lw + 8) -le $bw)
            if ($wordOk -and [int]$fit.n -le $maxRows -and ($single -or $fit.h -le ($bh - 2))) { $found = $true; break }
            if ($pt -le $rowMin) { break }
            $pt = [single]($pt - 0.5)
        }
        if (-not $found) {
            $pt = [single]$basePt
            for ($t = 0; $t -lt 80; $t++) {
                $fit = Get-Fit $text $pt ($bw - 8)
                $wordOk = (($fit.lw + 8) -le $bw)
                if ($single) { $hOk = ($fit.h -le ($bh * 1.9)) } else { $hOk = ($fit.h -le ($bh - 2)) }
                if ($wordOk -and $hOk) { break }
                if ($pt -le $minPt -and $wordOk) { break }
                if ($pt -le 8.5) { break }
                $pt = [single]($pt - 0.5)
            }
        }
        $dw = $bw
        if (($fit.lw + 8) -gt $dw) {
            $dw = [int][Math]::Min([Math]::Ceiling($fit.lw) + 8, $vs2.Width - 10)
            $fit = Get-Fit $text $pt ($dw - 8)
        }
    }
    # rows need height: use the free space above / below, shrink the type when there is not enough
    $wrapW = 1000000.0; if (-not $ok) { $wrapW = [double]($dw - 8) }
    $needH = [int][Math]::Ceiling($fit.h) + 5
    $availH = $bh + $roomU + $roomD
    for ($t2 = 0; $t2 -lt 40; $t2++) {
        if ($needH -le $availH -or $pt -le 8.5) { break }
        $pt = [single]($pt - 0.5)
        $fit = Get-Fit $text $pt $wrapW
        $needH = [int][Math]::Ceiling($fit.h) + 5
    }
    $dh = $bh
    if ($needH -gt $dh) { $dh = $needH }
    $extra = $dh - $bh
    $up = [int][Math]::Min([int]($extra / 2), $roomU)
    $down = $extra - $up
    if ($down -gt $roomD) { $down = [int]$roomD; $up = $extra - $down }
    $dx = $bx; $dy = $by - $up
    if ($ctr -and $dw -gt ($bw + 1)) {
        $dx = $bx - [int][Math]::Round(($dw - $bw) / 2.0)
        if ($dx -lt $leftMin) { $dx = [int]$leftMin }
    }
    if ($dx + $dw -gt $vs2.Right) { $dx = $vs2.Right - $dw }
    if ($dx -lt $vs2.Left) { $dx = $vs2.Left }
    if ($dy + $dh -gt $vs2.Bottom) { $dy = $vs2.Bottom - $dh }
    if ($dy -lt $vs2.Top) { $dy = $vs2.Top }
    # rows are already broken on word boundaries (explicit line breaks), so the painter never wraps by itself
    $b.lx = $dx; $b.ly = $dy; $b.lw = $dw; $b.lh = $dh; $b.pt = [double]$pt; $b.nw = $true; $b.ext = ($dw -gt ($bw + 1)); $b.ctr = ($ctr -and ($dw -gt ($bw + 1))); $b.txt = [string]$fit.text
    try { Build-Glass $b $bmp $rect } catch { Write-Log "glass: $($_.Exception.Message)" }
}
function Update-Glass($bmp, $rect) {
    # keep the frosted backgrounds in step with the picture behind them (moving backgrounds)
    if (-not $script:Settings.glass -or -not $bmp -or -not $rect) { return }
    if ($script:GlassAt -and ((Get-Date) - $script:GlassAt).TotalMilliseconds -lt 250) { return }
    $script:GlassAt = Get-Date
    foreach ($b in @($script:LastBlocks)) {
        if (-not $b -or [int]$b.lw -le 0) { continue }
        try {
            Build-Glass $b $bmp $rect
            $ir = New-Object System.Drawing.Rectangle ([int]$b.lx - $script:Overlay.Left), ([int]$b.ly - $script:Overlay.Top), ([int]$b.lw), ([int]$b.lh)
            $script:Overlay.Invalidate($ir)
        } catch { Write-Log "glass refresh: $($_.Exception.Message)" }
    }
}
$script:GlassBusy = $false
$script:LiveFrame = $null
function Refresh-GlassLive {
    # live background: re-sample the picture under every label several times a second (independent of OCR scans)
    # and rebuild only the glass whose background really changed
    if ($script:GlassBusy -or $script:Scanning) { return }
    if (-not $script:Settings.enabled -or -not $script:Settings.glass -or -not $script:Glass2Ok -or $script:HideOverlay) { return }
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($b0 in @($script:LastBlocks)) { if ($b0 -and [int]$b0.lw -gt 0 -and $b0.glass) { [void]$list.Add($b0) } }
    if ($list.Count -eq 0) { return }
    # without capture exclusion the overlay would have to be hidden for every grab (flicker in streams): only refresh
    # live when the smooth capture works; otherwise the OCR scans keep the glass up to date
    $pwLive = $false
    if (-not $script:ExcludeOk) {
        if (-not (($script:WgcOn -or ($script:PrintOk -and $script:PwMode -eq 'on')) -and $script:Game -and $script:Game.hwnd -ne [IntPtr]::Zero)) { return }
        $pwLive = $true
    }
    $script:GlassBusy = $true
    $swG = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $liveBmp = $null; $x0 = 0; $y0 = 0; $fr = $null
        if ($pwLive) {
            $crL = Get-GameClientRect
            if (-not $crL) { return }
            if ($null -eq $script:LivePw -or $script:LivePw.Width -ne $crL.Width -or $script:LivePw.Height -ne $crL.Height) {
                if ($script:LivePw) { try { $script:LivePw.Dispose() } catch {} }
                $script:LivePw = New-Object System.Drawing.Bitmap $crL.Width, $crL.Height
            }
            $okPwL = $false
            if ($script:WgcOn) { try { $okPwL = Grab-Wgc $script:LivePw $crL } catch {} }
            if (-not $okPwL -and $script:PrintOk -and $script:PwMode -eq 'on') { try { $okPwL = [HSPrint]::Client($script:Game.hwnd, $script:LivePw) } catch {} }
            if (-not $okPwL) { return }
            if ([HSPrint]::Dark($script:LivePw)) { return }
            $liveBmp = $script:LivePw; $x0 = [int]$crL.X; $y0 = [int]$crL.Y; $fr = $crL
        } else {
            $vs3 = [System.Windows.Forms.SystemInformation]::VirtualScreen
            $x0 = [int]$list[0].lx; $y0 = [int]$list[0].ly; $x1 = $x0 + [int]$list[0].lw; $y1 = $y0 + [int]$list[0].lh
            foreach ($b1 in $list) {
                if ([int]$b1.lx -lt $x0) { $x0 = [int]$b1.lx }
                if ([int]$b1.ly -lt $y0) { $y0 = [int]$b1.ly }
                if (([int]$b1.lx + [int]$b1.lw) -gt $x1) { $x1 = [int]$b1.lx + [int]$b1.lw }
                if (([int]$b1.ly + [int]$b1.lh) -gt $y1) { $y1 = [int]$b1.ly + [int]$b1.lh }
            }
            if ($x0 -lt $vs3.Left) { $x0 = $vs3.Left }
            if ($y0 -lt $vs3.Top) { $y0 = $vs3.Top }
            if ($x1 -gt $vs3.Right) { $x1 = $vs3.Right }
            if ($y1 -gt $vs3.Bottom) { $y1 = $vs3.Bottom }
            $uw = $x1 - $x0; $uh = $y1 - $y0
            if ($uw -lt 4 -or $uh -lt 4) { return }
            if ($null -eq $script:LiveFrame -or $script:LiveFrame.Width -ne $uw -or $script:LiveFrame.Height -ne $uh) {
                if ($script:LiveFrame) { try { $script:LiveFrame.Dispose() } catch {} }
                $script:LiveFrame = New-Object System.Drawing.Bitmap $uw, $uh
            }
            $okAff = $true
            if (-not $script:ExcludeOk) {
                $okAff = $false
                try { $okAff = [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0x11) } catch {}
                if ($okAff) { Start-Sleep -Milliseconds 24 }
            }
            if (-not $okAff) { return }
            $gr = [System.Drawing.Graphics]::FromImage($script:LiveFrame)
            try { $gr.CopyFromScreen($x0, $y0, 0, 0, (New-Object System.Drawing.Size $uw, $uh)) }
            finally {
                $gr.Dispose()
                if (-not $script:ExcludeOk) { try { [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0) | Out-Null } catch {} }
            }
            $fr = New-Object System.Drawing.Rectangle $x0, $y0, $uw, $uh
            $liveBmp = $script:LiveFrame
        }
        foreach ($b2 in $list) {
            $sg = [StarGlass2]::Sig($liveBmp, ([int]$b2.lx - $x0), ([int]$b2.ly - $y0), [int]$b2.lw, [int]$b2.lh)
            if (-not [StarGlass2]::Differs($sg, $b2.gSig, 2)) { continue }
            Build-Glass $b2 $liveBmp $fr
            $b2.gSig = $sg
            $ir2 = New-Object System.Drawing.Rectangle ([int]$b2.lx - $script:Overlay.Left), ([int]$b2.ly - $script:Overlay.Top), ([int]$b2.lw), ([int]$b2.lh)
            $script:Overlay.Invalidate($ir2)
        }
    } catch { Write-Log ('glass live: ' + $_.Exception.Message) }
    finally {
        $script:GlassBusy = $false
        try {
            $baseMs = 100; if (-not $script:ExcludeOk) { $baseMs = 250 }
            $script:GlassTimer.Interval = [int][Math]::Max($baseMs, ($swG.ElapsedMilliseconds * 4))
        } catch {}
    }
}
function Get-LineEm([string]$text, $w, $h) {
    # size of one Chinese glyph in this line: width per character when it can be trusted, otherwise the line height
    $n = ([regex]::Replace($text, '\s', '')).Length
    $hh = [double][Math]::Max(8, [double]$h)
    if ($n -ge 2) {
        $pc = [double]$w / [double]$n
        return [Math]::Min(1.0 * $hh, [Math]::Max(0.7 * $hh, $pc))
    }
    return 0.9 * $hh
}
function New-EmList($it) {
    $l = New-Object System.Collections.Generic.List[double]
    [void]$l.Add((Get-LineEm ([string]$it.text) $it.w $it.h))
    return ,$l
}
function Get-MedianEm($list) {
    $a = @($list.ToArray() | Sort-Object)
    if ($a.Count -eq 0) { return 16.0 }
    return [double]$a[[int][Math]::Floor($a.Count / 2)]
}
function Get-NumKey([string]$s) { return ([regex]::Replace($s, '[^0-9０-９零〇一二三四五六七八九十百千万亿两]', '')) }
function Get-RegionChange($t, $bmp, $rect) {
    # how much the picture changed in the area a track's text occupied when it was last read (mean brightness, -1 = unknown)
    if (-not $script:Glass2Ok -or $null -eq $bmp -or $null -eq $rect -or $null -eq $t.sig) { return -1 }
    try {
        $cs = [StarGlass2]::TextSig($bmp, ([int]$t.rx - $rect.X), ([int]$t.ry - $rect.Y), [int]$t.rw, [int]$t.rh)
        return [int][StarGlass2]::SigDiff($t.sig, $cs)
    } catch { return -1 }
}
function Get-TrackInk($t, $bmp, $rect) {
    if (-not $script:MaskOk -or $null -eq $bmp -or $null -eq $rect) { return -1 }
    try { return [int][StarMask]::InkPermille($bmp, ([int]$t.rx - $rect.X), ([int]$t.ry - $rect.Y), [int]$t.rw, [int]$t.rh, 160, 50, 25) } catch { return -1 }
}
# ---------- pre-written translations of whole fixed screens ----------
# Long fixed notices (the legal / anti-addiction text on the login screen) come back from the OCR in pieces - broken at
# the 《》 brackets, over the busy picture - and translated piece by piece they make a jumble of labels. When two or more
# of a notice's key phrases are on screen, every label inside that notice is replaced by ONE clean panel holding a
# complete, hand-written translation. The panel keeps the full size it has reached while the notice stays up.
$script:NoticeText = @{}
$script:NoticeDefs = @(
    [pscustomobject]@{
        key = '#NOTICE#login-legal'
        anchors = @('防沉迷自律公约', '适用于年满', '家长监护', '健康游戏忠告', '抵制不良游戏', '盗版游戏', '谨防受骗', '沉迷游戏伤身', '合理安排时间',
                    '国家新闻出版署', '防止未成年人沉迷', '严格管理', '实名注册', '有效身份信息', '防沉迷功能', '网出证', '著作权人', '腾讯科技',
                    '出版单位', '声像电子出版社', '运营单位', '纳原信息', '审批文号', '国新出审', '出版物号', 'ISBN')
        text = "This company actively follows the Online Game Industry Anti-Addiction Self-Discipline Convention. This game is suitable for players aged 12 and over; minors should play under parental supervision.`n" +
               "Healthy gaming advice: reject harmful games and pirated copies. Protect yourself and beware of scams. Moderate play is good for the mind, addiction harms the body. Plan your time and enjoy a healthy life.`n" +
               "Under the National Press and Publication Administration's 'Notice on Preventing Minors from Becoming Addicted to Online Games' and 'Notice on Further Strict Management to Effectively Prevent Minors from Becoming Addicted to Online Games', all players must register their account under their real name with valid ID before entering the game; players verified as minors are subject to anti-addiction limits.`n" +
               "Online publishing licence: (Shu) Wang Chu Zheng (Yue) No. 054   |   Copyright holder: Tencent Technology (Shenzhen) Co., Ltd.`n" +
               "Publisher: Shanghai Audio-Visual Electronic Publishing House   |   Operator: Shanghai Nayuan Information Technology Co., Ltd.   |   Approval: Guo Xin Chu Shen [2024] No. 1844   |   ISBN 978-7-498-13933-7"
    }
)
foreach ($nd0 in $script:NoticeDefs) { $script:NoticeText[$nd0.key] = $nd0.text }
$script:NoticeBox = @{}
# A glow / calligraphy mark around a label (the gold title art of the Martial Tournament) sits outside the box the OCR gave.
# The label's glass grows to cover the bright ink just outside it, by at most 0.4 x a line's height, so no smear is left.
function Grow-BlocksToInk($blocks, $bmp, $rect) {
    if (-not $script:MaskOk -or $null -eq $bmp -or $null -eq $rect) { return }
    foreach ($b in @($blocks)) {
        try {
            if ([string]$b.text -like '#NOTICE#*' -or [bool]$b.closed) { continue }
            $lh = [double]$b.h / [Math]::Max(1, [int]$b.lines)
            if ($lh -lt 14) { continue }
            $cap = [int][Math]::Round(0.4 * $lh)
            $e = [StarMask]::InkExtent($bmp, ([int]$b.x - $rect.X), ([int]$b.y - $rect.Y), [int]$b.w, [int]$b.h, $cap, 120, 35)
            if ($null -eq $e -or $e.Length -lt 4) { continue }
            $t = [int]$e[0]; $bt = [int]$e[1]; $l = [int]$e[2]; $r = [int]$e[3]
            if (($l + $t + $r + $bt) -le 0) { continue }
            $b.x = [int]$b.x - $l; $b.y = [int]$b.y - $t; $b.w = [int]$b.w + $l + $r; $b.h = [int]$b.h + $t + $bt
        } catch {}
    }
}
# "第1" and the unit that follows it ("赛季") are one phrase: read as two pieces they print as "No. 1" next to "Season".
function Merge-Ordinals($blocks) {
    $ordRx = New-Object System.Text.RegularExpressions.Regex('^第\s*[0-9一二三四五六七八九十]+$')
    $unitRx = New-Object System.Text.RegularExpressions.Regex('^(赛季|章|关|场|层|阶|届|期|回)')
    for ($ia = 0; $ia -lt $blocks.Count; $ia++) {
        $a = $blocks[$ia]
        if (-not $ordRx.IsMatch([string]$a.text)) { continue }
        $ax = [double]$a.x; $ay = [double]$a.y; $aw = [double]$a.w; $ah = [double]$a.h
        for ($ib = 0; $ib -lt $blocks.Count; $ib++) {
            if ($ib -eq $ia) { continue }
            $b = $blocks[$ib]
            if (-not $unitRx.IsMatch([string]$b.text)) { continue }
            if ([int]$b.lines -ne 1) { continue }
            $bx = [double]$b.x; $by = [double]$b.y; $bw = [double]$b.w; $bh = [double]$b.h
            $gap = $bx - ($ax + $aw)
            $dy = [Math]::Abs(($ay + $ah / 2.0) - ($by + $bh / 2.0))
            if ($dy -gt (0.4 * $ah)) { continue }
            if ($gap -lt -2.0 -or $gap -gt (1.2 * $ah)) { continue }
            $a.text = ([string]$a.text) + ([string]$b.text)
            $a.w = [int]($bx + $bw - $ax)
            $a.h = [int][Math]::Max($ah, $bh)
            $blocks.RemoveAt($ib)
            break
        }
    }
}
function Apply-Notices($blocks) {
    $keys = New-Object System.Collections.Generic.List[string]
    foreach ($nd in $script:NoticeDefs) {
        $hitB = New-Object System.Collections.Generic.List[object]; $hitA = @{}
        foreach ($b in $blocks) {
            $tx = ([string]$b.text) -replace '\s', ''
            foreach ($a in $nd.anchors) { if ($tx.Contains($a)) { $hitA[$a] = $true; [void]$hitB.Add($b); break } }
        }
        if ($hitA.Count -lt 2) { $script:NoticeBox.Remove($nd.key); continue }
        $lh = 0.0; foreach ($b in $hitB) { $lh = [Math]::Max($lh, [double]$b.h / [Math]::Max(1, [int]$b.lines)) }
        $x0 = 1e9; $y0 = 1e9; $x1 = -1e9; $y1 = -1e9
        foreach ($b in $hitB) { $x0 = [Math]::Min($x0, [double]$b.x); $y0 = [Math]::Min($y0, [double]$b.y); $x1 = [Math]::Max($x1, [double]$b.x + $b.w); $y1 = [Math]::Max($y1, [double]$b.y + $b.h) }
        $old = $script:NoticeBox[$nd.key]
        if ($old) { $x0 = [Math]::Min($x0, $old.x0); $y0 = [Math]::Min($y0, $old.y0); $x1 = [Math]::Max($x1, $old.x1); $y1 = [Math]::Max($y1, $old.y1) }
        # every other label inside the notice's area (and a line's height around it) belongs to the notice
        $members = New-Object System.Collections.Generic.List[object]
        foreach ($b in @($blocks)) {
            $cy = [double]$b.y + [double]$b.h / 2.0
            if ($cy -ge ($y0 - 1.2 * $lh) -and $cy -le ($y1 + 1.2 * $lh) -and ([double]$b.x + $b.w) -gt ($x0 - 2 * $lh) -and [double]$b.x -lt ($x1 + 2 * $lh)) { [void]$members.Add($b) }
        }
        foreach ($b in $members) { $x0 = [Math]::Min($x0, [double]$b.x); $y0 = [Math]::Min($y0, [double]$b.y); $x1 = [Math]::Max($x1, [double]$b.x + $b.w); $y1 = [Math]::Max($y1, [double]$b.y + $b.h); [void]$blocks.Remove($b) }
        $script:NoticeBox[$nd.key] = @{ x0 = $x0; y0 = $y0; x1 = $x1; y1 = $y1 }
        $nLines = [Math]::Max(5, [int][Math]::Round(($y1 - $y0) / [Math]::Max(8, $lh)))
        $emL = New-Object System.Collections.Generic.List[double]; [void]$emL.Add([double]$lh)
        $f0 = $members[0]
        $blocks.Add([pscustomobject]@{ text = $nd.key; x = [int]$x0; y = [int]$y0; w = [int]($x1 - $x0); h = [int]($y1 - $y0); lines = $nLines; emL = $emL; bgR = $f0.bgR; bgG = $f0.bgG; bgB = $f0.bgB; lastX = [int]$x0; lastY = [int]$y0; lastW = [int]($x1 - $x0); lastH = [int]$lh; lastText = $nd.key; maxW = [int]($x1 - $x0); closed = $true }) | Out-Null
        [void]$keys.Add($nd.key)
    }
    return $keys.ToArray()
}
function Get-TrackInkGrid($t, $bmp, $rect) {
    if (-not $script:MaskOk -or $null -eq $bmp -or $null -eq $rect) { return $null }
    try { return [StarMask]::InkGrid($bmp, ([int]$t.rx - $rect.X), ([int]$t.ry - $rect.Y), [int]$t.rw, [int]$t.rh, 160, 50, 25) } catch { return $null }
}
function Get-GridDiff($a, $b) {
    # 0 = ink in exactly the same places, 1 = completely different places; 9 = cannot compare
    if ($null -eq $a -or $null -eq $b -or $a.Length -ne 16 -or $b.Length -ne 16) { return 9.0 }
    $d = 0; $t = 0
    for ($q = 0; $q -lt 16; $q++) { $d += [Math]::Abs([int]$a[$q] - [int]$b[$q]); $t += [int]$a[$q] + [int]$b[$q] }
    if ($t -le 0) { return 9.0 }
    return [double]$d / $t
}
function Test-TracksChanged($bmp, $rect, [int]$thr) {
    # true when the picture under any shown label has clearly changed since that text was read
    if (-not $script:Glass2Ok -or $null -eq $bmp -or $null -eq $rect) { return $false }
    try {
        $tl = $script:Tracks
        $cntT = 0; if ($null -ne $tl) { $cntT = [int]$tl.Count }
        $n = 0
        for ($ti = 0; $ti -lt $cntT; $ti++) {
            $tk = $tl[$ti]
            if ($null -eq $tk) { continue }
            if ($null -eq $tk.sig) { continue }
            if (([int]$tk.seen) -lt 2) { continue }
            $rc = Get-RegionChange $tk $bmp $rect
            if (([int]$rc) -ge $thr) { return $true }
            $n++; if ($n -gt 80) { break }
        }
    } catch {
        $script:TtcErr = [int]$script:TtcErr + 1
        if ($script:TtcErr -le 5) { Write-Log ('tracks check: ' + $_.Exception.Message + ' | ' + [string]$_.ScriptStackTrace) }
    }
    return $false
}
$script:SlotMem = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal)
$script:SlotAsk = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal)
function Find-Slot([string]$tx, [double]$x, [double]$y, [double]$h, [bool]$add) {
    $ak = $tx + '|' + [int]($x / 4) + '|' + [int]($y / 4)
    if (-not $add) { $av = $script:SlotAsk[$ak]; if ($null -ne $av) { return [bool]$av } }
    $r0 = Find-Slot0 $tx $x $y $h $add
    if ($add) { $script:SlotAsk.Clear() } else { if ($script:SlotAsk.Count -gt 3000) { $script:SlotAsk.Clear() }; $script:SlotAsk[$ak] = [bool]$r0 }
    return [bool]$r0
}
function Find-Slot0([string]$tx, [double]$x, [double]$y, [double]$h, [bool]$add) {
    $k = Get-NormKey $tx
    if (-not $k) { return $false }
    $l = $script:SlotMem[$k]
    $tol = [Math]::Max(6.0, 0.7 * $h)
    if ($null -ne $l) { foreach ($pp in $l) { if ([Math]::Abs([double]$pp.x - $x) -le $tol -and [Math]::Abs([double]$pp.y - $y) -le $tol) { return $true } } }
    if (-not $add) { return $false }
    if ($script:SlotMem.Count -gt 600) { $script:SlotMem.Clear() }
    if ($null -eq $l) { $l = New-Object System.Collections.ArrayList; $script:SlotMem[$k] = $l }
    if ($l.Count -lt 8) { [void]$l.Add([pscustomobject]@{ x = $x; y = $y }) }
    return $true
}
$script:TrkLogAt = @{}
function Log-Track([string]$what, $t, [string]$why) {
    # diagnostics: why an established label (read 4+ times) was dropped or moved - rate limited per text
    try {
        if ([int]$t.seen -lt 4) { $offL = $false; try { $offL = Test-OfficialText ([string]$t.text) } catch {}; if (-not $offL) { return } }
        $k = $what + '|' + [string]$t.text; $now = [int64]$script:Clk.ElapsedMilliseconds
        if ($script:TrkLogAt.ContainsKey($k) -and ($now - [int64]$script:TrkLogAt[$k]) -lt 4000) { return }
        if ($script:TrkLogAt.Count -gt 400) { $script:TrkLogAt = @{} }
        $script:TrkLogAt[$k] = $now
        Write-Log ('track ' + $what + ' [' + $why + ']: ' + [string]$t.text + ' seen=' + $t.seen + ' missed=' + $t.missed)
    } catch {}
}
function Update-Tracks($items, $bmp, $rect) {
    # A label appears after the text is seen twice, stays exactly seated while the text sits still,
    # moves only after the same new position is seen twice, changes text only for a genuinely different
    # string seen twice (near-identical strings are OCR noise), and disappears after 5 scans without the text.
    $tracks = $script:Tracks
    $used = @{}
    $moved = 0
    $st = @{ pre = $tracks.Count; matched = 0; n = 0 }
    $idx = -1
    foreach ($it in $items) {
        $idx++
        $isFresh = ($idx -lt [int]$script:FreshN)       # read in this very scan (not a re-used earlier reading)
        $solid = ([int]$it.nz -eq 0 -and ([int]$it.pass -ne 2 -or (Test-OfficialText ([string]$it.text))))
        if ($solid) { $st.n = $st.n + 1 }       # stray readings of a moving background do not count towards 'the whole screen changed'
        $tol = [Math]::Max(4, 0.3 * [double]$it.h)
        $ptol = [Math]::Max(3, 0.1 * [double]$it.h)          # position: a label is 'in the same place' only within a few pixels, so a menu that shifts a little is followed
        $best = -1; $bd = 1e9
        for ($i = 0; $i -lt $tracks.Count; $i++) {
            if ($used.ContainsKey($i)) { continue }
            $t = $tracks[$i]
            if ([string]$t.text -ne [string]$it.text) { continue }
            $d = [Math]::Abs([int]$t.x - [int]$it.x) + [Math]::Abs([int]$t.y - [int]$it.y)
            if ($d -lt $bd -and $d -le 220) { $bd = $d; $best = $i }
        }
        if ($best -ge 0) {
            $t = $tracks[$best]; $used[$best] = $true; if ($solid) { $st.matched = $st.matched + 1 }
            $seated = ([Math]::Abs([int]$t.x - [int]$it.x) -le $ptol -and [Math]::Abs([int]$t.y - [int]$it.y) -le $ptol -and [Math]::Abs([int]$t.w - [int]$it.w) -le (2 * $tol) -and [Math]::Abs([int]$t.h - [int]$it.h) -le $tol)
            # the normal reading puts a text where it really is; a reading from the extra passes of the same text a few dozen
            # pixels elsewhere (the log shows 战斗录像 / 切磋排行 swinging by 24-36 px) never pulls it away
            $posIgn = $false
            if (-not $seated -and [int]$it.pass -eq 2 -and [bool]$t.p1) { $seated = $true; $posIgn = $true }
            if ($seated) { $t.mN = 0 }
            else {
                if ($t.mN -gt 0 -and [Math]::Abs([int]$t.mx - [int]$it.x) -le $ptol -and [Math]::Abs([int]$t.my - [int]$it.y) -le $ptol) { $t.mN++ } else { $t.mx = $it.x; $t.my = $it.y; $t.mN = 1 }
                $needMv = 2; if ([int]$t.seen -ge 4) { $needMv = 3 }
                # a clear, solid reading away from the old spot where the old spot's ink is gone: the text really moved - follow at once
                # (a menu that glides or sways moves a little every scan: waiting for the same new spot twice never happened, the
                # label then trailed behind and jumped once the menu stopped)
                if ($isFresh -and [int]$it.pass -ne 2 -and [int]$it.nz -eq 0 -and ([Math]::Abs([int]$t.x - [int]$it.x) + [Math]::Abs([int]$t.y - [int]$it.y)) -gt (1.5 * $ptol)) {
                    try { if ((Get-GridDiff $t.ig (Get-TrackInkGrid $t $bmp $rect)) -gt 0.38) { $needMv = 1 } } catch {}
                }
                if ([int]$it.pass -eq 2 -and ([Math]::Abs([int]$t.x - [int]$it.x) + [Math]::Abs([int]$t.y - [int]$it.y)) -gt 24) { $needMv = [Math]::Max($needMv, 5) }
                if ($t.mN -ge $needMv -or $t.seen -lt 2) {
                    Log-Track 'move' $t ('dx=' + ([int]$it.x - [int]$t.x) + ' dy=' + ([int]$it.y - [int]$t.y) + ' dw=' + ([int]$it.w - [int]$t.w) + ' dh=' + ([int]$it.h - [int]$t.h) + ' pass=' + $it.pass + ' need=' + $needMv + ' mN=' + $t.mN)
                    $t.x = $it.x; $t.y = $it.y; $t.w = $it.w; $t.h = $it.h; $t.bgR = $it.bgR; $t.bgG = $it.bgG; $t.bgB = $it.bgB; $t.mN = 0
                    if ($t.seen -ge 2) { $moved++ }
                }
            }
            $t.seen++; if ($t.seen -eq 2) { $moved++ }
            if ($isFresh) { $t.fresh = [int]$t.fresh + 1; if ([int]$it.pass -ne 2) { $t.p1 = $true } }
            if ($isFresh -and -not $posIgn) { $ik = Get-TrackInk $it $bmp $rect; if ($ik -ge 0) { $t.ink = [Math]::Max([int]$t.ink, $ik); $t.ig = Get-TrackInkGrid $it $bmp $rect } }
            if ([int]$t.seen -ge 4 -and -not $t.slotted -and [int]$t.fresh -ge 2 -and [int]$t.nz -eq 0) { $t.slotted = $true; try { [void](Find-Slot ([string]$t.text) ([double]$t.x) ([double]$t.y) ([double]$t.h) $true) } catch {} }
            $t.missed = 0; $t.pend = $null; $t.pendN = 0
            if (-not $posIgn) { $t.sig = $it.sig; $t.rx = $it.rx; $t.ry = $it.ry; $t.rw = $it.rw; $t.rh = $it.rh }
            continue
        }
        $ov = -1
        for ($i = 0; $i -lt $tracks.Count; $i++) {
            if ($used.ContainsKey($i)) { continue }
            $t = $tracks[$i]
            $ox = [Math]::Min([int]$t.x + [int]$t.w, [int]$it.x + [int]$it.w) - [Math]::Max([int]$t.x, [int]$it.x)
            $oy = [Math]::Min([int]$t.y + [int]$t.h, [int]$it.y + [int]$it.h) - [Math]::Max([int]$t.y, [int]$it.y)
            if ($ox -gt 0.5 * [Math]::Min([int]$t.w, [int]$it.w) -and $oy -gt 0.5 * [Math]::Min([int]$t.h, [int]$it.h)) { $ov = $i; break }
        }
        if ($ov -ge 0) {
            $t = $tracks[$ov]; $used[$ov] = $true; $t.missed = 0; if ($solid) { $st.matched = $st.matched + 1 }
            # did the picture itself change where the old text was? then this is new text, not OCR noise: accept it at once
            $cd = Get-RegionChange $t $bmp $rect
            $numDiff = ((Get-NumKey ([string]$t.text)) -ne (Get-NumKey ([string]$it.text)))
            # over a moving picture (car, rotating banner) the area always "changes", so a clear change is needed before a
            # differently read text replaces the label at once; the same Chinese with only other digits / brackets is OCR
            # jitter and must be read the same way twice before it counts
            $hanOld = [regex]::Replace([string]$t.text, '[^\u4e00-\u9fff]', ''); $hanNew = [regex]::Replace([string]$it.text, '[^\u4e00-\u9fff]', '')
            $sameHan = ($hanOld.Length -gt 0 -and $hanOld -eq $hanNew)
            $genuine = ($cd -ge 8) -or ($numDiff -and -not $sameHan -and ($cd -ge 5 -or $cd -lt 0))
            if (-not $genuine -and (Get-TextSim ([string]$t.text) ([string]$it.text)) -ge 0.5) {
                if (-not $sameHan) { continue }                                      # near-identical: OCR noise, keep the seated label
            }
            if ([string]$t.pend -eq [string]$it.text) { $t.pendN++ } else { $t.pend = [string]$it.text; $t.pendN = 1 }
            $need = 2; if ($sameHan) { $need = 3 }
            # never swap a working label for text that has no translation yet: keep the old one until the new one is ready
            if ($genuine -or $t.pendN -ge $need) {
                $trNew = $null; $trOld = $null
                try { $tb = Translate-Batch @([string]$it.text, [string]$t.text); $trNew = $tb[([string]$it.text).Trim()]; $trOld = $tb[([string]$t.text).Trim()] } catch {}
                if ([string]::IsNullOrWhiteSpace([string]$trNew) -and -not [string]::IsNullOrWhiteSpace([string]$trOld) -and [int]$t.pendN -lt 12) { continue }
            }
            if ($genuine -or $t.pendN -ge $need) {
                $fr = [int]$t.pendN; if (-not $isFresh) { $fr = [Math]::Max(0, $fr - 1) }
                if ($genuine -and $isFresh -and [int]$it.nz -eq 0 -and [int]$it.pass -ne 2) { $fr = [Math]::Max($fr, 2) }
                $t.fresh = $fr; $t.nz = [int]$it.nz; $t.p1 = ($isFresh -and [int]$it.pass -ne 2); $t.slotted = $false
                $t.text = $it.text; $t.x = $it.x; $t.y = $it.y; $t.w = $it.w; $t.h = $it.h; $t.bgR = $it.bgR; $t.bgG = $it.bgG; $t.bgB = $it.bgB; $t.pend = $null; $t.pendN = 0; $t.mN = 0; $moved++
                $t.sig = $it.sig; $t.rx = $it.rx; $t.ry = $it.ry; $t.rw = $it.rw; $t.rh = $it.rh
                if ($genuine) { $t.seen = [Math]::Max([int]$t.seen, 2) }
            }
            continue
        }
        $seen0 = 1; try { if (Find-Slot ([string]$it.text) ([double]$it.x) ([double]$it.y) ([double]$it.h) $false) { $seen0 = 4 } } catch {}
        $fr0 = [int]$isFresh; if ($seen0 -eq 4 -and $isFresh) { $fr0 = 2 }        # a remembered spot (only real, twice-read text is remembered)
        $ik0 = 0; if ($isFresh) { $ik0 = [Math]::Max(0, (Get-TrackInk $it $bmp $rect)) }
        $ig0 = $null; if ($isFresh -and $ik0 -gt 0) { $ig0 = Get-TrackInkGrid $it $bmp $rect }
        $tracks.Add([pscustomobject]@{ ig = $ig0; ink = $ik0; fresh = $fr0; nz = [int]$it.nz; p1 = ($isFresh -and [int]$it.pass -ne 2); slotted = ($seen0 -eq 4); text = $it.text; x = $it.x; y = $it.y; w = $it.w; h = $it.h; bgR = $it.bgR; bgG = $it.bgG; bgB = $it.bgB; missed = 0; seen = $seen0; pend = $null; pendN = 0; mx = 0; my = 0; mN = 0; sig = $it.sig; rx = $it.rx; ry = $it.ry; rw = $it.rw; rh = $it.rh }) | Out-Null
        try { Log-Track 'new' $tracks[$tracks.Count - 1] ('first sighting pass=' + $it.pass) } catch {}
        $used[$tracks.Count - 1] = $true
    }
    # scene change (most text is new): drop the old screen's labels at once and show new text after one sighting
    $sceneCut = $false
    $script:Pruning = $false
    try { if ($st.pre -ge 3) { if ($st.n -ge 3) { if (($st.matched * 5) -lt ($st.n * 2)) { $sceneCut = $true } } } } catch { $sceneCut = $false; Write-Log "scenecut: $($_.Exception.Message)" }
    if ($sceneCut) { $script:SceneChange = 2; $script:LayMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal) }
    $readNow = @{}
    for ($i = 0; $i -lt $tracks.Count; $i++) { if ($used.ContainsKey($i)) { $readNow[[string]$tracks[$i].text] = $true } }
    for ($i = $tracks.Count - 1; $i -ge 0; $i--) {
        if ($used.ContainsKey($i)) { continue }
        if ($sceneCut) { Log-Track 'drop' $tracks[$i] 'scene-change'; $tracks.RemoveAt($i); $moved++; continue }
        $t = $tracks[$i]
        if ($readNow.ContainsKey([string]$t.text)) { Log-Track 'drop' $t 'read-elsewhere'; $tracks.RemoveAt($i); if ($t.seen -ge 2) { $moved++ }; continue }      # its text was just read elsewhere: this copy is out of date (menu slid / scrolled)
        $t.missed++
        # sticky: an established label of the game's own text (chapter list, menu entries) stays while its light text is
        # still on screen - even when a moving picture behind it makes the OCR miss it and the area 'changes'. It goes
        # when the whole screen changes (scene change above), when other text replaces it, or when its ink is gone.
        if ([int]$t.seen -ge 3 -and [int]$t.ink -ge 12 -and [int]$t.missed -le 90) {
            $offT = $false; try { $offT = Test-OfficialText ([string]$t.text) } catch {}
            if ($offT -or ([int]$t.nz -eq 0 -and [int]$t.fresh -ge 3)) {
                $inkNow = Get-TrackInk $t $bmp $rect
                $samePlace = $false
                if ($inkNow -ge 0 -and $inkNow -ge [int](0.55 * [int]$t.ink) -and $inkNow -le [int](1.8 * [int]$t.ink + 10)) {
                    # the ink must still sit where this text's ink sat (another entry slid into the spot has its ink elsewhere)
                    $samePlace = ((Get-GridDiff $t.ig (Get-TrackInkGrid $t $bmp $rect)) -le 0.38)
                }
                if ($samePlace) {
                    # and nothing else may have been read on top of it in this scan
                    $tx0 = [double]$t.x; $ty0 = [double]$t.y; $tw0 = [double]$t.w; $th0 = [double]$t.h; $onTop = $false
                    for ($q = 0; $q -lt [Math]::Min($items.Count, [int]$script:FreshN); $q++) {
                        $o = $items[$q]
                        if ([string]$o.text -eq [string]$t.text) { continue }
                        $ox = [Math]::Max(0.0, [Math]::Min($tx0 + $tw0, [double]$o.x + [double]$o.w) - [Math]::Max($tx0, [double]$o.x))
                        $oy = [Math]::Max(0.0, [Math]::Min($ty0 + $th0, [double]$o.y + [double]$o.h) - [Math]::Max($ty0, [double]$o.y))
                        if ($ox * $oy -gt 0.25 * $tw0 * $th0) { $onTop = $true; break }
                    }
                    if (-not $onTop) { continue }                                  # still there: keep it (no fast rescans needed)
                }
            }
        }
        $cdm = Get-RegionChange $t $bmp $rect
        # the text under the label changed a lot AND it was not read twice in a row: it is gone (one miss alone is often just
        # a glow or animation behind the text that made the OCR skip it once)
        # a label that has been read many times in a row is established: an animated, sparkling or glowing background can make
        # the OCR miss it several scans running, so it gets more patience before it is taken away (a real screen change is
        # handled at once by the scene-change check above, and new text in its place replaces it directly)
        $stable = ([int]$t.seen -ge 4)
        $pinned = $false; if ($stable) { try { $pinned = [bool](Find-Slot ([string]$t.text) ([double]$t.x) ([double]$t.y) ([double]$t.h) $false) } catch {} }
        if ($pinned) {
            # remembered spot: it goes only when the picture there clearly changed, or after ~16 scans without the text
            $pinMax = 16; if ($cdm -ge 0 -and $cdm -lt 3) { $pinMax = 40 }      # the picture there has not changed at all: the text cannot have gone
            if (($cdm -ge 10 -and $t.missed -ge 2) -or $t.missed -ge $pinMax) { Log-Track 'drop' $t ('pinned cdm=' + $cdm); $tracks.RemoveAt($i); $moved++ } else { $script:Pruning = $true }
            continue
        }
        $kn = $false; try { $kn = [bool](Test-KnownText ([string]$t.text)) } catch {}
        $goneAfter = 2; if ($stable) { $goneAfter = 5 } elseif ($kn) { $goneAfter = 4 }
        if ($cdm -ge 5 -and $t.missed -ge $goneAfter) { Log-Track 'drop' $t ('changed cdm=' + $cdm); $tracks.RemoveAt($i); if ($t.seen -ge 2) { $moved++ }; continue }
        $maxMiss = 2; if ($cdm -ge 0 -and $cdm -lt 3) { $maxMiss = 3 }                           # picture unchanged: the OCR just missed it, wait a little longer
        if ($stable) { $maxMiss = $maxMiss + 4 }
        # an established label whose picture is untouched (the log showed 7 missed scans at 'cdm 0-1' dropping real text) stays: only the OCR missed it
        if ($stable -and $cdm -ge 0 -and $cdm -lt 3) { $maxMiss = 40 }
        if ($kn -and -not $stable) { $maxMiss = $maxMiss + 2 }                                     # a known game word that is hard to read: give its sightings time to add up
        $newMiss = 2; if ($kn) { $newMiss = 4 }
        if ($t.seen -lt 2) { if ($t.missed -ge $newMiss) { $tracks.RemoveAt($i) } else { $script:Pruning = $true } }     # text read only now and then can still be confirmed on its second sighting
        elseif ($t.missed -ge $maxMiss) { Log-Track 'drop' $t ('missed cdm=' + $cdm); $tracks.RemoveAt($i); $moved++ }
        else { $script:Pruning = $true }
    }
    return $moved
}
function Invoke-Scan {
    if ($script:Scanning -or -not $script:Settings.enabled) { return }
    if ($script:Settings.captureMode -eq 'game' -and ($script:HideOverlay -or -not $script:Game)) { return }
    $script:Scanning = $true
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $bmp = $null; $small = $null; $gotFrame = $false
    try {
        if (-not (Ensure-WinRT)) { Update-Tray; return }
        $rect = Get-CaptureRect
        if (-not $rect -or $rect.Width -lt 8) { $script:Status = 'no game window'; return }
        $script:LastRect = $rect
        $bmp = New-Object System.Drawing.Bitmap $rect.Width, $rect.Height
        $hidMode = 'none'
        $usedPw = $false
        if (-not $script:ExcludeOk -and $script:Settings.captureMode -eq 'game') {
            try { $usedPw = Grab-Wgc $bmp $rect } catch { $usedPw = $false }
            if ($usedPw -and [HSPrint]::Dark($bmp)) { $usedPw = $false }
        }
        if (-not $usedPw -and $script:PrintOk -and -not $script:ExcludeOk -and $script:PwMode -eq 'on' -and $script:Settings.captureMode -eq 'game' -and $script:Game -and $script:Game.hwnd -ne [IntPtr]::Zero -and (Get-Date) -lt $script:PwNext) {
            # smooth capture: the game window's own picture, the overlay is never hidden
            try { $usedPw = [HSPrint]::Client($script:Game.hwnd, $bmp) } catch { $usedPw = $false }
            if ($usedPw) {
                $script:PwFails = 0
                if ([HSPrint]::Dark($bmp)) { $usedPw = $false }        # black picture: take the real screen grab this time
            } else {
                $script:PwFails = [int]$script:PwFails + 1
                if ([int]$script:PwFails -ge 3) { $script:PwMode = 'off'; $script:PwPass = 0; $script:PwNext = (Get-Date).AddSeconds(30); Write-Log 'smooth capture: off (PrintWindow failed)' }
            }
        }
        if (-not $usedPw) {
            if (-not $script:ExcludeOk) {
                $okAff = $false
                try { $okAff = [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0x11) } catch {}
                if ($okAff) { $hidMode = 'affinity'; Start-Sleep -Milliseconds 24 } else { $hidMode = 'visible'; $script:Overlay.Visible = $false }
            }
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            try { $g.CopyFromScreen($rect.Location, [System.Drawing.Point]::Empty, $rect.Size) }
            catch { $script:Status = 'capture failed'; return }
            finally {
                $g.Dispose()
                if ($hidMode -eq 'affinity') { try { [HSNative]::SetWindowDisplayAffinity($script:Overlay.Handle, 0) | Out-Null } catch {} }
                elseif ($hidMode -eq 'visible') { $script:Overlay.Visible = $true }
            }
            # is the smooth capture usable? compare the game window's own picture with the real screen grab (two passes in a row)
            if ($script:PrintOk -and -not $script:ExcludeOk -and [string]$script:Settings.printCapture -ne 'off' -and $script:Settings.captureMode -eq 'game' -and $script:Game -and $script:Game.hwnd -ne [IntPtr]::Zero -and (Get-Date) -ge $script:PwNext) {
                $tmpB = $null
                try {
                    $tmpB = New-Object System.Drawing.Bitmap $rect.Width, $rect.Height
                    if ([HSPrint]::Client($script:Game.hwnd, $tmpB)) {
                        $df = [int][HSPrint]::Diff($tmpB, $bmp)
                        if ($df -lt 0) { $script:PwNext = (Get-Date).AddSeconds(5) }
                        elseif ($df -le 14) {
                            $script:PwPass = [int]$script:PwPass + 1
                            if ($script:PwMode -ne 'on' -and [int]$script:PwPass -ge 2) { $script:PwMode = 'on'; $script:PwFails = 0; Write-Log ('smooth capture: ON (diff ' + $df + ')') }
                            if ($script:PwMode -eq 'on') { $script:PwNext = (Get-Date).AddSeconds(30) } else { $script:PwNext = Get-Date }
                        } else {
                            if ($script:PwMode -eq 'on') { Write-Log ('smooth capture: off (picture differs, ' + $df + ')') }
                            $script:PwMode = 'off'; $script:PwPass = 0; $script:PwNext = (Get-Date).AddSeconds(30)
                        }
                    } else { $script:PwMode = 'off'; $script:PwPass = 0; $script:PwNext = (Get-Date).AddSeconds(60) }
                } catch { $script:PwMode = 'off'; $script:PwPass = 0; $script:PwNext = (Get-Date).AddSeconds(60) }
                finally { if ($tmpB) { try { $tmpB.Dispose() } catch {} } }
            }
        }
        $gotFrame = $true

        $hash = $null
        try { $hash = Get-FrameHash $bmp } catch { $hash = $null }
        $sinceOcr = 99
        $holdSec = 3.0; if ([int]$script:Unconf -gt 0) { $holdSec = 0.2 }
        if ($script:LastOcrAt) { $sinceOcr = ((Get-Date) - $script:LastOcrAt).TotalSeconds }
        if ($hash -and $script:LastHash -and -not (Test-FrameChanged $hash $script:LastHash) -and $sinceOcr -lt $holdSec -and $script:LastBlocks -and @($script:LastBlocks).Count -gt 0 -and -not (Test-TracksChanged $bmp $rect 4)) {
            $script:Status = 'holding (frame unchanged)'
            return
        }
        $script:PendingHash = $hash      # only becomes LastHash once this scan has really been applied

        $targetW = 2880
        $scale = 1.0
        $use = $bmp
        if ($bmp.Width -lt 2400 -or $bmp.Width -gt 3200) {
            $scale = $targetW / [double]$bmp.Width
            $small = New-Object System.Drawing.Bitmap $targetW, ([Math]::Max(1, [int]($bmp.Height * $scale)))
            $gg = [System.Drawing.Graphics]::FromImage($small)
            $gg.InterpolationMode = 'HighQualityBicubic'
            $gg.DrawImage($bmp, 0, 0, $small.Width, $small.Height)
            $gg.Dispose()
            $use = $small
        }

        $swA = [System.Diagnostics.Stopwatch]::StartNew()
        $result = Get-OcrResult $use
        $swA.Stop()
        $script:OcrMsA = $swA.ElapsedMilliseconds
        $lineCount = 0
        try { $lineCount = @($result.Lines).Count } catch {}
        $allLines = New-Object System.Collections.Generic.List[object]
        foreach ($ln0 in $result.Lines) { [void]$allLines.Add([pscustomobject]@{ line = $ln0; pass = 1 }) }
        $script:ScanN = 1 + [int]$script:ScanN
        # pass B: contrast-normalised image so coloured / dark / low-contrast text is read too
        $sinceB = 99; if ($script:LastBAt) { $sinceB = ((Get-Date) - $script:LastBAt).TotalSeconds }
        $ranB = $false
        $sinceM = 99; if ($script:LastMAt) { $sinceM = ((Get-Date) - $script:LastMAt).TotalSeconds }
        $ranM = $false
        # light-text pass: white text over a see-through, busy background (buttons over a moving scene). It also runs while
        # the picture moves - exactly when the other contrast passes are skipped - but at most about once a second
        # while a screen is still settling (scene change, unconfirmed or fading readings, or fewer than six unchanged scans) the extra
        # passes run every 0.3-0.6 s instead of every ~4 s: most buttons over a busy picture are read only by them, and they need
        # several readings each before they show. Needs a capture that costs no flicker.
        $mGap = 1.1; $mAny = ([int]$script:MotionBoost -gt 0 -or ([int]$script:ScanN % 4) -eq 0)
        $capFree = ($script:WgcOn -or $script:ExcludeOk -or $script:PwMode -eq 'on')
        if ($capFree) {
            if ([int]$script:SceneChange -gt 0 -or [int]$script:Unconf -gt 0 -or $script:Pruning) { $mGap = 0.3; $mAny = $true }
            elseif ([int]$script:SameStreak -lt 6) { $mGap = 0.6; $mAny = $true }
        }
        $bGap = 0.7; if ($capFree -and ([int]$script:SceneChange -gt 0 -or [int]$script:Unconf -gt 0)) { $bGap = 0.4 }
        if ($script:MaskOk -and ([double]$script:OcrMsA -lt 600) -and ([double]$sinceM -ge $mGap) -and $mAny) {
            try {
                $msk = [StarMask]::LightText($use, 175, 46, 18)
                $resM = Get-OcrResult $msk
                $msk.Dispose()
                $ranM = $true; $ranB = $true; $script:LastMAt = Get-Date        # its readings are kept between scans like the other contrast passes
                foreach ($ln0 in $resM.Lines) { [void]$allLines.Add([pscustomobject]@{ line = $ln0; pass = 2 }) }
            } catch { Write-Log "light-text pass: $_" }
        }
        if ((-not $ranM) -and ([bool]$script:ContrastPass) -and ([int]$script:MotionBoost -le 0) -and ([double]$script:OcrMsA -lt 450) -and ([double]$sinceB -ge $bGap)) {
            try {
                # two kinds of contrast pass, used in turn: local contrast (large / plain text) and a band-pass that cuts patterned backgrounds
                # three kinds in turn: local contrast (large / plain text), a band-pass that cuts patterned backgrounds,
                # and a strong local contrast for grey text that is only a little brighter / darker than its background
                $script:BAlt = ([int]$script:BAlt + 1) % 3
                if ([int]$script:BAlt -eq 1 -and $script:Glass2Ok) { $enh = [StarGlass2]::Band($use, 1, 8, 22, 4) }
                elseif ([int]$script:BAlt -eq 2) { $enh = [StarContrast]::Process($use, 6, 12) }      # small window: dim text beside bright text is compared with its own background only
                else { $enh = [StarContrast]::Process($use, 14, 6) }
                $resB = Get-OcrResult $enh
                $enh.Dispose()
                $ranB = $true; $script:LastBAt = Get-Date
                foreach ($ln0 in $resB.Lines) { [void]$allLines.Add([pscustomobject]@{ line = $ln0; pass = 2 }) }
            } catch { Write-Log "contrast pass: $_" }
        }

        $items = New-Object System.Collections.Generic.List[object]
        $symList = New-Object System.Collections.Generic.List[object]
        foreach ($entry in $allLines) {
            $line = $entry.line
            $rawText = [string]$line.Text
            if (-not (Test-Cjk $rawText)) {
                if ($entry.pass -eq 1 -and $rawText.Trim().Length -gt 0) { foreach ($w9 in $line.Words) { Add-SymRect $symList $w9.BoundingRect $scale $rect } }
                continue
            }
            # words that carry a letter or digit (pure symbol words are icons); rectangles are read once
            $wl = New-Object System.Collections.Generic.List[object]
            $pun = New-Object System.Collections.Generic.List[object]
            $lwArr = @($line.Words)
            for ($lwi = 0; $lwi -lt $lwArr.Count; $lwi++) {
                $w0 = $lwArr[$lwi]
                if (([string]$w0.Text) -match '^[\s。、，．,.！!？?：:；;…]+$') { [void]$pun.Add($w0.BoundingRect) }
                $wc = Clean-OcrText ([string]$w0.Text)
                # a widely spaced 一 standing alone between two characters is often read as a dash: "第 - 章" -> 第一章
                if (([string]$w0.Text).Trim() -match '^[\-\u2010-\u2015\u30fc\uff0d_~]$' -and $lwi -gt 0 -and $lwi -lt ($lwArr.Count - 1)) {
                    $pv = Clean-OcrText ([string]$lwArr[$lwi - 1].Text); $nx = Clean-OcrText ([string]$lwArr[$lwi + 1].Text)
                    if ($pv -match '[\u4e00-\u9fff]$' -and $nx -match '^[\u4e00-\u9fff]' -and (Test-OfficialText ($pv + '一' + $nx))) { $wc = '一' }
                }
                if ([regex]::IsMatch($wc, '[\p{L}\p{N}]') -or ($wc -match $script:BrOnlyRx)) { [void]$wl.Add([pscustomobject]@{ t = $wc; r = $w0.BoundingRect; pt = $false }) }   # brackets on their own are kept: they hold their words together
                elseif ($entry.pass -eq 1) { Add-SymRect $symList $w0.BoundingRect $scale $rect }
            }
            if ($wl.Count -eq 0) { continue }
            # widely spaced titles ("第 一 章", "第 二 章" in the season menu) come back one word per character: a run of words
            # that together make one of the game's own strings is protected - none of its characters is taken for an icon
            # (a lone 一 is a solid bar, a lone 第 at the start looks like a leading icon) and the run is never split apart
            $nWp = $wl.Count
            for ($pa0 = 0; $pa0 -lt $nWp - 1; $pa0++) {
                $jt = ([string]$wl[$pa0].t).Trim()
                # the round icon in front of a title is often glued to its first character ("G第"): cut it off when the rest
                # of the run is one of the game's own strings
                $mLead = [regex]::Match($jt, '^([A-Za-z0-9√✓]{1,2})([\u4e00-\u9fff]+)$')
                if ($mLead.Success) {
                    $rest0 = $mLead.Groups[2].Value; $jt2 = $rest0
                    for ($pq = $pa0 + 1; $pq -lt [Math]::Min($nWp, $pa0 + 8); $pq++) {
                        $jt2 += ([string]$wl[$pq].t).Trim()
                        if ($jt2.Length -gt 14) { break }
                        if (Test-OfficialText $jt2) {
                            $r0 = $wl[$pa0].r; $cut = [double]$r0.Width * (0.6 * $mLead.Groups[1].Value.Length) / (0.6 * $mLead.Groups[1].Value.Length + $rest0.Length)
                            Add-SymRect $symList ([pscustomobject]@{ X = [double]$r0.X; Y = [double]$r0.Y; Width = $cut; Height = [double]$r0.Height }) $scale $rect
                            $wl[$pa0] = [pscustomobject]@{ t = $rest0; r = [pscustomobject]@{ X = [double]$r0.X + $cut; Y = [double]$r0.Y; Width = [double]$r0.Width - $cut; Height = [double]$r0.Height }; pt = $false }
                            $jt = $rest0
                            break
                        }
                    }
                }
                for ($pb0 = $pa0 + 1; $pb0 -lt [Math]::Min($nWp, $pa0 + 8); $pb0++) {
                    $jt += ([string]$wl[$pb0].t).Trim()
                    if ($jt.Length -gt 14) { break }
                    if ($jt.Length -ge 2 -and (Test-OfficialText $jt)) { for ($pc0 = $pa0; $pc0 -le $pb0; $pc0++) { $wl[$pc0].pt = $true } }
                }
            }
            # a short word whose ink has a solid core (padlock, filled badge ...) is an icon, not text
            if ($script:Glass2Ok) {
                $keepW = New-Object System.Collections.Generic.List[object]
                foreach ($wq in $wl) {
                    $isIcon = $false; $spTxt = ''
                    # a character that sits tight against its neighbours is part of a text run (the OCR often returns one word per character): never an icon
                    $inRun = $false
                    try {
                        $r1 = $wq.r; $lim1 = [Math]::Max([double]$r1.Width, [double]$r1.Height)
                        foreach ($wo in $line.Words) {
                            $r2 = $wo.BoundingRect
                            if ([Math]::Abs([double]$r2.X - [double]$r1.X) -lt 0.5 -and [Math]::Abs([double]$r2.Y - [double]$r1.Y) -lt 0.5 -and [Math]::Abs([double]$r2.Width - [double]$r1.Width) -lt 0.5) { continue }
                            $gap1 = [Math]::Max([double]$r2.X - ([double]$r1.X + [double]$r1.Width), [double]$r1.X - ([double]$r2.X + [double]$r2.Width))
                            $ov1 = [Math]::Min([double]$r1.Y + [double]$r1.Height, [double]$r2.Y + [double]$r2.Height) - [Math]::Max([double]$r1.Y, [double]$r2.Y)
                            if ($gap1 -le (0.45 * $lim1) -and $ov1 -gt (0.5 * [Math]::Min([double]$r1.Height, [double]$r2.Height))) { $inRun = $true; break }
                        }
                    } catch { $inRun = $false }
                    if (-not $inRun -and -not [bool]$wq.pt -and ([string]$wq.t) -notmatch $script:BrOnlyRx -and ([string]$wq.t).Length -le 2 -and $wq.r.Width -gt 0) {
                        try {
                            $sp = [StarGlass2]::SolidPct($bmp, [int][Math]::Floor($wq.r.X / $scale), [int][Math]::Floor($wq.r.Y / $scale), [int][Math]::Ceiling($wq.r.Width / $scale), [int][Math]::Ceiling($wq.r.Height / $scale))
                            if ($sp -and $sp.Length -eq 2 -and [int]$sp[0] -ge 0 -and [int]$sp[1] -le 88) {
                                $thrS = 14; if (Test-KnownText ([string]$wq.t)) { $thrS = 28 }
                                if ([int]$sp[0] -ge $thrS) { $isIcon = $true; $spTxt = ' (' + [int]$sp[0] + '% solid)' }
                            }
                        } catch {}
                    }
                    if ($isIcon) { Log-Reject 'icon-shape' (([string]$wq.t) + $spTxt); Add-SymRect $symList $wq.r $scale $rect }
                    else { [void]$keepW.Add($wq) }
                }
                $wl = $keepW
                if ($wl.Count -eq 0) { continue }
            }
            # a lone lowercase Latin letter between Chinese words is a symbol that the OCR read as "a", "o" ... (padlock, dot, badge)
            if ($wl.Count -gt 0) {
                $keepL = New-Object System.Collections.Generic.List[object]
                for ($wi = 0; $wi -lt $wl.Count; $wi++) {
                    $wq = $wl[$wi]
                    $isLet = $false
                    if ([regex]::IsMatch([string]$wq.t, '^[a-z]$')) {
                        $pa = $false; $na = $false
                        if ($wi -gt 0) { $pa = [regex]::IsMatch([string]$wl[$wi - 1].t, '[A-Za-z0-9]$') }
                        if ($wi -lt ($wl.Count - 1)) { $na = [regex]::IsMatch([string]$wl[$wi + 1].t, '^[A-Za-z0-9]') }
                        if (-not $pa -and -not $na) { $isLet = $true }
                    }
                    if ($isLet) { Log-Reject 'icon-letter' ([string]$wq.t); Add-SymRect $symList $wq.r $scale $rect } else { [void]$keepL.Add($wq) }
                }
                $wl = $keepL
                if ($wl.Count -eq 0) { continue }
            }
            # split the row where two words are more than ~1.8 glyphs apart: separate buttons / tabs / icons share one OCR row
            $segs = New-Object System.Collections.Generic.List[object]
            $cur = New-Object System.Collections.Generic.List[object]
            $brDepth = 0
            foreach ($wq in $wl) {
                if ($cur.Count -gt 0) {
                    $pr = $cur[$cur.Count - 1].r
                    $gapW = [double]$wq.r.X - ([double]$pr.X + [double]$pr.Width)
                    $hhW = [Math]::Max([double]$pr.Height, [double]$wq.r.Height)
                    if ($brDepth -gt 0 -and $gapW -gt (5 * $hhW)) { $brDepth = 0 }      # a bracket that never closed (misread): give up on it far away
                    if ($brDepth -le 0 -and $gapW -gt (1.8 * $hhW) -and -not ([bool]$wq.pt -and [bool]$cur[$cur.Count - 1].pt)) { [void]$segs.Add($cur); $cur = New-Object System.Collections.Generic.List[object] }
                }
                [void]$cur.Add($wq)
                # inside 【 】 《 》 （ ） 「 」 the words stay together, however far apart they are
                foreach ($ch in ([string]$wq.t).ToCharArray()) { if ($script:BrOpen.IndexOf($ch) -ge 0) { $brDepth++ } elseif ($script:BrClose.IndexOf($ch) -ge 0 -and $brDepth -gt 0) { $brDepth-- } }
            }
            if ($cur.Count -gt 0) { [void]$segs.Add($cur) }
            # a full stop / comma right after the last word belongs to the text: the box must cover it too
            if ($pun.Count -gt 0) {
                foreach ($sg0 in $segs) {
                    $lastW = $sg0[$sg0.Count - 1]
                    for ($pj = 0; $pj -lt 2; $pj++) {
                        $lastR = $lastW.r; $took = $false
                        foreach ($pr in $pun) {
                            $gp = [double]$pr.X - ([double]$lastR.X + [double]$lastR.Width)
                            $vo = [Math]::Min([double]$pr.Y + [double]$pr.Height, [double]$lastR.Y + [double]$lastR.Height) - [Math]::Max([double]$pr.Y, [double]$lastR.Y)
                            if ($gp -ge -2 -and $gp -le (0.9 * [double]$lastR.Height) -and $vo -gt (0.3 * [double]$pr.Height)) {
                                $lastW = [pscustomobject]@{ t = ''; r = $pr }; [void]$sg0.Add($lastW); $took = $true; break
                            }
                        }
                        if (-not $took) { break }
                    }
                }
            }
            for ($si = 0; $si -lt $segs.Count; $si++) {
                $sg = $segs[$si]
                $text = ''
                foreach ($wq in $sg) {
                    $tw = [string]$wq.t
                    if ($text.Length -gt 0 -and $tw.Length -gt 0) {
                        if ([regex]::IsMatch($text.Substring($text.Length - 1), '[A-Za-z0-9]') -and [regex]::IsMatch($tw.Substring(0, 1), '[A-Za-z0-9]')) { $text += ' ' }
                    }
                    $text += $tw
                }
                $text = $text.Trim()
                # a lone icon-looking glyph at either end, set apart from the text by a gap, is an icon and not a letter
                for ($gd = 0; $gd -lt 3; $gd++) {
                    if ($sg.Count -lt 2) { break }
                    $dropped = $false
                    $fa = $sg[0]; $fb = $sg[1]
                    $gapF = [double]$fb.r.X - ([double]$fa.r.X + [double]$fa.r.Width)
                    if ([bool]$fa.pt -and [bool]$sg[$sg.Count - 1].pt) { break }        # a protected run (e.g. 第 一 章): nothing to drop
                    if (([string]$fa.t) -match $script:BrOnlyRx) { break }               # an opening bracket is not an icon
                    $iconLead = (-not [bool]$fa.pt) -and ($fa.t.Length -eq 1 -and ([string]$fb.t).Length -gt 0 -and [regex]::IsMatch(([string]$fb.t).Substring(0, 1), '[\u4e00-\u9fff]') -and ($gapF -gt (0.6 * [double]$fb.r.Height) -or ([double]$fa.r.Height -gt 1.25 * [double]$fb.r.Height -and $gapF -gt (0.25 * [double]$fb.r.Height))))
                    # a check box / tick in front of an option is often read as "7", "V" or "√"; a real number is followed by its
                    # unit (7天, 7次, 7级 ...) - anything else after a lone 7 / V is the box
                    $boxLead = ($fa.t -match '^[7VvY√✓]$' -and ([string]$fb.t) -match '^[\u4e00-\u9fff]' -and ([string]$fb.t) -notmatch '^[天日次级个倍星阶连分秒人名场局轮周月年章关折万亿]' -and $gapF -gt (0.12 * [double]$fb.r.Height))
                    if ($iconLead -or $boxLead -or (-not [bool]$fa.pt -and $fa.t.Length -eq 1 -and ($script:LookalikeHan.IndexOf($fa.t) -ge 0 -or [regex]::IsMatch([string]$fa.t, '^[A-Za-z]$')) -and $gapF -gt (0.4 * [double]$fa.r.Height))) {
                        Add-SymRect $symList $fa.r $scale $rect
                        $sg.RemoveAt(0); $dropped = $true
                        if ($text.StartsWith($fa.t)) { $text = $text.Substring($fa.t.Length).Trim() }
                    } else {
                        $la = $sg[$sg.Count - 1]; $lb = $sg[$sg.Count - 2]
                        $gapL = [double]$la.r.X - ([double]$lb.r.X + [double]$lb.r.Width)
                        if (-not [bool]$la.pt -and $la.t.Length -eq 1 -and ($script:LookalikeHan.IndexOf($la.t) -ge 0 -or [regex]::IsMatch([string]$la.t, '^[A-Za-z]$')) -and $gapL -gt (0.4 * [double]$la.r.Height)) {
                            Add-SymRect $symList $la.r $scale $rect
                            $sg.RemoveAt($sg.Count - 1); $dropped = $true
                            if ($text.EndsWith($la.t)) { $text = $text.Substring(0, $text.Length - $la.t.Length).Trim() }
                        }
                    }
                    if (-not $dropped) { break }
                }
                if ($sg.Count -eq 0) { continue }
                # controller / keyboard button prompts (A, B, X, Y, LB, RB, LT, RT, Esc, F ...): never translated and never
                # covered - they are taken out of the text and kept clear of labels, also when the OCR glued them to the Chinese
                $btnRx = '^(?:[ABXY]|LB|RB|LT|RT|LS|RS|L1|R1|L2|R2|L3|R3|ZL|ZR|ESC|Esc|esc|TAB|Tab|Enter|ENTER|Space|SPACE|Shift|SHIFT|Ctrl|CTRL|Alt|ALT|F[1-9]|F1[0-2])$'
                $fuseRx = '^(LB|RB|LT|RT|LS|RS|ZL|ZR|Esc|ESC|[ABXY])([一-鿿].*)$'
                $fuseRxE = '^(.*[一-鿿])(LB|RB|LT|RT|LS|RS|ZL|ZR|Esc|ESC|[ABXY])$'
                if ([regex]::IsMatch($text, '^[\s]*(?:(?:[ABXY]|LB|RB|LT|RT|LS|RS|ZL|ZR|Esc|ESC|Tab|TAB|F\d{1,2})[\s/+]*)+$')) {
                    foreach ($wq in $sg) { Add-SymRect $symList $wq.r $scale $rect }
                    continue
                }
                if ([regex]::IsMatch($text, '[一-鿿]')) {
                    $keepB = New-Object System.Collections.Generic.List[object]; $chB = $false
                    foreach ($wq in $sg) {
                        $wt = ([string]$wq.t).Trim()
                        if ([regex]::IsMatch($wt, $btnRx)) { Add-SymRect $symList $wq.r $scale $rect; $chB = $true; continue }
                        $mB = [regex]::Match($wt, $fuseRx); $mE = [regex]::Match($wt, $fuseRxE)
                        if ($mB.Success -or $mE.Success) {
                            if ($mB.Success) { $bt = $mB.Groups[1].Value; $rest = $mB.Groups[2].Value } else { $bt = $mE.Groups[2].Value; $rest = $mE.Groups[1].Value }
                            $wb = 0.6 * $bt.Length; $wr = 0.0
                            foreach ($ch in $rest.ToCharArray()) { if ([int]$ch -ge 0x4E00 -and [int]$ch -le 0x9FFF) { $wr += 1.0 } else { $wr += 0.55 } }
                            $bw = [double]$wq.r.Width * $wb / ($wb + $wr)
                            if ($mB.Success) {
                                $rb = [pscustomobject]@{ X = [double]$wq.r.X; Y = [double]$wq.r.Y; Width = $bw; Height = [double]$wq.r.Height }
                                $rr = [pscustomobject]@{ X = [double]$wq.r.X + $bw; Y = [double]$wq.r.Y; Width = [double]$wq.r.Width - $bw; Height = [double]$wq.r.Height }
                            } else {
                                $rr = [pscustomobject]@{ X = [double]$wq.r.X; Y = [double]$wq.r.Y; Width = [double]$wq.r.Width - $bw; Height = [double]$wq.r.Height }
                                $rb = [pscustomobject]@{ X = [double]$wq.r.X + [double]$wq.r.Width - $bw; Y = [double]$wq.r.Y; Width = $bw; Height = [double]$wq.r.Height }
                            }
                            Add-SymRect $symList $rb $scale $rect
                            [void]$keepB.Add([pscustomobject]@{ t = $rest; r = $rr }); $chB = $true
                            continue
                        }
                        [void]$keepB.Add($wq)
                    }
                    if ($chB) {
                        if ($keepB.Count -eq 0) { continue }
                        $sg = $keepB
                        $text = ''
                        foreach ($wq in $sg) {
                            $tw = [string]$wq.t
                            if ($text.Length -gt 0 -and $tw.Length -gt 0) {
                                if ([regex]::IsMatch($text.Substring($text.Length - 1), '[A-Za-z0-9]') -and [regex]::IsMatch($tw.Substring(0, 1), '[A-Za-z0-9]')) { $text += ' ' }
                            }
                            $text += $tw
                        }
                        $text = $text.Trim()
                    }
                }
                # names, currencies, rank badges and numbered season / challenge / event words get labels of their own:
                # "午后球场百川2阶" -> Afternoon Court | Hundred Rivers II, "冯宝宝 Lv.30" -> Feng Baobao (number stays visible),
                # "银鲤币x200" -> Silver Carp Coins (x200 stays visible), "挑战3/10" -> Challenge (3/10 stays visible)
                if ($null -eq $script:IsoRx) { $script:IsoRx = '(' + $script:RankRx + ')|(' + $script:IsoNames + ')|(' + $script:IsoCur + ')|((?<=\d\s*)(?:赛季|挑战|活动)|(?:赛季|挑战|活动)(?=\s*\d))' }
                if (-not (Test-OfficialText $text) -and [regex]::IsMatch($text, $script:IsoRx)) {
                    $cells = New-Object System.Collections.Generic.List[object]
                    foreach ($wq in $sg) {
                        $wt = [string]$wq.t
                        if ($wt.Length -eq 0) { continue }
                        $wsum = 0.0; foreach ($ch in $wt.ToCharArray()) { if ([int]$ch -ge 0x4E00 -and [int]$ch -le 0x9FFF) { $wsum += 1.0 } else { $wsum += 0.55 } }
                        $px = [double]$wq.r.X
                        foreach ($ch in $wt.ToCharArray()) {
                            $cw0 = 0.55; if ([int]$ch -ge 0x4E00 -and [int]$ch -le 0x9FFF) { $cw0 = 1.0 }
                            $pw = [double]$wq.r.Width * $cw0 / $wsum
                            [void]$cells.Add([pscustomobject]@{ c = [string]$ch; x = $px; w = $pw; y = [double]$wq.r.Y; h = [double]$wq.r.Height })
                            $px += $pw
                        }
                    }
                    $cs = -join @($cells | ForEach-Object { $_.c })
                    $hanN = [regex]::Matches($cs, '[一-鿿]').Count
                    $mAll = @([regex]::Matches($cs, $script:IsoRx) | Where-Object { $_.Length -gt 0 })
                    $brS = Get-BracketSpans $cs
                    # only on short lines (names, badges, prices, counters, list rows) - sentences are translated whole
                    if ($hanN -le 16 -and $mAll.Count -gt 0) {
                        $cutList = New-Object System.Collections.Generic.List[object]; $pos = 0
                        foreach ($mm in $mAll) {
                            # a bare rank name without its tier only on very short lines
                            if ($mm.Groups[1].Success -and -not $mm.Groups[3].Success -and $hanN -gt 8) { continue }
                            $fit = Fit-ToBrackets $brS $mm.Index $mm.Length
                            if ($null -eq $fit) { continue }
                            $mI = [int]$fit[0]; $mL = [int]$fit[1]
                            if ($mI -lt $pos) { continue }
                            if ($mI -gt $pos) { [void]$cutList.Add(@($pos, ($mI - $pos), $false)) }
                            [void]$cutList.Add(@($mI, $mL, $true)); $pos = $mI + $mL
                        }
                        if ($pos -lt $cs.Length) { [void]$cutList.Add(@($pos, ($cs.Length - $pos), $false)) }
                        # every other piece with Chinese in it must make sense on its own (one of the game's words), or be set
                        # apart from the name / currency by a gap or a symbol - "冯宝宝的生日" stays one sentence
                        $okIso = ($cutList.Count -gt 1)
                        for ($k = 0; $k -lt $cutList.Count -and $okIso; $k++) {
                            $cu = $cutList[$k]
                            if ([bool]$cu[2]) { continue }
                            $ptx = $cs.Substring([int]$cu[0], [int]$cu[1]).Trim()
                            if ($ptx -notmatch '[一-鿿]') { continue }
                            if (Test-OfficialText $ptx) { continue }
                            foreach ($nb in @(($k - 1), ($k + 1))) {
                                if ($nb -lt 0 -or $nb -ge $cutList.Count -or -not [bool]$cutList[$nb][2]) { continue }
                                $aIdx = [int]$cu[0]; $bIdx = [int]$cu[0] + [int]$cu[1] - 1
                                if ($nb -lt $k) { $l0 = [int]$cutList[$nb][0] + [int]$cutList[$nb][1] - 1; $r0 = $aIdx } else { $l0 = $bIdx; $r0 = [int]$cutList[$nb][0] }
                                $border = ($cs[$l0] -notmatch '[一-鿿]') -or ($cs[$r0] -notmatch '[一-鿿]')
                                if (-not $border) { $gx = [double]$cells[$r0].x - ([double]$cells[$l0].x + [double]$cells[$l0].w); $border = ($gx -ge 0.45 * [double]$cells[$r0].h) }
                                if (-not $border) { $okIso = $false }
                            }
                        }
                        if ($okIso) {
                            $parts = New-Object System.Collections.Generic.List[object]
                            foreach ($cu in $cutList) {
                                $a0 = [int]$cu[0]; $n0 = [int]$cu[1]
                                while ($n0 -gt 0 -and [string]::IsNullOrWhiteSpace($cells[$a0].c)) { $a0++; $n0-- }
                                while ($n0 -gt 0 -and [string]::IsNullOrWhiteSpace($cells[$a0 + $n0 - 1].c)) { $n0-- }
                                if ($n0 -le 0) { continue }
                                $pt0 = $cs.Substring($a0, $n0)
                                $x0 = [double]$cells[$a0].x; $x1 = [double]$cells[$a0 + $n0 - 1].x + [double]$cells[$a0 + $n0 - 1].w
                                $y0 = 1e9; $y1 = -1e9
                                for ($ci = $a0; $ci -lt $a0 + $n0; $ci++) { if ($cells[$ci].y -lt $y0) { $y0 = $cells[$ci].y }; if ($cells[$ci].y + $cells[$ci].h -gt $y1) { $y1 = $cells[$ci].y + $cells[$ci].h } }
                                $pr0 = [pscustomobject]@{ X = $x0; Y = $y0; Width = ($x1 - $x0); Height = ($y1 - $y0) }
                                if (-not [regex]::IsMatch($pt0, '[一-鿿]')) { Add-SymRect $symList $pr0 $scale $rect; continue }     # numbers / symbols stay visible
                                $gp0 = New-Object System.Collections.Generic.List[object]
                                [void]$gp0.Add([pscustomobject]@{ t = $pt0.Trim(); r = $pr0; pt = $true })
                                [void]$parts.Add($gp0)
                            }
                            if ($parts.Count -gt 0) {
                                $sg = $parts[0]
                                $text = [string]$sg[0].t
                                for ($gi = 1; $gi -lt $parts.Count; $gi++) { [void]$segs.Add($parts[$gi]) }
                            }
                        }
                    }
                }
                # a row of separate buttons / tabs with icons between them ("[>] 阵容方案  [cam] 战斗录像  [|||] 切磋排行 ...") often comes
                # back from the OCR as ONE line, with the icons read as stray characters or letters - which made the whole row
                # look like junk and it was dropped. When the row is made of the game's own words (plus a stray glyph or two),
                # every word is cut out and gets its own label; the stray glyphs (icons) are kept clear of labels.
                $hanAll = [regex]::Matches($text, '[一-鿿]').Count
                if ($hanAll -ge 3 -and $hanAll -le 30 -and -not (Test-OfficialText $text) -and -not (Translate-Local $text) -and ($sg.Count -ge 2 -or $hanAll -ge 5)) {
                    $cells = New-Object System.Collections.Generic.List[object]
                    foreach ($wq in $sg) {
                        $wt = [string]$wq.t
                        if ($wt.Length -eq 0) { continue }
                        $wsum = 0.0; foreach ($ch in $wt.ToCharArray()) { if ([int]$ch -ge 0x4E00 -and [int]$ch -le 0x9FFF) { $wsum += 1.0 } else { $wsum += 0.55 } }
                        $px = [double]$wq.r.X
                        foreach ($ch in $wt.ToCharArray()) {
                            $cw0 = 0.55; if ([int]$ch -ge 0x4E00 -and [int]$ch -le 0x9FFF) { $cw0 = 1.0 }
                            $pw = [double]$wq.r.Width * $cw0 / $wsum
                            [void]$cells.Add([pscustomobject]@{ c = [string]$ch; x = $px; w = $pw; y = [double]$wq.r.Y; h = [double]$wq.r.Height })
                            $px += $pw
                        }
                    }
                    $cs = -join @($cells | ForEach-Object { $_.c })
                    # longest game word starting at each position (2..12 characters, Chinese only)
                    $terms = New-Object System.Collections.Generic.List[object]
                    $ci = 0
                    while ($ci -lt $cs.Length) {
                        $hit = 0
                        if ([int][char]$cs[$ci] -ge 0x4E00 -and [int][char]$cs[$ci] -le 0x9FFF) {
                            for ($ln = [Math]::Min(12, $cs.Length - $ci); $ln -ge 2; $ln--) {
                                $sub = $cs.Substring($ci, $ln)
                                if ($sub -notmatch '^[一-鿿]+$') { continue }
                                if (Test-OfficialText $sub) { $hit = $ln; break }
                            }
                        }
                        if ($hit -gt 0) { [void]$terms.Add(@($ci, $hit)); $ci += $hit } else { $ci++ }
                    }
                    $brS2 = Get-BracketSpans $cs
                    if ($brS2.Count -gt 0) {
                        $t2 = New-Object System.Collections.Generic.List[object]; $lastEnd = -1
                        foreach ($tm in $terms) {
                            $fit = Fit-ToBrackets $brS2 ([int]$tm[0]) ([int]$tm[1])
                            if ($null -eq $fit) { $t2 = $null; break }                       # a word crossing a bracket: do not split this row
                            if ([int]$fit[0] -le $lastEnd) { continue }                     # two words in the same brackets: one piece
                            [void]$t2.Add($fit); $lastEnd = [int]$fit[0] + [int]$fit[1] - 1
                        }
                        if ($null -eq $t2) { $terms = New-Object System.Collections.Generic.List[object] } else { $terms = $t2 }
                    }
                    $covered = 0; foreach ($tm in $terms) { $covered += [regex]::Matches($cs.Substring([int]$tm[0], [int]$tm[1]), '[\u4e00-\u9fff]').Count }
                    # the characters left over must look like icons (strokes / boxes), never real characters: "玩法奖" with the
                    # last character hidden is not "玩法" + an icon
                    $leftOk = $true
                    $mark = New-Object 'bool[]' $cs.Length
                    foreach ($tm in $terms) { for ($q = [int]$tm[0]; $q -lt [int]$tm[0] + [int]$tm[1]; $q++) { $mark[$q] = $true } }
                    for ($q = 0; $q -lt $cs.Length; $q++) { if (-not $mark[$q] -and $cs[$q] -match '[\u4e00-\u9fff]' -and $script:LookalikeHan.IndexOf([string]$cs[$q]) -lt 0) { $leftOk = $false; break } }
                    $leftHan = $hanAll - $covered
                    # split only when the game's words make up the row: two or more of them with at most one stray character
                    # per word left over, or one word with a single stray glyph beside it
                    # and the words must stand apart (an icon / other glyph or a clear gap between them): two words written
                    # together are one name, which is better translated as a whole
                    $apart = $true
                    for ($ti = 1; $ti -lt $terms.Count; $ti++) {
                        $endA = [int]$terms[$ti - 1][0] + [int]$terms[$ti - 1][1]; $startB = [int]$terms[$ti][0]
                        if ($startB -gt $endA -and -not [string]::IsNullOrWhiteSpace($cs.Substring($endA, $startB - $endA))) { continue }
                        $gx = [double]$cells[$startB].x - ([double]$cells[$endA - 1].x + [double]$cells[$endA - 1].w)
                        if ($gx -lt 0.8 * [double]$cells[$startB].h) { $apart = $false; break }
                    }
                    if ($apart -and $leftOk -and (($terms.Count -ge 2 -and $leftHan -le $terms.Count) -or ($terms.Count -eq 1 -and $leftHan -le 1 -and $covered -lt $hanAll))) {
                        $parts = New-Object System.Collections.Generic.List[object]
                        $pos = 0
                        $cutList = New-Object System.Collections.Generic.List[object]
                        foreach ($tm in $terms) {
                            if ([int]$tm[0] -gt $pos) { [void]$cutList.Add(@($pos, ([int]$tm[0] - $pos), $false)) }
                            [void]$cutList.Add(@([int]$tm[0], [int]$tm[1], $true)); $pos = [int]$tm[0] + [int]$tm[1]
                        }
                        if ($pos -lt $cs.Length) { [void]$cutList.Add(@($pos, ($cs.Length - $pos), $false)) }
                        foreach ($cu in $cutList) {
                            $a0 = [int]$cu[0]; $n0 = [int]$cu[1]
                            while ($n0 -gt 0 -and [string]::IsNullOrWhiteSpace($cells[$a0].c)) { $a0++; $n0-- }
                            while ($n0 -gt 0 -and [string]::IsNullOrWhiteSpace($cells[$a0 + $n0 - 1].c)) { $n0-- }
                            if ($n0 -le 0) { continue }
                            $x0 = [double]$cells[$a0].x; $x1 = [double]$cells[$a0 + $n0 - 1].x + [double]$cells[$a0 + $n0 - 1].w
                            $y0 = 1e9; $y1 = -1e9
                            for ($cj = $a0; $cj -lt $a0 + $n0; $cj++) { if ($cells[$cj].y -lt $y0) { $y0 = $cells[$cj].y }; if ($cells[$cj].y + $cells[$cj].h -gt $y1) { $y1 = $cells[$cj].y + $cells[$cj].h } }
                            $pr0 = [pscustomobject]@{ X = $x0; Y = $y0; Width = ($x1 - $x0); Height = ($y1 - $y0) }
                            if (-not [bool]$cu[2]) { Add-SymRect $symList $pr0 $scale $rect; continue }          # icon / stray glyph / number: left visible
                            $gp0 = New-Object System.Collections.Generic.List[object]
                            [void]$gp0.Add([pscustomobject]@{ t = $cs.Substring($a0, $n0); r = $pr0; pt = $true })
                            [void]$parts.Add($gp0)
                        }
                        if ($parts.Count -gt 0) {
                            $sg = $parts[0]
                            $text = [string]$sg[0].t
                            for ($gi = 1; $gi -lt $parts.Count; $gi++) { [void]$segs.Add($parts[$gi]) }
                        }
                    }
                }
                # known words with numbers between / after them ("阶段6（1/3）", "赛季1·风起", "等级 10"): each word gets its own
                # label and the game's own numbers stay visible between them (the OCR often loses brackets, slashes and dots,
                # so numbers are never re-typed)
                if ([regex]::IsMatch($text, '\d') -and -not (Translate-Local $text) -and [regex]::IsMatch($text, '^[\u4e00-\u9fff\s\d\(\)\uff08\uff09/\uff0f:\uff1a%\.\-+\u00b7\u30fb]+$')) {
                    $runs = [regex]::Matches($text, '[\u4e00-\u9fff]+')
                    $allKnown = ($runs.Count -ge 1)
                    foreach ($ru in $runs) { if ($ru.Value.Length -gt 8 -or -not $script:Dict.ContainsKey((Get-NormKey $ru.Value))) { $allKnown = $false } }
                    if ($allKnown) {
                        $groups = New-Object System.Collections.Generic.List[object]
                        $curG = New-Object System.Collections.Generic.List[object]
                        foreach ($wq in $sg) {
                            $wt = [string]$wq.t
                            if ($wt.Length -eq 0) { continue }
                            # cut the word into Chinese / other pieces; each piece gets its share of the word's box
                            $pcs = [regex]::Matches($wt, '[\u4e00-\u9fff]+|[^\u4e00-\u9fff]+')
                            $wsum = 0.0; foreach ($pc in $pcs) { if ([regex]::IsMatch($pc.Value, '^[\u4e00-\u9fff]')) { $wsum += $pc.Value.Length } else { $wsum += 0.55 * $pc.Value.Length } }
                            if ($wsum -le 0) { continue }
                            $px = [double]$wq.r.X
                            foreach ($pc in $pcs) {
                                $isHan = [regex]::IsMatch($pc.Value, '^[\u4e00-\u9fff]')
                                $pw0 = 0.55 * $pc.Value.Length; if ($isHan) { $pw0 = [double]$pc.Value.Length }
                                $pw = [double]$wq.r.Width * $pw0 / $wsum
                                $nr = [pscustomobject]@{ X = $px; Y = [double]$wq.r.Y; Width = $pw; Height = [double]$wq.r.Height }
                                $px += $pw
                                if ($isHan) { [void]$curG.Add([pscustomobject]@{ t = $pc.Value; r = $nr }) }
                                else {
                                    if ($pc.Value.Trim().Length -gt 0) { Add-SymRect $symList $nr $scale $rect }
                                    if ($curG.Count -gt 0) { [void]$groups.Add($curG); $curG = New-Object System.Collections.Generic.List[object] }
                                }
                            }
                        }
                        if ($curG.Count -gt 0) { [void]$groups.Add($curG) }
                        if ($groups.Count -gt 0) {
                            $sg = $groups[0]
                            $text = ''; foreach ($wq in $sg) { $text += [string]$wq.t }
                            for ($gi = 1; $gi -lt $groups.Count; $gi++) { [void]$segs.Add($groups[$gi]) }     # the other words are handled as their own rows
                        }
                    }
                }
                if (-not (Test-Cjk $text)) { continue }
                # numbers on their own are left exactly as they are (they only change from a million up)
                $nvv = Get-NumberOnlyValue $text
                if ($null -ne $nvv -and $nvv -lt 1000000) { Log-Reject 'number' $text; foreach ($wq in $sg) { Add-SymRect $symList $wq.r $scale $rect }; continue }
                $joinedLone = $false
                if (($text -replace '\s', '').Length -eq 1 -and $sg.Count -eq 1 -and $items.Count -gt 0) {
                    $lr = $sg[0].r
                    $lx1 = $rect.X + ($lr.X / $scale); $ly1 = $rect.Y + ($lr.Y / $scale); $lw1 = $lr.Width / $scale; $lh1 = $lr.Height / $scale
                    foreach ($ex in $items) {
                        if ($null -eq $ex.rx -or ([string]$ex.text).Length -lt 2) { continue }
                        $gapM = $lx1 - ([double]$ex.rx + [double]$ex.rw)
                        if ($gapM -lt -2 -or $gapM -gt (0.6 * $lh1)) { continue }
                        if ([Math]::Abs([double]$ex.rh - $lh1) -gt (0.25 * [Math]::Max([double]$ex.rh, $lh1))) { continue }
                        if ([Math]::Abs(([double]$ex.ry + [double]$ex.rh / 2.0) - ($ly1 + $lh1 / 2.0)) -gt (0.25 * $lh1)) { continue }
                        $ex.text = [string]$ex.text + $text
                        $newR = [Math]::Max([double]$ex.rx + [double]$ex.rw, $lx1 + $lw1)
                        $ex.rw = [int]($newR - [double]$ex.rx); $ex.w = [int]$ex.rw
                        if ($script:Glass2Ok) { try { $ex.sig = [StarGlass2]::TextSig($bmp, ([int]$ex.rx - $rect.X), ([int]$ex.ry - $rect.Y), [int]$ex.rw, [int]$ex.rh) } catch {} }
                        $joinedLone = $true; break
                    }
                }
                if ($joinedLone) { continue }
                if (-not (Test-RealText $text)) { Log-Reject 'symbol-like' $text; foreach ($wq in $sg) { Add-SymRect $symList $wq.r $scale $rect }; continue }
                $gz = Get-GhostScore $text
                if ($gz -ge 2 -and -not (Test-OfficialText $text)) { Log-Reject 'ghost-like' $text; continue }
                $minX = 1e9; $minY = 1e9; $maxX = -1e9; $maxY = -1e9; $n = 0
                foreach ($wq in $sg) {
                    $r = $wq.r
                    $x1 = $rect.X + ($r.X / $scale); $y1 = $rect.Y + ($r.Y / $scale)
                    $x2 = $rect.X + (($r.X + $r.Width) / $scale); $y2 = $rect.Y + (($r.Y + $r.Height) / $scale)
                    if ($x1 -lt $minX) { $minX = $x1 }; if ($y1 -lt $minY) { $minY = $y1 }
                    if ($x2 -gt $maxX) { $maxX = $x2 }; if ($y2 -gt $maxY) { $maxY = $y2 }
                    $n++
                }
                if ($n -eq 0) { continue }
                $bw1 = $maxX - $minX; $bh1 = $maxY - $minY
                $nch = ($text -replace '\s', '').Length
                if ($bh1 -lt 8 -or $bh1 -gt 140 -or $nch -lt 1) { Log-Reject 'size' $text; foreach ($wq in $sg) { Add-SymRect $symList $wq.r $scale $rect }; continue }
                $perChar = ($bw1 / $nch) / $bh1
                if ($perChar -lt 0.42 -or $perChar -gt 2.6) { Log-Reject 'shape' $text; foreach ($wq in $sg) { Add-SymRect $symList $wq.r $scale $rect }; continue }      # width per character must look like real type
                if ($entry.pass -eq 2) {
                    if ($nch -lt 2) { continue }
                    $dup = $false
                    $areaB = [Math]::Max(1.0, $bw1 * $bh1)
                    foreach ($ex in $items) {
                        $ix = [Math]::Min($maxX, $ex.x + $ex.w) - [Math]::Max($minX, $ex.x)
                        $iy = [Math]::Min($maxY, $ex.y + $ex.h) - [Math]::Max($minY, $ex.y)
                        if ($ix -gt 0 -and $iy -gt 0) {
                            $inter = $ix * $iy
                            if ($inter / [Math]::Min($areaB, [Math]::Max(1.0, $ex.w * $ex.h)) -ge 0.4) { $dup = $true; break }
                        }
                    }
                    if ($dup) { continue }
                }
                if ([int]$entry.pass -eq 2 -and $script:MaskOk) {
                    # the extra pass's box can be off by 10-30 px: put it on the light ink actually there
                    try {
                        $rng = [int][Math]::Min(34, [Math]::Max(8, [Math]::Round(0.9 * $bh1)))
                        $bs = [StarMask]::BestShift($bmp, [int]($minX - $rect.X), [int]($minY - $rect.Y), [int]($maxX - $minX), [int]($maxY - $minY), $rng, 2)
                        if ($bs -and $bs.Length -ge 2 -and ([int]$bs[0] -ne 0 -or [int]$bs[1] -ne 0)) {
                            $minX = $minX + [int]$bs[0]; $maxX = $maxX + [int]$bs[0]; $minY = $minY + [int]$bs[1]; $maxY = $maxY + [int]$bs[1]
                            $script:Perf.shift = [int]$script:Perf.shift + 1
                        }
                    } catch {}
                }
                $col = @{ r = 28; g = 28; b = 32 }
                try { $col = Get-RegionColor $bmp ([int]($minX - $rect.X)) ([int]($minY - $rect.Y)) ([int]($maxX - $minX)) ([int]($maxY - $minY)) } catch {}
                $qx = [int]([Math]::Round($minX / 4.0) * 4)
                $qy = [int]([Math]::Round($minY / 4.0) * 4)
                foreach ($old in @($script:LastBlocks)) {
                    if ($old -and [string]$old.src -eq $text) {
                        $dx = [Math]::Abs([int]$old.x - $qx)
                        $dy = [Math]::Abs([int]$old.y - $qy)
                        if ($dx -lt 4 -and $dy -lt 4) { $qx = [int]$old.x; $qy = [int]$old.y }
                        break
                    }
                }
                $tsig = $null
                if ($script:Glass2Ok) { try { $tsig = [StarGlass2]::TextSig($bmp, ([int]($minX - $rect.X)), ([int]($minY - $rect.Y)), ([int]($maxX - $minX)), ([int]($maxY - $minY))) } catch { $tsig = $null } }
                # a reading over an area without any sharp detail is not text on screen (a stray reading from the glow of a
                # button or a soft background): it would put a label in an empty spot, e.g. a second "Duel" above the button
                # (only for readings of the extra contrast passes, and only when not even one part of the area has sharp
                # detail: soft grey text over a photo, like the bottom bar, has little detail on average but always some)
                if ([int]$entry.pass -eq 2 -and $null -ne $tsig -and $tsig.Length -gt 0) {
                    $sigMax = 0; foreach ($sb1 in $tsig) { if ([int]$sb1 -gt $sigMax) { $sigMax = [int]$sb1 } }
                    if ($sigMax -lt 8) {
                        $dupe = $false; foreach ($ex0 in $items) { if ([string]$ex0.text -eq $text) { $dupe = $true; break } }
                        if ($dupe -or -not (Test-OfficialText $text)) { Log-Reject 'no-detail' $text; continue }
                    }
                }
                $items.Add([pscustomobject]@{ text = $text; x = $qx; y = $qy; w = [int]($maxX - $minX); h = [int]($maxY - $minY); bgR = [int]$col.r; bgG = [int]$col.g; bgB = [int]$col.b; pass = [int]$entry.pass; nz = [int]$gz; sig = $tsig; rx = [int]$minX; ry = [int]$minY; rw = [int]($maxX - $minX); rh = [int]($maxY - $minY) }) | Out-Null
            }
        }
        $script:Sym = @($symList.ToArray())
        $script:FreshN = [int]$items.Count          # items after this index are re-used (carried) readings, not new ones
        # pass-B results (dim / small / low-contrast text) are collected over the three kinds of contrast pass and re-used on the
        # scans in between for up to 6 s while the picture under that text is unchanged, so text that only one kind of pass reads
        # (or a busy, moving background) is still confirmed and kept instead of flickering in and out
        # (kept as separate little records {it; cat} so the scan items themselves are never modified here)
        try {
            $nowCm = [double]$script:Clk.ElapsedMilliseconds
            $newCarry = New-Object System.Collections.Generic.List[object]
            $nItems = [int]$items.Count
            $script:FreshN = $nItems
            if ($ranB) {
                for ($ii = 0; $ii -lt $nItems; $ii++) {
                    $ob0 = $items[$ii]
                    if ($null -ne $ob0 -and [int]$ob0.pass -eq 2) { [void]$newCarry.Add([pscustomobject]@{ it = $ob0; cat = $nowCm }) }
                }
            }
            $oldC = $script:BCarry
            if ($null -ne $oldC) {
                $nOld = [int]$oldC.Count
                for ($ci = 0; $ci -lt $nOld; $ci++) {
                    $cw = $oldC[$ci]
                    if ($null -eq $cw) { continue }
                    $cb = $cw.it
                    if ($null -eq $cb) { continue }
                    if (($nowCm - [double]$cw.cat) -gt 3500) { continue }
                    if (([int](Get-RegionChange $cb $bmp $rect)) -ge 5) { continue }
                    $dupc = $false
                    # the same text read anywhere now means the remembered spot is out of date (a menu slid into place)
                    for ($ei = 0; $ei -lt $items.Count; $ei++) { if ([string]$items[$ei].text -eq [string]$cb.text) { $dupc = $true; break } }
                    if ($dupc) { continue }
                    $cbx = [double]$cb.x; $cby = [double]$cb.y; $cbw = [double]$cb.w; $cbh = [double]$cb.h
                    for ($ei = 0; $ei -lt $items.Count; $ei++) {
                        $ex = $items[$ei]
                        $ix = [Math]::Min($cbx + $cbw, [double]$ex.x + [double]$ex.w) - [Math]::Max($cbx, [double]$ex.x)
                        $iy = [Math]::Min($cby + $cbh, [double]$ex.y + [double]$ex.h) - [Math]::Max($cby, [double]$ex.y)
                        if ($ix -gt 0 -and $iy -gt 0) { $dupc = $true; break }
                    }
                    if (-not $dupc) { [void]$items.Add($cb); [void]$newCarry.Add($cw) }
                }
            }
            $script:BCarry = $newCarry
        } catch {
            $script:BCarry = $null
            $script:CarryErr = [int]$script:CarryErr + 1
            if ($script:CarryErr -le 5) { Write-Log ('carry: ' + $_.Exception.Message + ' | ' + [string]$_.ScriptStackTrace) }
        }
        $script:LastOcrAt = Get-Date
        if ($items.Count -eq 0) {
            # No Chinese on screen: tolerate one missed scan, then clear so stale labels never stay stuck.
            $script:EmptyScans++
            $script:Unconf = 0
            $goneAll = $false; try { $goneAll = Test-TracksChanged $bmp $rect 5 } catch {}
            if ($script:EmptyScans -ge 2 -or $goneAll) { $script:Tracks.Clear() }
            if ($script:EmptyScans -ge 2 -or $goneAll) { $script:LastBlocks = @(); $script:LastTextSig = $null; $script:Status = 'no Chinese text'; try { $script:Overlay.Invalidate() } catch {} }
            $script:LastHash = $script:PendingHash
            Update-Tray
            return
        }
        $script:EmptyScans = 0
        $script:LastMoved = Update-Tracks $items $bmp $rect
        $unconfirmed = @($script:Tracks | Where-Object { $_.seen -lt 2 }).Count
        $script:Unconf = $unconfirmed
        if ($script:LastMoved -gt 0 -or $unconfirmed -gt 0) { $script:MotionBoost = 4 } elseif ($script:MotionBoost -gt 0) { $script:MotionBoost-- }
        $minSeen = 2
        if ([int]$script:SceneChange -gt 0) { $minSeen = 1; $script:SceneChange = [int]$script:SceneChange - 1 }
        # start translating text on its FIRST sighting, so the translation is ready when the label is confirmed
        try {
            $pf = New-Object System.Collections.Generic.List[string]
            foreach ($tk in $script:Tracks) {
                if ($tk.seen -lt 2 -and $tk.text) {
                    $tt = ([string]$tk.text).Trim()
                    if (-not $script:Cache.ContainsKey($tt) -and -not $script:Pending.ContainsKey($tt)) { [void]$pf.Add($tt) }
                }
            }
            if ($pf.Count -gt 0) { [void](Translate-Batch $pf.ToArray()) }
        } catch { Write-Log "prefetch: $($_.Exception.Message)" }
        # text that is already known (dictionary / cache) is shown at once instead of after two sightings
        # subtitle-like text (centred, lower part of the picture, a real sentence) is also shown on first sighting
        $subCx = [double]$rect.X + [double]$rect.Width / 2.0
        $subTop = [double]$rect.Y + 0.55 * [double]$rect.Height
        $subHalf = 0.22 * [double]$rect.Width
        # ghost guard: text that is not one of the game's own strings has to be READ again (re-used readings do not count);
        # a reading that only the extra contrast passes found, or one with a little junk in it, needs three real readings
        # and never gets the show-at-once shortcuts (scene change, known text, subtitle position)
        $items = @($script:Tracks | Where-Object {
            $tx0 = [string]$_.text
            $official = Test-OfficialText $tx0
            $suspect = (-not $official) -and ([int]$_.nz -gt 0 -or -not [bool]$_.p1)
            if ($suspect) { ([int]$_.fresh -ge 3) -and ([int]$_.seen -ge 2) }
            else {
                ($official -or [int]$_.fresh -ge [Math]::Min(2, [int]$_.seen)) -and (
                $_.seen -ge $minSeen -or ($_.seen -ge 1 -and ((Test-KnownText $tx0) -or
                    ($tx0.Length -ge 4 -and ([Math]::Abs(([double]$_.x + [double]$_.w / 2.0) - $subCx) -lt $subHalf) -and (([double]$_.y + [double]$_.h / 2.0) -gt $subTop)))))
            }
        })
        # no doubles: two labels on top of each other (the same text read twice a few pixels apart, or a shorter / longer
        # reading of it), or the same text shown twice close together (an old copy left where a menu entry used to be):
        # the better-established one stays - read in this scan, the game's own text, read more often
        if ($items.Count -gt 1) {
            $sc = @{}
            for ($q = 0; $q -lt $items.Count; $q++) {
                $tq = $items[$q]; $v = [int]$tq.fresh + [int]$tq.seen
                if ([int]$tq.missed -eq 0) { $v += 60 }
                try { if (Test-OfficialText ([string]$tq.text)) { $v += 30 } } catch {}
                $sc[$q] = $v
            }
            $drop = @{}
            for ($q = 0; $q -lt $items.Count; $q++) {
                if ($drop.ContainsKey($q)) { continue }
                $a1 = $items[$q]
                for ($r = $q + 1; $r -lt $items.Count; $r++) {
                    if ($drop.ContainsKey($r)) { continue }
                    $b1 = $items[$r]
                    $ox = [Math]::Min([double]$a1.x + [double]$a1.w, [double]$b1.x + [double]$b1.w) - [Math]::Max([double]$a1.x, [double]$b1.x)
                    $oy = [Math]::Min([double]$a1.y + [double]$a1.h, [double]$b1.y + [double]$b1.h) - [Math]::Max([double]$a1.y, [double]$b1.y)
                    $minA = [Math]::Max(1.0, [Math]::Min([double]$a1.w * [double]$a1.h, [double]$b1.w * [double]$b1.h))
                    $dup = ($ox -gt 0 -and $oy -gt 0 -and ($ox * $oy) -ge 0.45 * $minA)
                    if (-not $dup -and ((Get-NormKey ([string]$a1.text)) -eq (Get-NormKey ([string]$b1.text)))) {
                        $dcx = [Math]::Abs(([double]$a1.x + [double]$a1.w / 2) - ([double]$b1.x + [double]$b1.w / 2)); $dcy = [Math]::Abs(([double]$a1.y + [double]$a1.h / 2) - ([double]$b1.y + [double]$b1.h / 2))
                        $hh = [Math]::Max([double]$a1.h, [double]$b1.h)
                        if (($dcy -lt 4 * $hh -and $dcx -lt 12 * $hh -and ([int]$a1.missed -gt 0 -or [int]$b1.missed -gt 0)) -or ($dcy -lt 2.4 * $hh -and $dcx -lt 8 * $hh)) { $dup = $true }
                    }
                    if (-not $dup -and ([bool]$a1.p1 -ne [bool]$b1.p1)) {
                        # one reading from the normal pass (right place, often garbled: "《跨平台匹配", "奖励)(") and one from an extra pass
                        # (clean words, place often off): the same words close together are one text - the normal reading keeps the place,
                        # the clean reading gives the words
                        $pP = $a1; $pQ = $b1; $pIdx = $q; if ([bool]$b1.p1) { $pP = $b1; $pQ = $a1; $pIdx = $r }
                        $hP = [regex]::Replace([string]$pP.text, '[^\u4e00-\u9fff]', ''); $hQ = [regex]::Replace([string]$pQ.text, '[^\u4e00-\u9fff]', '')
                        $junkP = ([string]$pP.text -match '[^\u4e00-\u9fff\s]')
                        if ($junkP -and $hP.Length -ge 2 -and $hQ.Length -ge $hP.Length -and ($hQ -eq $hP -or $hQ.EndsWith($hP) -or $hQ.StartsWith($hP))) {
                            $hh2 = [Math]::Max([double]$a1.h, [double]$b1.h)
                            $dx2 = [Math]::Abs(([double]$a1.x + [double]$a1.w / 2) - ([double]$b1.x + [double]$b1.w / 2)); $dy2 = [Math]::Abs(([double]$a1.y + [double]$a1.h / 2) - ([double]$b1.y + [double]$b1.h / 2))
                            if ($dy2 -lt 5 * $hh2 -and $dx2 -lt 14 * $hh2) {
                                $cl = $pP.psobject.Copy(); $cl.text = [string]$pQ.text
                                $items[$pIdx] = $cl
                                if ($pIdx -eq $q) { $a1 = $cl } else { $b1 = $cl }
                                $sc[$pIdx] = [int]$sc[$pIdx] + 1000
                                $dup = $true
                            }
                        }
                    }
                    if ($dup) { if ([int]$sc[$q] -ge [int]$sc[$r]) { $drop[$r] = $true } else { $drop[$q] = $true; break } }
                }
            }
            if ($drop.Count -gt 0) { $keep = New-Object System.Collections.Generic.List[object]; for ($q = 0; $q -lt $items.Count; $q++) { if (-not $drop.ContainsKey($q)) { [void]$keep.Add($items[$q]) } }; $items = @($keep.ToArray()) }
        }
        $sigParts = New-Object System.Collections.Generic.List[string]
        foreach ($it in $items) {
            if ($it -and $it.text) { [void]$sigParts.Add(([string]$it.text) + '@' + [int]$it.x + ',' + [int]$it.y + ',' + [int]$it.w + ',' + [int]$it.h) }
        }
        $sigArr = $sigParts.ToArray()
        [Array]::Sort($sigArr)
        $sig = [string]::Join('|', $sigArr)
        if ($sig -and ($sig -eq [string]$script:LastTextSig) -and $script:LastBlocks) {
            $script:Status = 'holding (same text)'
            $script:SameStreak = [Math]::Min(10, [int]$script:SameStreak + 1)
            try { Update-Glass $bmp $rect } catch {}
            $script:LastHash = $script:PendingHash
            Update-Tray
            return
        }
        $script:LastTextSig = $sig
        $script:SameStreak = 0
        $script:LastHash = $script:PendingHash

        # v2.2: a line joins a block only when it is a true wrapped continuation of a paragraph:
        # directly below, left-aligned, same text height, and the line above was (nearly) full width.
        # Short labels, stat rows, buttons and list entries therefore stay separate.
        $sorted = $items | Sort-Object y, x
        $blocks = New-Object System.Collections.Generic.List[object]
        foreach ($it in $sorted) {
            $target = $null
            if ($script:Settings.joinDescriptions) {
                for ($bi = $blocks.Count - 1; $bi -ge 0; $bi--) {
                    $b = $blocks[$bi]
                    if ($b.closed) { continue }
                    $lh = [double][Math]::Max(10, $b.lastH)
                    $gap = [double]$it.y - ([double]$b.lastY + [double]$b.lastH)
                    if ($gap -gt ($lh * 0.8)) { continue }                                  # too far below
                    if ($gap -lt -($lh * 0.3)) { continue }                                 # overlapping / same row
                    if ([Math]::Abs([double]$it.h - $lh) -gt ($lh * 0.35)) { continue }    # different text size
                    if ([Math]::Abs([double]$it.x - [double]$b.lastX) -gt [Math]::Max(8, $lh * 0.7)) { continue }  # not left-aligned
                    if ($b.lastText.Length -lt 9) { continue }                              # short line = label, not a wrapped paragraph
                    if ($b.lastText -match '[。！？!?…]$') { continue }   # sentence ended
                    if ([double]$b.lastW -lt (0.82 * [double]$b.maxW)) { continue }        # line above was not full width
                    if (([double]$it.w) -gt (1.15 * [double]$b.maxW) -and $b.lines -ge 1) { continue }
                    if (($b.text.Length + $it.text.Length) -ge [int]$script:Settings.maxBlockChars) { continue }
                    $target = $b; break
                }
            }
            if ($target) {
                $target.text = $target.text + "`n" + $it.text
                $nx = [Math]::Min([int]$target.x, [int]$it.x); $ny = [Math]::Min([int]$target.y, [int]$it.y)
                $nr = [Math]::Max([int]$target.x + [int]$target.w, [int]$it.x + [int]$it.w)
                $nb = [Math]::Max([int]$target.y + [int]$target.h, [int]$it.y + [int]$it.h)
                $target.x = $nx; $target.y = $ny; $target.w = $nr - $nx; $target.h = $nb - $ny; $target.lines++; [void]$target.emL.Add((Get-LineEm ([string]$it.text) $it.w $it.h))
                $target.lastX = $it.x; $target.lastY = $it.y; $target.lastW = $it.w; $target.lastH = $it.h; $target.lastText = $it.text
                if ([int]$it.w -gt [int]$target.maxW) { $target.maxW = $it.w }
            } else {
                $blocks.Add([pscustomobject]@{ p1 = [bool]$it.p1; text = $it.text; x = $it.x; y = $it.y; w = $it.w; h = $it.h; lines = 1; emL = (New-EmList $it); bgR = $it.bgR; bgG = $it.bgG; bgB = $it.bgB; lastX = $it.x; lastY = $it.y; lastW = $it.w; lastH = $it.h; lastText = $it.text; maxW = $it.w; closed = $false }) | Out-Null
            }
        }
        try { Merge-Ordinals $blocks } catch { Write-Log ('ordinal: ' + $_.Exception.Message) }
        $noticeKeys = @()
        try { $noticeKeys = @(Apply-Notices $blocks) } catch { Write-Log ('notice: ' + $_.Exception.Message) }
        # which menu is this? (decides a few words, see Fix-Canon); kept for a few seconds so a flickering reading does not flip a label
        try {
            $hanAll = [regex]::Replace((($blocks | ForEach-Object { [string]$_.text }) -join ' '), '[^\u4e00-\u9fff ]', '')
            $ctxNow = ''
            if ($hanAll -match '勇气积分|百川|保护卡设置|跨平台匹配') { $ctxNow = 'ranked' }
            elseif ($hanAll -match '娱乐|房间|排位赛') { $ctxNow = 'spar' }
            if ($ctxNow) { $script:CtxName = $ctxNow; $script:CtxAt = [int64]$script:Clk.ElapsedMilliseconds }
            elseif ($script:CtxName -and ([int64]$script:Clk.ElapsedMilliseconds - [int64]$script:CtxAt) -gt 8000) { $script:CtxName = '' }
        } catch {}
        $map = Translate-Batch @($blocks | ForEach-Object { $_.text } | Where-Object { -not ([string]$_).StartsWith('#NOTICE#') })
        foreach ($nk0 in $noticeKeys) { $map[$nk0] = $script:NoticeText[$nk0] }
        # the same words read two ways a little apart (garbled reading in the right place + clean extra-pass reading off to the side,
        # both translated to the same English) are one text: the garbled / normal-pass one stays where the text is
        try {
            if ($blocks.Count -gt 1) {
                $enB = New-Object 'string[]' $blocks.Count
                for ($qi = 0; $qi -lt $blocks.Count; $qi++) {
                    $tq0 = [string]$blocks[$qi].text
                    if ($tq0.StartsWith('#NOTICE#')) { continue }
                    try { $enB[$qi] = ([string]$map[$tq0]).Trim().ToLowerInvariant() } catch {}
                }
                $rmB = @{}
                for ($qi = 0; $qi -lt $blocks.Count; $qi++) {
                    if ($rmB.ContainsKey($qi) -or [string]::IsNullOrEmpty($enB[$qi]) -or $enB[$qi].Length -lt 5) { continue }
                    for ($ri = $qi + 1; $ri -lt $blocks.Count; $ri++) {
                        if ($rmB.ContainsKey($ri) -or $enB[$ri] -ne $enB[$qi]) { continue }
                        $a2 = $blocks[$qi]; $b2 = $blocks[$ri]
                        if ([int]$a2.lines -gt 1 -or [int]$b2.lines -gt 1 -or [string]$a2.text -eq [string]$b2.text) { continue }
                        $hh2 = [Math]::Max([double]$a2.h, [double]$b2.h)
                        $dx2 = [Math]::Abs(([double]$a2.x + [double]$a2.w / 2) - ([double]$b2.x + [double]$b2.w / 2)); $dy2 = [Math]::Abs(([double]$a2.y + [double]$a2.h / 2) - ([double]$b2.y + [double]$b2.h / 2))
                        if ($dy2 -ge 6 * $hh2 -or $dx2 -ge 16 * $hh2) { continue }
                        $ka = 0; $kb = 0
                        if ([bool]$a2.p1) { $ka += 2 }; if ([bool]$b2.p1) { $kb += 2 }
                        try { if (-not (Test-OfficialText ([string]$a2.text))) { $ka += 1 } } catch {}
                        try { if (-not (Test-OfficialText ([string]$b2.text))) { $kb += 1 } } catch {}
                        if ($ka -ge $kb) { $rmB[$ri] = $true } else { $rmB[$qi] = $true; break }
                    }
                }
                if ($rmB.Count -gt 0) {
                    $keepB = New-Object System.Collections.Generic.List[object]
                    for ($qi = 0; $qi -lt $blocks.Count; $qi++) { if (-not $rmB.ContainsKey($qi)) { [void]$keepB.Add($blocks[$qi]) } }
                    $blocks.Clear(); foreach ($kb0 in $keepB) { [void]$blocks.Add($kb0) }
                }
            }
        } catch { Write-Log ('dedupe-en: ' + $_.Exception.Message) }
        $script:Obst = @($blocks | ForEach-Object { @{ x = [int]$_.x; y = [int]$_.y; w = [int]$_.w; h = [int]$_.h } })
        $drawn = New-Object System.Collections.Generic.List[object]
        $sample = ''
        $nowMs = [int64]$script:Clk.ElapsedMilliseconds
        $swL = [System.Diagnostics.Stopwatch]::StartNew()
        foreach ($b in $blocks) {
            $en = Clean-Names ([string]$map[$b.text])
            if ([string]::IsNullOrWhiteSpace($en)) { $en = '' }
            if (-not $sample) { $sample = $en }
            $em = Get-MedianEm $b.emL
            $pad = [int][Math]::Max(2, [Math]::Round($em * 0.1))
            $nb1 = [pscustomobject]@{ en = $en; src = $b.text; x = $b.x; y = $b.y; w = $b.w; h = $b.h; lines = $b.lines; em = $em; pad = $pad; lx = 0; ly = 0; lw = 0; lh = 0; pt = 0.0; nw = $false; ext = $false; gT = 0; gSig = $null; iR = 0; iG = 0; iB = 0; iOk = $false; sig = [int]$blocks.Count; ax = 0; ay = 0; aw = 0; ah = 0; txt = ''; tx = 0; ty = 0; tw = 0; th = 0; ctr = $false; glass = $null; gR = [int]$b.bgR; gG = [int]$b.bgG; gB = [int]$b.bgB; gLum = -1; bgR = $b.bgR; bgG = $b.bgG; bgB = $b.bgB }
            if ($en) {
                # same text, same place, same size as last scan: reuse the layout (and the glass for a short while)
                $prev = $null; $shX = 0; $shY = 0
                $mk = [string]$b.text + '|' + $en
                # The old layout is compared with the spot where it was LAID OUT (its anchor), never with the previous scan:
                # otherwise a menu that creeps a few pixels per scan would never count as moved.
                $tolW = [Math]::Max(6, [int][Math]::Round(0.15 * [int]$b.w)); $tolH = [Math]::Max(3, [int][Math]::Round(0.12 * [int]$b.h))      # a box read a little wider / narrower keeps its layout
                $tolP = [Math]::Max(2, [int][Math]::Round(0.06 * [int]$b.h))                      # smaller than this: same spot, keep the box exactly
                $maxSh = [Math]::Max(60, 2 * [int]$b.h)                                           # a label that moved this far with the same text and size keeps its rows and just follows
                $cands = New-Object System.Collections.ArrayList
                foreach ($old0 in @($script:LastBlocks)) { if ($null -ne $old0) { $null = $cands.Add($old0) } }
                try {
                    $ml0 = $script:LayMemo[$mk]
                    if ($null -ne $ml0) {
                        for ($mi0 = 0; $mi0 -lt $ml0.Count; $mi0++) {
                            $sn0 = $ml0[$mi0]
                            if (($nowMs - [int64]$sn0.memoAt) -le 6000) { $null = $cands.Add($sn0) }
                        }
                    }
                } catch { Write-Log ('layout memo read: ' + $_.Exception.Message) }
                $bestD = 1000000
                foreach ($old in $cands) {
                    if ([int]$old.lw -le 0) { continue }
                    if ([string]$old.src -ne [string]$b.text) { continue }
                    if ([string]$old.en -ne $en) { continue }
                    if ([int]$old.lines -ne [int]$b.lines) { continue }
                    $oax = [int]$old.ax; $oay = [int]$old.ay; $oaw = [int]$old.aw; $oah = [int]$old.ah
                    if ($oaw -le 0) { continue }
                    if ([Math]::Abs($oaw - [int]$b.w) -gt $tolW -or [Math]::Abs($oah - [int]$b.h) -gt $tolH) { continue }
                    $ddx = [int]$b.x - $oax; $ddy = [int]$b.y - $oay
                    if ([Math]::Abs($ddx) -gt $maxSh -or [Math]::Abs($ddy) -gt $maxSh) { continue }
                    if ([Math]::Abs($ddx) -le $tolP -and [Math]::Abs($ddy) -le $tolP) { $ddx = 0; $ddy = 0 }
                    $dist = [Math]::Abs($ddx) + [Math]::Abs($ddy)
                    if ($dist -ge $bestD) { continue }
                    # the old box (moved along) is only kept when nothing else that was scanned now sits inside it
                    $intr = $false
                    $lx0 = [int]$old.lx + $ddx - 1; $ly0 = [int]$old.ly + $ddy - 1; $lx1 = [int]$old.lx + $ddx + [int]$old.lw + 1; $ly1 = [int]$old.ly + $ddy + [int]$old.lh + 1
                    $cvx = [Math]::Min($lx1 - 1, [int]$b.x + [int]$b.w) - [Math]::Max($lx0 + 1, [int]$b.x); $cvy = [Math]::Min($ly1 - 1, [int]$b.y + [int]$b.h) - [Math]::Max($ly0 + 1, [int]$b.y)
                    if ($cvx -le 0 -or $cvy -le 0 -or ($cvx * $cvy) -lt (0.45 * [double]([int]$b.w * [int]$b.h))) { continue }      # a remembered box that would sit beside its text, not on it
                    foreach ($ob in $blocks) {
                        if ([object]::ReferenceEquals($ob, $b)) { continue }
                        $ox1 = [Math]::Min($lx1, [int]$ob.x + [int]$ob.w) - [Math]::Max($lx0, [int]$ob.x); $oy1 = [Math]::Min($ly1, [int]$ob.y + [int]$ob.h) - [Math]::Max($ly0, [int]$ob.y)
                        if ($ox1 -gt 0 -and $oy1 -gt 0) { $intr = $true; break }
                    }
                    if (-not $intr) {
                        foreach ($symo in @($script:Sym)) {
                            if ($null -eq $symo) { continue }
                            $sx1 = [Math]::Min($lx1, [int]$symo.x + [int]$symo.w) - [Math]::Max($lx0, [int]$symo.x); $sy1 = [Math]::Min($ly1, [int]$symo.y + [int]$symo.h) - [Math]::Max($ly0, [int]$symo.y)
                            if ($sx1 -le 0 -or $sy1 -le 0) { continue }
                            $sa0 = [double]([int]$symo.w * [int]$symo.h)
                            $bx1 = [Math]::Min([int]$b.x + [int]$b.w, [int]$symo.x + [int]$symo.w) - [Math]::Max([int]$b.x, [int]$symo.x); $by1 = [Math]::Min([int]$b.y + [int]$b.h, [int]$symo.y + [int]$symo.h) - [Math]::Max([int]$b.y, [int]$symo.y)
                            if ($bx1 -gt 0 -and $by1 -gt 0 -and (($bx1 * $by1) -gt (0.5 * $sa0))) { continue }      # part of this label
                            $intr = $true; break
                        }
                    }
                    if ($intr) { continue }
                    $prev = $old; $shX = $ddx; $shY = $ddy; $bestD = $dist
                    if ($dist -eq 0) { break }
                }
                try {
                    if ($prev) {
                        $nb1.pad = $prev.pad; $nb1.em = $prev.em
                        $nb1.gSig = $prev.gSig; $nb1.iR = $prev.iR; $nb1.iG = $prev.iG; $nb1.iB = $prev.iB; $nb1.iOk = $prev.iOk
                        $nb1.lx = [int]$prev.lx + $shX; $nb1.ly = [int]$prev.ly + $shY; $nb1.lw = $prev.lw; $nb1.lh = $prev.lh; $nb1.pt = $prev.pt; $nb1.nw = $prev.nw; $nb1.ext = $prev.ext; $nb1.txt = $prev.txt
                        $nb1.tx = [int]$prev.tx + $shX; $nb1.ty = [int]$prev.ty + $shY; $nb1.tw = $prev.tw; $nb1.th = $prev.th; $nb1.ctr = $prev.ctr
                        if ($shX -ne 0 -or $shY -ne 0) {
                            # the menu moved: the same box follows it (same rows), new anchor
                            $vsA = [System.Windows.Forms.SystemInformation]::VirtualScreen
                            if ($nb1.lx + $nb1.lw -gt $vsA.Right) { $nb1.lx = $vsA.Right - $nb1.lw }
                            if ($nb1.lx -lt $vsA.Left) { $nb1.lx = $vsA.Left }
                            if ($nb1.ly + $nb1.lh -gt $vsA.Bottom) { $nb1.ly = $vsA.Bottom - $nb1.lh }
                            if ($nb1.ly -lt $vsA.Top) { $nb1.ly = $vsA.Top }
                            $nb1.ax = [int]$b.x; $nb1.ay = [int]$b.y; $nb1.aw = [int]$b.w; $nb1.ah = [int]$b.h
                            Build-Glass $nb1 $bmp $rect
                        } else {
                        $nb1.ax = $prev.ax; $nb1.ay = $prev.ay; $nb1.aw = $prev.aw; $nb1.ah = $prev.ah
                        if ($prev.glass -and (($nowMs - [int64]$prev.gT) -lt 450)) {
                            $nb1.glass = $prev.glass; $prev.glass = $null; $nb1.gT = $prev.gT
                            $nb1.gR = $prev.gR; $nb1.gG = $prev.gG; $nb1.gB = $prev.gB; $nb1.gLum = $prev.gLum
                        } else { Build-Glass $nb1 $bmp $rect }
                        }
                        $script:Perf.reuse = [int]$script:Perf.reuse + 1
                    } else {
                        Layout-Block $nb1 $bmp $rect
                        $nb1.ax = [int]$b.x; $nb1.ay = [int]$b.y; $nb1.aw = [int]$b.w; $nb1.ah = [int]$b.h
                        $script:Perf.fresh = [int]$script:Perf.fresh + 1
                    }
                } catch { Write-Log "layout: $($_.Exception.Message)" }
            }
            if ($en -and [int]$nb1.lw -gt 0) {
                # the label has to cover the text it translates. One that sits beside it (the recording showed "Cancel" 75 px
                # above its button, "Martial Tournament" 100 px below its title) is laid out again, and if that is still
                # not on the text it is put there
                try {
                    $bArea = [double][Math]::Max(1, [int]$b.w * [int]$b.h)
                    $covF = { param($n0) $ox0 = [Math]::Min([double]$n0.lx + [double]$n0.lw, [double]$b.x + [double]$b.w) - [Math]::Max([double]$n0.lx, [double]$b.x); $oy0 = [Math]::Min([double]$n0.ly + [double]$n0.lh, [double]$b.y + [double]$b.h) - [Math]::Max([double]$n0.ly, [double]$b.y); if ($ox0 -gt 0 -and $oy0 -gt 0) { return ($ox0 * $oy0 / $bArea) } else { return 0.0 } }
                    $cv0 = [double](& $covF $nb1)
                    if ($cv0 -lt 0.45) {
                        $nb1.ax = [int]$b.x; $nb1.ay = [int]$b.y; $nb1.aw = [int]$b.w; $nb1.ah = [int]$b.h
                        Layout-Block $nb1 $bmp $rect
                        $cv0 = [double](& $covF $nb1)
                        if ($cv0 -lt 0.45) {
                            $vsC = [System.Windows.Forms.SystemInformation]::VirtualScreen
                            $nx = [int]$b.x; if ($nx + [int]$nb1.lw -gt $vsC.Right) { $nx = $vsC.Right - [int]$nb1.lw }; if ($nx -lt $vsC.Left) { $nx = $vsC.Left }
                            $ny = [int]([double]$b.y + [double]$b.h / 2.0 - [double]$nb1.lh / 2.0); if ($ny + [int]$nb1.lh -gt $vsC.Bottom) { $ny = $vsC.Bottom - [int]$nb1.lh }; if ($ny -lt $vsC.Top) { $ny = $vsC.Top }
                            $nb1.lx = $nx; $nb1.ly = $ny; $nb1.tx = [int]$b.x; $nb1.ty = [int]$b.y; $nb1.tw = [int]$b.w; $nb1.th = [int]$b.h
                            try { Build-Glass $nb1 $bmp $rect } catch {}
                        }
                        $script:Perf.snap = [int]$script:Perf.snap + 1
                    }
                } catch { Write-Log ('cover check: ' + $_.Exception.Message) }
            }
            $drawn.Add($nb1) | Out-Null
            if ($en -and [int]$nb1.lw -gt 0) {
                try {
                    $mk2 = [string]$b.text + '|' + $en
                    $ml = $script:LayMemo[$mk2]
                    if ($null -eq $ml) { $ml = New-Object System.Collections.ArrayList; $script:LayMemo[$mk2] = $ml }
                    for ($mi = $ml.Count - 1; $mi -ge 0; $mi--) {
                        $m0 = $ml[$mi]
                        if (($nowMs - [int64]$m0.memoAt) -gt 6000 -or ([Math]::Abs([int]$m0.ax - [int]$nb1.ax) -le 8 -and [Math]::Abs([int]$m0.ay - [int]$nb1.ay) -le 8)) { $ml.RemoveAt($mi) }
                    }
                    $snap = [pscustomobject]@{ en = $nb1.en; src = $nb1.src; x = $nb1.x; y = $nb1.y; w = $nb1.w; h = $nb1.h; lines = $nb1.lines; em = $nb1.em; pad = $nb1.pad; lx = $nb1.lx; ly = $nb1.ly; lw = $nb1.lw; lh = $nb1.lh; pt = $nb1.pt; nw = $nb1.nw; ext = $nb1.ext; txt = $nb1.txt; tx = $nb1.tx; ty = $nb1.ty; tw = $nb1.tw; th = $nb1.th; ctr = $nb1.ctr; gSig = $nb1.gSig; ax = $nb1.ax; ay = $nb1.ay; aw = $nb1.aw; ah = $nb1.ah; iR = $nb1.iR; iG = $nb1.iG; iB = $nb1.iB; iOk = $nb1.iOk; glass = $null; gT = 0; memoAt = [int64]$nowMs }
                    $null = $ml.Add($snap)
                    while ($ml.Count -gt 4) { $ml.RemoveAt(0) }
                } catch { Write-Log ('layout memo store: ' + $_.Exception.Message) }
            }
        }
        if ($script:LayMemo.Count -gt 300) { $script:LayMemo = New-Object System.Collections.Hashtable ([StringComparer]::Ordinal) }
        if (([int]$script:ScanN % 40) -eq 0) { Write-Log ('perf: ocr=' + $script:OcrMsA + 'ms items=' + $items.Count + ' layout=' + $swL.ElapsedMilliseconds + 'ms reused=' + $script:Perf.reuse + ' fresh=' + $script:Perf.fresh + ' snapped=' + $script:Perf.snap + ' shifted=' + $script:Perf.shift + ' glyph=' + $script:Perf.glyph + ' iconcut=' + $script:Perf.icon) }
        # repaint only what changed (a full-screen repaint on every scan makes streaming / recording software see the overlay stutter)
        $dirty = New-Object System.Collections.Generic.List[System.Drawing.Rectangle]
        $fullInv = [bool]$script:Settings.debug
        if (-not $fullInv) {
            try {
                $oldL = @(@($script:LastBlocks) | Where-Object { $_ -and [int]$_.lw -gt 0 })
                $newL = @(@($drawn.ToArray()) | Where-Object { $_ -and [int]$_.lw -gt 0 })
                $usedO = New-Object 'System.Collections.Generic.HashSet[int]'
                foreach ($nbk in $newL) {
                    $hitI = -1
                    for ($oi = 0; $oi -lt $oldL.Count; $oi++) {
                        if ($usedO.Contains($oi)) { continue }
                        $obk = $oldL[$oi]
                        if ([int]$obk.lx -ne [int]$nbk.lx -or [int]$obk.ly -ne [int]$nbk.ly -or [int]$obk.lw -ne [int]$nbk.lw -or [int]$obk.lh -ne [int]$nbk.lh) { continue }
                        if ([string]$obk.txt -ne [string]$nbk.txt -or [double]$obk.pt -ne [double]$nbk.pt -or [bool]$obk.ctr -ne [bool]$nbk.ctr -or [bool]$obk.ext -ne [bool]$nbk.ext) { continue }
                        $hitI = $oi; break
                    }
                    $chg = $true
                    if ($hitI -ge 0) {
                        [void]$usedO.Add($hitI)
                        $obk = $oldL[$hitI]
                        if ($null -eq $obk.glass) { $chg = $false }                       # glass was carried over (or none): same picture
                        elseif ($nbk.glass) {
                            $sa = [StarGlass2]::Sig($obk.glass, 0, 0, [int]$obk.lw, [int]$obk.lh)
                            $sb2 = [StarGlass2]::Sig($nbk.glass, 0, 0, [int]$nbk.lw, [int]$nbk.lh)
                            if (-not [StarGlass2]::Differs($sa, $sb2, 1)) { $chg = $false }
                        }
                    }
                    if ($chg) { [void]$dirty.Add((New-Object System.Drawing.Rectangle ([int]$nbk.lx - $script:Overlay.Left - 2), ([int]$nbk.ly - $script:Overlay.Top - 2), ([int]$nbk.lw + 6), ([int]$nbk.lh + 6))) }
                }
                for ($oi = 0; $oi -lt $oldL.Count; $oi++) {
                    if ($usedO.Contains($oi)) { continue }
                    $obk = $oldL[$oi]
                    [void]$dirty.Add((New-Object System.Drawing.Rectangle ([int]$obk.lx - $script:Overlay.Left - 2), ([int]$obk.ly - $script:Overlay.Top - 2), ([int]$obk.lw + 6), ([int]$obk.lh + 6)))
                }
            } catch { $fullInv = $true }
        }
        foreach ($ob0 in @($script:LastBlocks)) { if ($ob0 -and $ob0.glass) { try { $ob0.glass.Dispose() } catch {} } }
        $script:LastBlocks = @($drawn.ToArray())
        $script:ShownAt = Get-Date
        if ($sample.Length -gt 40) { $sample = $sample.Substring(0, 40) }
        $script:Sample = $sample
        $script:Status = "$($drawn.Count) block(s)"
        try {
            if ($fullInv -or $dirty.Count -gt 40) { $script:Overlay.Invalidate() }
            else { foreach ($dr in $dirty) { $script:Overlay.Invalidate($dr) } }
        } catch { Write-Log "render: $_" }
        Update-Tray
    } catch {
        $script:Status = 'scan error: ' + $_.Exception.Message
        if ($script:Status.Length -gt 90) { $script:Status = $script:Status.Substring(0, 90) }
        Write-Log ("scan: " + $_.Exception.Message + " @ " + $_.InvocationInfo.ScriptLineNumber)
        $script:ScanErrN = [int]$script:ScanErrN + 1
        if ($script:ScanErrN -le 6) { Write-Log ('scan detail: ' + [string]$_.ScriptStackTrace + ' | ' + [string]$_.InvocationInfo.Line.Trim()) }
        Update-Tray
    } finally {
        if ($small) { $small.Dispose() }
        if ($bmp) {
            if ($gotFrame) { $oldF = $script:FrameBmp; $script:FrameBmp = $bmp; $script:FrameRect = $rect; if ($oldF) { try { $oldF.Dispose() } catch {} } }
            else { $bmp.Dispose() }
        }
        $script:LastScanMs = $sw.ElapsedMilliseconds
        $script:Scanning = $false
    }
}

function Install-OcrPacks {
    $cmd = @'
$ErrorActionPreference = "Continue"
$caps = @("Language.OCR~~~zh-CN~0.0.1.0","Language.OCR~~~zh-TW~0.0.1.0","Language.OCR~~~zh-HK~0.0.1.0")
foreach ($c in $caps) {
  Write-Host $c
  $cur = Get-WindowsCapability -Online -Name $c -ErrorAction SilentlyContinue
  if ($cur -and $cur.State -eq "Installed") { Write-Host "  already installed"; continue }
  Write-Host "  installing (this downloads from Windows Update)..."
  Add-WindowsCapability -Online -Name $c
}
Write-Host "Done. Close this window, then right-click the Starfire Lite tray icon."
Read-Host "Press Enter"
'@
    $tmp = Join-Path $env:TEMP 'starfire-ocr.ps1'
    Set-Content $tmp $cmd -Encoding UTF8
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$tmp`""
}
function Start-RegionSelect {
    $sel = New-Object System.Windows.Forms.Form
    $sel.FormBorderStyle = 'None'
    $v = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $sel.Bounds = New-Object System.Drawing.Rectangle $v.X, $v.Y, $v.Width, $v.Height
    $sel.BackColor = [System.Drawing.Color]::Black
    $sel.Opacity = 0.3
    $sel.TopMost = $true
    $sel.Cursor = 'Cross'
    $sel.KeyPreview = $true
    $script:DragStart = $null
    $script:DragRect = $null
    $sel.Add_MouseDown({ param($s,$e) $script:DragStart = $e.Location })
    $sel.Add_MouseMove({
        param($s,$e)
        if ($script:DragStart) {
            $x = [Math]::Min($script:DragStart.X, $e.X); $y = [Math]::Min($script:DragStart.Y, $e.Y)
            $script:DragRect = New-Object System.Drawing.Rectangle ($s.Left+$x), ($s.Top+$y), ([Math]::Abs($e.X-$script:DragStart.X)), ([Math]::Abs($e.Y-$script:DragStart.Y))
            $s.Invalidate()
        }
    })
    $sel.Add_Paint({
        param($s,$e)
        if ($script:DragRect) {
            $local = New-Object System.Drawing.Rectangle ($script:DragRect.X-$s.Left), ($script:DragRect.Y-$s.Top), $script:DragRect.Width, $script:DragRect.Height
            $e.Graphics.DrawRectangle([System.Drawing.Pens]::Orange, $local)
        }
        $f = New-Object System.Drawing.Font 'Segoe UI', ([single]14)
        $e.Graphics.DrawString('Drag over the area to translate. Esc cancels.', $f, [System.Drawing.Brushes]::White, 30, 30)
        $f.Dispose()
    })
    $sel.Add_MouseUp({
        param($s,$e)
        if ($script:DragRect -and $script:DragRect.Width -gt 20) {
            $script:Settings.region = @{ x = $script:DragRect.X; y = $script:DragRect.Y; w = $script:DragRect.Width; h = $script:DragRect.Height }
            Set-Target 'region'
        }
        $s.Close()
    })
    $sel.Add_KeyDown({ param($s,$e) if ($e.KeyCode -eq 'Escape') { $s.Close() } })
    [void]$sel.ShowDialog()
}
$script:Quitting = $false
function Cleanup-And-Exit {
    $script:Quitting = $true                       # a deliberate quit: the message loop below must not restart, the watchdog must not relaunch
    try { [System.IO.File]::WriteAllText((Join-Path $script:DataDir 'quit.flag'), '1') } catch {}
    try { Save-Cache } catch {}
    try { $script:Overlay.Hide() } catch {}
    try { $script:KeyTimer.Stop() } catch {}
    try { [HSKeys]::Stop() } catch {}
    $script:Tray.Visible = $false
    $script:Tray.Dispose()
    [System.Windows.Forms.Application]::Exit()
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
    try {
        if (([int64]$script:Clk.ElapsedMilliseconds - [int64]$script:TopAt) -gt 3000) { $script:TopAt = [int64]$script:Clk.ElapsedMilliseconds; [HSNative]::SetWindowPos($script:Overlay.Handle, [IntPtr](-1), 0, 0, 0, 0, 0x13) | Out-Null }
    } catch {}
    if ($script:Settings.enabled) { Invoke-Scan }
    try {
        if ([int]$script:SceneChange -gt 0) { $timer.Interval = 200 }
        elseif ([int]$script:Unconf -gt 0) { $timer.Interval = 150 }
        elseif ($script:Pruning) { $timer.Interval = 250 }
        elseif ($script:MotionBoost -gt 0) { if ($script:WgcOn -or $script:ExcludeOk -or $script:PwMode -eq 'on') { $timer.Interval = 140 } else { $timer.Interval = 300 } }      # things are moving: look often (no flicker cost with window capture)
        else {
            $ivl = [int](500 + 50 * [Math]::Min(10, [int]$script:SameStreak))
            if ($script:ExcludeOk -or $script:PwMode -eq 'on' -or $script:WgcOn) {
                if ([int]$script:SameStreak -lt 4) { $ivl = [Math]::Min($ivl, 130) } else { $ivl = [Math]::Min($ivl, 320) }      # quick while things change, calmer once the screen is still
            }      # no flicker cost: keep checking often so changes show up fast
            $timer.Interval = $ivl
        }
    } catch {}
})
$timer.Start()

$gameTimer = New-Object System.Windows.Forms.Timer
$gameTimer.Interval = 1000
$gameTimer.Add_Tick({ try { Update-GameState } catch { Write-Log "game: $_" } })
$gameTimer.Start()
try { Update-GameState } catch {}

Start-SelfTest
$poll = New-Object System.Windows.Forms.Timer
$poll.Interval = 30
$poll.Add_Tick({ try { Poll-Translations } catch { Write-Log "poll: $_" }; if ($script:Notice -and (Get-Date) -ge $script:NoticeUntil) { $script:Notice = ""; try { $script:Overlay.Invalidate() } catch {} } })
$poll.Start()

$script:GlassTimer = New-Object System.Windows.Forms.Timer
$script:GlassTimer.Interval = 120
$script:GlassTimer.Add_Tick({ try { Refresh-GlassLive } catch { Write-Log ('glass tick: ' + $_.Exception.Message) } })
$script:GlassTimer.Start()

$script:MemOk = $false
try {
    Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices; using System.Diagnostics;
public static class StarMem {
    [DllImport("kernel32.dll")] static extern bool SetProcessWorkingSetSize(IntPtr h, IntPtr min, IntPtr max);
    public static void Trim() { SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, (IntPtr)(-1), (IntPtr)(-1)); }
}
'@
    $script:MemOk = $true
} catch { Write-Log ('memory trim unavailable: ' + $_.Exception.Message) }
function Trim-Memory {
    # while nothing is being scanned: collect garbage (compacting the large-object heap), forget stale bookkeeping, give unused pages back
    if ($script:Scanning) { return }
    if ($script:LastOcrAt -and (((Get-Date) - $script:LastOcrAt).TotalSeconds -lt 2.5)) { return }
    try {
        foreach ($fk2 in @($script:FailedAt.Keys)) { if (((Get-Date) - $script:FailedAt[$fk2]).TotalSeconds -gt 90) { $script:FailedAt.Remove($fk2) } }
        if ($script:FitMemo.Count -gt 600) { $script:FitMemo = @{} }
        $script:TrimN = 1 + [int]$script:TrimN
        $m0 = 0; try { $m0 = [int]([System.Diagnostics.Process]::GetCurrentProcess().WorkingSet64 / 1MB) } catch {}
        if ([int]$script:TrimN -le 3) { Write-Log ('trim: start, working set ' + $m0 + ' MB') }
        [System.Runtime.GCSettings]::LargeObjectHeapCompactionMode = [System.Runtime.GCLargeObjectHeapCompactionMode]::CompactOnce
        [System.GC]::Collect()          # no WaitForPendingFinalizers: finalizers of COM objects can need this (UI) thread, which would deadlock it
        if ($script:MemOk) { [StarMem]::Trim() }
        if ([int]$script:TrimN -le 3) { $m1 = 0; try { $m1 = [int]([System.Diagnostics.Process]::GetCurrentProcess().WorkingSet64 / 1MB) } catch {}; Write-Log ('trim: done, working set ' + $m1 + ' MB') }
    } catch {}
}
$script:MemTimer = New-Object System.Windows.Forms.Timer
$script:MemTimer.Interval = 60000
$script:MemTimer.Add_Tick({ try { Trim-Memory } catch {} })
$script:MemTimer.Start()

$flush = New-Object System.Windows.Forms.Timer
$flush.Interval = 20000
$flush.Add_Tick({ if ($script:CacheDirty -gt 0) { Save-Cache } })
$flush.Start()

$script:HbPath = Join-Path $script:DataDir 'heartbeat.txt'
$script:WatchdogSrc = @'
param([int]$MainPid)
# Starfire Lite watchdog: relaunches the program if it disappears or stops responding, unless it was quit on purpose (quit.flag).
# (it lives in Starfire Lite's own data folder - normal or test - and uses that folder; it used to look in Project Starfire's)
$data = $PSScriptRoot
$flag = Join-Path $data 'quit.flag'; $hb = Join-Path $data 'heartbeat.txt'; $cfg = Join-Path $data 'watchdog.cfg'; $log = Join-Path $data 'starfire.log'; $cnt = Join-Path $data 'watchdog.cnt'
function WL([string]$m) { try { Add-Content -Path $log -Value ('{0:yyyy-MM-dd HH:mm:ss}  watchdog: {1}' -f (Get-Date), $m) -Encoding UTF8 } catch {} }
$last = Get-Date
Start-Sleep -Seconds 20
while ($true) {
    Start-Sleep -Seconds 3
    $now = Get-Date
    $slept = ($now - $last).TotalSeconds; $last = $now
    if (Test-Path $flag) { break }
    $alive = $false
    try { $pr = Get-Process -Id $MainPid -ErrorAction Stop; $alive = (-not $pr.HasExited) } catch { $alive = $false }
    $why = $null
    if ($alive) {
        if ($slept -gt 20) { continue }
        $age = 0
        try { $age = ($now.ToUniversalTime() - (Get-Item $hb -ErrorAction Stop).LastWriteTimeUtc).TotalSeconds } catch { $age = 0 }
        if ($age -gt 60) { $why = 'not responding'; try { Stop-Process -Id $MainPid -Force -ErrorAction Stop } catch {} }
    } else { $why = 'gone' }
    if (-not $why) { continue }
    Start-Sleep -Seconds 2
    if (Test-Path $flag) { break }
    $others = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*StarfireLite.ps1*' })
    if ($others.Count -gt 0) { WL 'another copy is running, stopping'; break }
    $times = @()
    try { $times = @(Get-Content $cnt -ErrorAction Stop | ForEach-Object { [int64]$_ } | Where-Object { $_ -gt ($now.Ticks - 6000000000) }) } catch { $times = @() }
    if ($times.Count -ge 30) { WL 'restarted 30 times in 10 minutes, giving up'; break }
    $times += $now.Ticks
    try { Set-Content -Path $cnt -Value $times } catch {}
    $script = ''
    try { $script = (Get-Content $cfg -TotalCount 1 -ErrorAction Stop) } catch {}
    if (-not $script -or -not (Test-Path $script)) { WL 'program path unknown'; break }
    WL ('program ' + $why + ' - restarting')
    Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $script + '" --elevated')
    break
}
'@
function Start-Watchdog {
    try {
        $wd = Join-Path $script:DataDir 'StarfireLiteWD.ps1'
        [System.IO.File]::WriteAllText($wd, $script:WatchdogSrc, (New-Object System.Text.UTF8Encoding($true)))
        [System.IO.File]::WriteAllText((Join-Path $script:DataDir 'watchdog.cfg'), [string]$PSCommandPath)
        Remove-Item -Path (Join-Path $script:DataDir 'quit.flag') -ErrorAction SilentlyContinue
        try { [System.IO.File]::WriteAllText($script:HbPath, [string][DateTime]::UtcNow.Ticks) } catch {}
        foreach ($w in @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*StarfireLiteWD*' })) { try { Stop-Process -Id $w.ProcessId -Force -ErrorAction Stop } catch {} }
        Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $wd + '" ' + [string]$PID)
        Write-Log 'watchdog started'
    } catch { Write-Log ('watchdog: ' + $_.Exception.Message) }
}
$script:HbTimer = New-Object System.Windows.Forms.Timer
$script:HbTimer.Interval = 5000
$script:HbTimer.Add_Tick({ try { [System.IO.File]::WriteAllText($script:HbPath, [string][DateTime]::UtcNow.Ticks) } catch {} })
$script:HbTimer.Start()

# ---------- automatic updates while the overlay runs on its own ----------
# The Starfire launcher leaves a note next to this script (launcher.txt: mini loader path, launcher version, update source).
# Shortly after start and then every 2 hours the overlay looks for a newer Starfire; if there is one it starts the mini
# loader, which installs the update (launcher, mini loader and overlay) and starts the new overlay - and the new overlay
# closes this one. Done once per run; nothing happens when there is no note, no internet or no update.
$script:UpdNote = Join-Path $PSScriptRoot 'launcher.txt'
$script:SelfUpdTask = $null; $script:SelfUpdDone = $false; $script:SelfUpdInfo = $null
$script:SelfUpdTimer = New-Object System.Windows.Forms.Timer
$script:SelfUpdTimer.Interval = 45000
$script:SelfUpdTimer.Add_Tick({
    try {
        if ($script:SelfUpdDone) { $this.Stop(); return }
        if ($null -eq $script:SelfUpdTask) {
            $this.Interval = 7200000
            if (-not (Test-Path $script:UpdNote)) { return }
            $ln = @(Get-Content $script:UpdNote -Encoding UTF8 -ErrorAction Stop)
            if ($ln.Count -lt 3) { return }
            $script:SelfUpdInfo = [pscustomobject]@{ mini = [string]$ln[0]; ver = [string]$ln[1]; repo = [string]$ln[2] }
            if (-not (Test-Path $script:SelfUpdInfo.mini) -or $script:SelfUpdInfo.repo -notmatch '^[\w\-]+/[\w\-\.]+$') { return }
            $wc = New-Object System.Net.WebClient
            $wc.Headers.Add('User-Agent', 'Starfire-Overlay')
            $script:SelfUpdTask = $wc.DownloadStringTaskAsync('https://raw.githubusercontent.com/' + $script:SelfUpdInfo.repo + '/main/updates/latest.json?t=' + [DateTime]::UtcNow.Ticks)
            $this.Interval = 1000                                   # look again in a second for the answer
            return
        }
        if (-not $script:SelfUpdTask.IsCompleted) { return }
        $t = $script:SelfUpdTask; $script:SelfUpdTask = $null; $this.Interval = 7200000
        if ($t.Status -ne 'RanToCompletion') { return }
        $man = [string]$t.Result | ConvertFrom-Json
        $vN = $null; $vC = $null
        try { $vN = [version](([string]$man.version) -replace '[^\d\.]', ''); $vC = [version](($script:SelfUpdInfo.ver) -replace '[^\d\.]', '') } catch { return }
        if ($vN -and $vC -and $vN -gt $vC) {
            $script:SelfUpdDone = $true; $this.Stop()
            Write-Log ('update found: ' + $vC + ' -> ' + $vN + ' - starting the mini loader')
            Show-Notice ('Starfire update ' + $vN + ' - installing ...')
            Start-Process -FilePath $script:SelfUpdInfo.mini -WorkingDirectory (Split-Path $script:SelfUpdInfo.mini -Parent)
        }
    } catch { Write-Log ('update check: ' + $_.Exception.Message) }
})
$script:SelfUpdTimer.Start()
try { [AppDomain]::CurrentDomain.add_UnhandledException({ param($sender, $ea) try { Write-Log ('FATAL: ' + [string]$ea.ExceptionObject) } catch {} }) } catch {}
Start-Watchdog

Write-Log 'message loop'
try { Show-Notice ('Starfire Lite ' + $script:AppVersion + ' is running - F8 overlay on/off') } catch {}
while (-not $script:Quitting) {
    try { [System.Windows.Forms.Application]::Run() } catch { Write-Log ('message loop error (continuing): ' + $_.Exception.Message) }
    if (-not $script:Quitting) { Write-Log 'message loop ended unexpectedly - restarting it'; Start-Sleep -Milliseconds 300 }
}
