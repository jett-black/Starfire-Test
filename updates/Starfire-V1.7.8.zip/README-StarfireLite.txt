STARFIRE LITE 2.9.4
Chinese -> English overlay for The Hidden Ones. Same engine as Project Starfire 1.6.21. Every label is looked up in
the built-in game dictionaries first; only text that is not in them is sent to the online translators.

START
  Double-click "Starfire Lite.exe": a setup window opens (Install / Update / Reinstall, OCR pack, shortcuts) and installs
  to %LOCALAPPDATA%\StarfireLite\app. Afterwards start it from the desktop or Start menu shortcut, or
  double-click "Starfire Lite.cmd" to run it straight from this folder.
  Hotkeys in game: F8 overlay on / off, Ctrl+Shift+Q quit.

WHAT IT KNOWS
  * About 1,400 built-in game terms (the same as Project Starfire), plus
  * starfire-lite-dict.tsv: 3,380 further menu labels, buttons, item, skill, place and character names taken from the
    game's own string table (I18NTranslation_CN.bytes) and translated to English. These are the short labels
    (2-4 characters) that make up most of the menus.
  * On first start it copies the translations Project Starfire has already fetched (translation-cache.json) and your
    glossary.csv, so everything you have seen before works offline too.
  * Text that is in none of these (chat, story dialogue, long descriptions, event text) is translated online as a
    backup: Microsoft -> Google -> Google (2nd address) -> Lingva (2 servers) -> MyMemory, the same chain as Project
    Starfire. Each online translation is saved, so a phrase is only requested once and works offline afterwards.
    Without internet, such text simply gets no label.
  * Short unknown phrases are also listed in %LOCALAPPDATA%\StarfireLite\unknown-short.txt. Add them to glossary.csv
    (cn,en) in that folder and restart Lite to fix a translation for good.

NOTES
  * Lite and Project Starfire are separate programs with separate settings (%LOCALAPPDATA%\StarfireLite).
    Run only one of them at a time, or you get two overlays.
  * Lite does not change the game or any game file.
  * Everything else (window capture without flicker, glass labels, layout, watchdog) works as in Project Starfire 1.6.19.

WHAT'S NEW IN 1.1
  * Online translators as backup for everything not in the game dictionaries (1.0 left such text without a label).

WHAT'S NEW IN 1.2
  * Labels on sparkling / glowing buttons (Duel) no longer blink off for a second. A label that has been read 6 or more times
    in a row now survives up to 4-5 scans in which the OCR misses its text (the glitter on the gold Duel button makes it
    miss a few scans in a row). A real screen change still removes labels at once, and new text in the same spot still
    replaces the label directly.

WHAT'S NEW IN 1.3
  * Established labels (read 6+ times in a row) now survive one more missed scan: up to 5-6 instead of 4-5.

WHAT'S NEW IN 1.4
  * A label counts as established (and survives 5-6 missed scans) after 4 readings in a row instead of 6, so labels on
    sparkling buttons such as Duel lock in sooner.

WHAT'S NEW IN 1.5
  * Calmer labels on panels over moving pictures (the main-menu cards: Beginner's Journey with the driving car, the
    rotating event banner, Daily Quests):
    - the moving picture made every slightly different reading count as "new text" at once, so the label kept changing,
      re-sizing and moving. Now a clearer change is needed, and the same Chinese with only other numbers or brackets
      ("Stage 6 1 3 )" style jitter) has to be read the same way three times before the label changes;
    - a label is no longer switched to a new reading that has no translation yet (it used to vanish while the
      translation was fetched); the old label stays until the new one is ready;
    - a box that is read a little wider or narrower keeps its layout instead of being laid out again.

WHAT'S NEW IN 1.6
  * Window capture really works now. Your log showed it switching on and failing at once ("Cannot find an overload for
    CreateCopyFromSurfaceAsync"), so the overlay was still being hidden for every scan - that is the whole-overlay blink in
    your clip. The picture is now copied in a way PowerShell can call. Look for "window capture: ON" WITHOUT error lines
    after it in starfire.log.
  * No more leftover copies of a label: in your clip a second "Duel" sat above the Duel button and a second
    "Beginner's Journey" sat over the card below it for a few seconds. A copy whose text is read somewhere else in the
    same scan is now removed at once.
  * Icons in front of text (the diamond / shield / "!" symbols on the main-menu cards) are kept apart from the text, so
    "0 daily mission" becomes "Daily Quests" and the icon is not covered.
  * "阶段6（1/3）" style counters keep their numbers: "Stage 6 (1/3)" instead of "Stage 6 1 3 )".
  * Dictionary: Stage, Season 1, Season 1: Rising Wind (the rotating card that showed three different translations).

WHAT'S NEW IN 1.7
  * Duel (and other game words that are hard to read on glittering or glowing buttons) is caught sooner. Text that is in
    the dictionary now stays "in the running" for 4 missed scans instead of 2, so the few times the OCR does read it add
    up quickly, and the label locks in.
  * An established label only moves after its new spot has been read 3 times in a row (was 2), so one odd reading no
    longer makes it shoot off for a moment.
  * Counters: "Stage 6 (1/3)". 1.6 only fixed one of the ways the text reaches the screen; the counter is now corrected at
    the very end, whatever produced the English (dictionary, saved or online translation), and also when the OCR lost
    the slash or a bracket.

WHAT'S NEW IN 1.8
  * No more stray "Duel" floating above the Duel button (and similar stray labels in empty spots): a reading is ignored
    when the area it came from has no sharp detail at all (no letter strokes), which is what the glow around the gold
    button produced. Such readings are logged as "reject [no-detail]".
  * Dictionary: common OCR misreadings of 切磋 / 对决 (so 切磋 never comes out as "Let's discuss"), plus Set Off and Enter.
  * Your 1.6 log confirms window capture now works ("window capture: ON" with no errors after it), so the overlay no
    longer blinks off for scans.

WHAT'S NEW IN 1.9
  * Fixes 1.8: the "no detail" check threw away real text (your log: 仓库 / Storage, 身外身, 异人, 阶段6 1 3,
    今日奖励领取 ...). Soft grey text over a photo has little sharp detail on average. The check now looks only at
    readings from the extra contrast passes, and only drops one when no part of its area has any sharp detail at all.

WHAT'S NEW IN 2.0
  * Counters such as 阶段6（1/3）: the label now covers only the word ("Stage") and the game's own numbers stay visible
    next to it, exactly as the game shows them. The OCR reads this line as "阶段6 1 3" (it loses the brackets and the
    slash), so re-typing the numbers could never be right. The same applies to any known word followed only by numbers,
    e.g. 等级 10 -> "Level" + the game's 10.

WHAT'S NEW IN 2.1
  * Season card: 赛季1·风起 is split like the Stage counter - "Season" over 赛季, "Rising Wind" over 风起, and the game's own
    "1·" stays visible between them. This works for any row made of dictionary words with numbers between or after them.
  * Remembered spots: once a word has settled on a button (read 4 times in a row), Lite remembers that spot for the rest
    of the session. When the word is read there again it gets its label at once (no waiting for a second reading), and
    a remembered label is only taken away when the picture there clearly changes or after ~16 scans without the text -
    the Duel button's flash can no longer make it vanish. A screen change still clears everything at once.

WHAT'S NEW IN 2.2
  * The installer now sets up Windows' Chinese text recognition (OCR) language pack before the program starts. If it is
    missing, it asks once, then installs it from Windows Update (about 30 MB; Windows asks for administrator permission and
    a window shows the progress). If it is already installed, nothing happens. The pack itself cannot be included in the
    download (Microsoft only hands it out through Windows Update), so the PC needs internet for this one step.
    Install-OcrPack.ps1 is also included to run by hand (right-click > Run with PowerShell) if you use the .cmd instead.

WHAT'S NEW IN 2.3
  * You can see which version runs:
    - "Starfire Lite.exe" shows a message after a first install ("installed to ...") and after every update
      ("updated from 2.2 to 2.3"); when nothing changed it starts silently as before;
    - hovering over the tray icon shows the version ("Starfire Lite 2.3 ON ...");
    - a notice "Starfire Lite 2.3 is running" appears when it starts, and starfire.log starts with
      "---- start ---- Starfire Lite 2.3".

WHAT'S NEW IN 2.4
  * A real setup window. "Starfire Lite.exe" now opens Starfire Lite Setup, which shows:
    - whether Starfire Lite is installed and which version ("Installed now: 2.3 -> will be updated to 2.4");
    - the install folder;
    - options: install the Chinese OCR pack (only if missing), desktop shortcut, Start menu entry, start when finished;
    - a progress bar and a log of every step, ending with "installed" / "updated from ... to ...".
    A running Starfire Lite is closed during the update and started again at the end.
  * Desktop / Start menu shortcuts start the installed copy directly (no setup window each time).

WHAT'S NEW IN 2.5
  * Fixes 2.4: "Starfire Lite.exe" did not show the setup window (it started PowerShell with a "keep hidden" flag, and
    Windows applied it to the setup window). The window now opens and comes to the front.
  * The OCR pack is installed straight from the setup window when its box is ticked (Windows asks for permission and a
    progress window opens).

WHAT'S NEW IN 2.6
  * Controller and keyboard button prompts are left alone: A, B, X, Y, LB, RB, LT, RT, LS, RS, Esc, Tab, F1-F12 and
    similar are taken out of the text before it is translated (no more "B Back" or "RB Switch"), even when the OCR glued
    them to the Chinese ("B返回"). Their spots are kept clear, so labels do not cover the button icons, and a prompt on its
    own never gets a label.

WHAT'S NEW IN 2.7
  * New launcher look: a red and purple supernova in a starry sky, with glass panels for status and options, and large
    buttons. When Starfire Lite is installed and up to date the main button is START (with REINSTALL beside it), so
    "Starfire Lite.exe" doubles as a launcher; otherwise it is INSTALL or UPDATE.
  * Chinese text recognition (OCR) is now required before anything else: if it is missing, a message explains it and
    installs it (Windows asks for permission, a progress window opens). Without it the launcher does not continue,
    because Starfire Lite cannot read the game without it.

WHAT'S NEW IN 2.8
  * Faster, lighter scanning:
    - with window capture the screen is still read ~8 times a second while things change, but settles to ~3 times a
      second once the screen has been still for a moment (it used to read ~8 times a second all the time);
    - the checks "is this a known game word?", "is this a remembered spot?" and the text clean-up are remembered
      instead of being worked out again for every label on every scan.

WHAT'S NEW IN 2.9
  * Fewer "ghost" labels: random phrases that popped up now and then where there is no text (over shadows, road
    markings, hair, clothes ...). Those are the OCR misreading a busy picture as a few Chinese characters mixed with junk.
    - readings with junk the game's own text never has (@ # * and other keyboard symbols, half a pair of brackets
      such as a lone 《, a ring read as a lone "0" or a stroke read as a small letter between Chinese characters)
      are dropped, or held back until read again when there is only a little of it;
    - text that is not one of the game's own strings must really be read twice before its label appears - re-used
      earlier readings of dim text no longer count as a second reading;
    - readings only the extra contrast passes found, or with a little junk in them, need three real readings and no
      longer appear at once after a scene change, at the subtitle position, or because they were translated before.
    The game's own words (the built-in dictionary) are shown as quickly as before.
  * The debug overlay is switched off: its tray menu item is gone and F7 no longer does anything.

WHAT'S NEW IN 2.9.1
  * Fix: an earlier 2.9 test copy (with the debug overlay still on F7) was kept instead of being replaced, because it had
    the same version number. The Starfire launcher now compares the files themselves and replaces any copy that differs.

WHAT'S NEW IN 2.9.2
  * Widely spaced titles such as 第 一 章 / 第 二 章 / 第 三 章 in the season menu are read when they are not highlighted.
    The OCR returns them one word per character; the lone 一 (a solid bar) was taken for an icon, the lone 第 in front for
    a leading icon, and what was left was dropped. Now a run of characters that together make one of the game's own
    strings is protected from those checks; a dash read in place of 一, and the round icon glued to the first character
    ("G第"), are corrected when that makes one of the game's own strings.

WHAT'S NEW IN 2.9.3
  * Duel / loading bars: the rank badge (百川2阶, 九曲3阶 ...) and the stage or player name beside it were read as one
    line and translated together ("In the afternoon, the course was visited by Baichuan 2 Terrace"). The rank is now cut
    out and each piece gets its own label: "Afternoon Court" | "Hundred Rivers II". A number left on its own stays visible.
  * Dictionary: all 15 duel ranks with their tiers (First Nook, First Dew, Three Courts, Three Streams, Six Gardens,
    Six Marshes, Nine Bends, Nine Paths, Hundred Rivers, Hundred Nations, Thousand Realms, Thousand Falls,
    Myriad Abysses, Myriad Worlds, Eminence; tiers I-III), plus Afternoon Court, Luotian Ceremony Grounds, Win Streak.

WHAT'S NEW IN 2.9.4
  * Only one overlay at a time: when Starfire Lite starts, it closes every other Starfire overlay that is running - other
    versions, test copies, the full Project Starfire, the old HanScreen - and their watchdogs (so they are not brought back).
