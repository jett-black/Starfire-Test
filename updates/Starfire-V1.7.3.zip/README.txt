STARFIRE 1.7.3
One window for The Hidden Ones: the Starfire Lite translation overlay, the game and UU Booster - one at a time or all at once.
Same red / purple supernova look as the Starfire Lite launcher.

START
  Unzip ALL files into one folder you keep (for example Documents\Starfire) and double-click "Starfire.exe" there.
  (Or right-click StarfireHub.ps1 > Run with PowerShell.) Keep the files together - Starfire.exe opens StarfireHub.ps1
  from its own folder.
  Windows' Chinese text recognition (OCR) is checked first. If it is missing, Starfire installs it (Windows asks for
  permission, a small progress window opens). Starfire does not continue without it, because the translator needs it.

IN THE WINDOW
  STARFIRE LITE      Starfire Lite 2.8 is included. INSTALL / UPDATE puts it in %LOCALAPPDATA%\StarfireLite\app (a running
                     copy is closed and started again); START LITE starts it (and installs it first if needed).
                     Tick "Desktop shortcut for Starfire Lite" before installing if you want one.
  THE HIDDEN ONES    BROWSE to the game or its launcher .exe (for example YiRenZhiXia.exe). LAUNCH GAME starts it.
  UU BOOSTER         BROWSE to UU Booster's .exe (a .lnk shortcut works too). OPEN UU starts it.
                     On first start Starfire looks for both in the list of installed programs and fills them in if found.
  LAUNCH ALL         Starts the ticked ones in this order: UU Booster, then waits (default 6 s, so you can start the
                     acceleration for the game in UU), then the game, then Starfire Lite.
  Paths and choices are remembered in %LOCALAPPDATA%\Starfire\starfire-hub.json.

NOTES
  * UU Booster usually asks for administrator permission when it starts - that is UU, not Starfire.
  * Starfire only starts programs; it does not change the game, UU Booster or any of their files.

WHAT'S NEW IN 1.1
  * The OCR check is stricter and repeated: Starfire needs the Simplified Chinese pack (zh-Hans / zh-CN) - a Traditional
    Chinese pack no longer counts. It is checked when Starfire opens AND again before every button (Install, Start Lite,
    Launch Game, Open UU, Launch All). If it is missing, Starfire offers to install it; without it, nothing is started.
  * The header shows the real OCR state (green "installed" / red "MISSING") instead of a fixed "ready".
  * After removing or adding the OCR pack, Windows sometimes needs one restart before the change counts - until then the
    pack still works. Starfire mentions this when an install does not take effect.

WHAT'S NEW IN 1.2
  * Live updates. When Starfire opens it checks github.com/jett-black/Starfire for a newer version. If a newer version
    is there, the top right shows "Update available: v1.2 -> v1.3" and an UPDATE button. UPDATE shows what is new,
    downloads it, keeps a backup of the current files (%LOCALAPPDATA%\Starfire\backup-<version>), replaces the files next
    to Starfire.exe and restarts Starfire. CHECK AGAIN checks once more. A broken or incomplete download changes nothing.
  * Starfire Lite is updated together with Starfire (it is part of the download; INSTALL / UPDATE or START LITE puts the
    new Lite in place).

WHAT'S NEW IN 1.3
  * DESKTOP SHORTCUT button (bottom row) creates a "Starfire" shortcut on the desktop that opens this Starfire.exe. It keeps
    working after live updates, because updates replace the files in the same folder. The button shows
    "SHORTCUT ON DESKTOP" once it exists; pressing it again simply recreates it.

WHAT'S NEW IN 1.4
  * The live updater now reads the update file in the repo (updates/latest.json) instead of GitHub Releases, so new
    versions can be published straight to the repo.

WHAT'S NEW IN 1.5
  * The game and UU Booster are found by themselves in their usual places:
      game        C:\yrzx\launcher\yrzx_launcher.exe  (also D:\ and E:\)
      UU Booster  C:\Program Files (x86)\Netease\UU\uu_launcher.exe  (also Program Files and D:\)
    These are checked whenever no path is set or the saved one no longer exists; then the installed-programs list is
    searched. BROWSE stays as the backup for any other place.

WHAT'S NEW IN 1.6
  * Update window in the supernova style: "Updating Starfire  v1.5 -> v1.6", a rounded crimson-to-purple progress bar
    with the percentage and the MB downloaded, then "Installing ..." and "Done - restarting". It cannot be closed halfway.
  * All pop-ups (OCR required, update question, errors) are themed windows instead of plain Windows message boxes.
  * New versions are seen at once: the version file is read through GitHub's API (no 5-minute delay); the plain file is
    the fallback.

WHAT'S NEW IN 1.6.1
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.2
  * Fixes 1.6 / 1.6.1: "update check failed". The version file read through GitHub's API was decoded wrongly. Fixed, and if
    that answer can ever not be read, Starfire now falls back to the plain file instead of giving up.

WHAT'S NEW IN 1.6.3
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.4
  * Starfire closes itself after a launch: LAUNCH ALL, LAUNCH GAME, OPEN UU and START LITE close the window about a second
    after what they started is running. If something could not be started, the window stays open and shows why.

WHAT'S NEW IN 1.6.5
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.6
  * Includes Starfire Lite 2.8 (faster, lighter scanning). Press INSTALL / UPDATE or START LITE once to put it in place.

WHAT'S NEW IN 1.6.7
  * Fewer antivirus false alarms. Starfire.exe was rebuilt so it no longer looks like a "dropper" to virus scanners:
    - it no longer asks for administrator rights when it starts (only the OCR install asks, when needed);
    - it no longer carries hidden copies of the scripts and no longer unpacks them into a temporary folder - it simply
      opens StarfireHub.ps1 from its own folder (all files are in the zip, readable);
    - it carries normal program information (name, description, version, publisher) and is no longer stripped.
    Nothing else changed: same window, same buttons, same updater.
  * Includes Starfire Lite 2.8.

WHAT'S NEW IN 1.6.8
  * The launcher calls the translation overlay just "Starfire" (START STARFIRE, "Starfire is running", ...); the version
    numbers stay the same.
  * The VPN no longer appears by product name anywhere in the launcher ("VPN / ACCELERATOR", OPEN VPN); it is still found
    by itself in its usual place.
  * New "VPN section" checkbox (top right). Unticked, the whole VPN panel and the VPN parts of LAUNCH ALL disappear and the
    window gets shorter; ticked, they come back. It switches instantly and is remembered until you change it by hand.
    Until you have chosen, the section is shown only when a VPN was found or picked, and hidden otherwise.

WHAT'S NEW IN 1.6.9
  * Fixed cut-off text: the "The Hidden Ones companion" line and the "VPN section" checkbox are no longer clipped at the
    top (the big title and the OCR status line were overlapping them).

WHAT'S NEW IN 1.7.0
  * New "Game section" checkbox next to "VPN section". Unticked, the game panel and the Game box of LAUNCH ALL disappear
    and the panels below move up. Remembered until changed by hand (on by default).
  * With both Game and VPN sections off, the LAUNCH ALL panel disappears and the big button becomes LAUNCH STARFIRE,
    which starts just the Starfire overlay.
  * Switching is instant: each layout's background is drawn once (in the background right after the window opens).
  * The OCR status in the header is shorter ("OCR: installed") to make room for the two switches.

WHAT'S NEW IN 1.7.1
  * New mini loader: "Starfire Overlay.exe", next to Starfire.exe. It is for when you only want the translator:
      - it checks for a Starfire update first (a small window, a few seconds at most);
      - no update (or no internet): it starts the overlay right away - the launcher never opens;
      - an update is waiting: the launcher opens, installs it by itself without asking, then starts the overlay.
  * New MINI LOADER button in the Starfire panel: puts a "Starfire Overlay" icon on the desktop that runs the mini loader.
    (It replaces the old "Desktop shortcut for the Starfire overlay" checkbox; an existing "Starfire Overlay" desktop
    icon is switched over to the mini loader the next time the overlay is installed.)

WHAT'S NEW IN 1.7.2
  * The Windows frame is gone: every Starfire window (launcher, messages, update window, mini loader) is now borderless,
    with rounded corners (Windows 11) and a soft shadow.
  * Animated border: a glowing edge in the Starfire colours flows all the way around each window - two light currents
    chase each other while the colours slowly drift, so it never looks the same twice.
  * Move a window by dragging its header; its own minimize / close buttons are in the top-right corner.

WHAT'S NEW IN 1.7.3  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the Starfire overlay 2.9: far fewer "ghost" labels (random phrases over shadows / road markings / hair
    where there is no text). See README-StarfireLite.txt for details.
