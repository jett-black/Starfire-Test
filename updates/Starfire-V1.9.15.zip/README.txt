STARFIRE 1.9.5
One window for The Hidden Ones: the Starfire Lite translation overlay, the game and UU Booster - one at a time or all at once.
Same red / purple supernova look as the Starfire Lite launcher.

START
  Unzip ALL files into one folder you keep (for example Documents\Starfire) and double-click "Starfire.exe" there.
  (Or right-click StarfireHub.ps1 > Run with PowerShell.) Keep the files together - Starfire.exe opens StarfireHub.ps1
  from its own folder.
  Windows' Chinese text recognition (OCR) is checked first. If it is missing, Starfire installs it (Windows asks for
  permission, a small progress window opens). Starfire does not continue without it, because the translator needs it.

IN THE WINDOW
  STARFIRE LITE      Starfire Lite 2.8 is included. INSTALL / UPDATE puts it in %LOCALAPPDATA%\StarfireLite\app (a running
                     copy is closed and started again); START LITE starts it (and installs it first if needed).
                     Tick "Desktop shortcut for Starfire Lite" before installing if you want one.
  THE HIDDEN ONES    BROWSE to the game or its launcher .exe (for example YiRenZhiXia.exe). LAUNCH GAME starts it.
  UU BOOSTER         BROWSE to UU Booster's .exe (a .lnk shortcut works too). OPEN UU starts it.
                     On first start Starfire looks for both in the list of installed programs and fills them in if found.
  LAUNCH ALL         Starts the ticked ones in this order: UU Booster, then waits (default 6 s, so you can start the
                     acceleration for the game in UU), then the game, then Starfire Lite.
  Paths and choices are remembered in %LOCALAPPDATA%\Starfire\starfire-hub.json.

NOTES
  * UU Booster usually asks for administrator permission when it starts - that is UU, not Starfire.
  * Starfire only starts programs; it does not change the game, UU Booster or any of their files.

WHAT'S NEW IN 1.1
  * The OCR check is stricter and repeated: Starfire needs the Simplified Chinese pack (zh-Hans / zh-CN) - a Traditional
    Chinese pack no longer counts. It is checked when Starfire opens AND again before every button (Install, Start Lite,
    Launch Game, Open UU, Launch All). If it is missing, Starfire offers to install it; without it, nothing is started.
  * The header shows the real OCR state (green "installed" / red "MISSING") instead of a fixed "ready".
  * After removing or adding the OCR pack, Windows sometimes needs one restart before the change counts - until then the
    pack still works. Starfire mentions this when an install does not take effect.

WHAT'S NEW IN 1.2
  * Live updates. When Starfire opens it checks github.com/jett-black/Starfire for a newer version. If a newer version
    is there, the top right shows "Update available: v1.2 -> v1.3" and an UPDATE button. UPDATE shows what is new,
    downloads it, keeps a backup of the current files (%LOCALAPPDATA%\Starfire\backup-<version>), replaces the files next
    to Starfire.exe and restarts Starfire. CHECK AGAIN checks once more. A broken or incomplete download changes nothing.
  * Starfire Lite is updated together with Starfire (it is part of the download; INSTALL / UPDATE or START LITE puts the
    new Lite in place).

WHAT'S NEW IN 1.3
  * DESKTOP SHORTCUT button (bottom row) creates a "Starfire" shortcut on the desktop that opens this Starfire.exe. It keeps
    working after live updates, because updates replace the files in the same folder. The button shows
    "SHORTCUT ON DESKTOP" once it exists; pressing it again simply recreates it.

WHAT'S NEW IN 1.4
  * The live updater now reads the update file in the repo (updates/latest.json) instead of GitHub Releases, so new
    versions can be published straight to the repo.

WHAT'S NEW IN 1.5
  * The game and UU Booster are found by themselves in their usual places:
      game        C:\yrzx\launcher\yrzx_launcher.exe  (also D:\ and E:\)
      UU Booster  C:\Program Files (x86)\Netease\UU\uu_launcher.exe  (also Program Files and D:\)
    These are checked whenever no path is set or the saved one no longer exists; then the installed-programs list is
    searched. BROWSE stays as the backup for any other place.

WHAT'S NEW IN 1.6
  * Update window in the supernova style: "Updating Starfire  v1.5 -> v1.6", a rounded crimson-to-purple progress bar
    with the percentage and the MB downloaded, then "Installing ..." and "Done - restarting". It cannot be closed halfway.
  * All pop-ups (OCR required, update question, errors) are themed windows instead of plain Windows message boxes.
  * New versions are seen at once: the version file is read through GitHub's API (no 5-minute delay); the plain file is
    the fallback.

WHAT'S NEW IN 1.6.1
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.2
  * Fixes 1.6 / 1.6.1: "update check failed". The version file read through GitHub's API was decoded wrongly. Fixed, and if
    that answer can ever not be read, Starfire now falls back to the plain file instead of giving up.

WHAT'S NEW IN 1.6.3
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.4
  * Starfire closes itself after a launch: LAUNCH ALL, LAUNCH GAME, OPEN UU and START LITE close the window about a second
    after what they started is running. If something could not be started, the window stays open and shows why.

WHAT'S NEW IN 1.6.5
  * Test update: no changes, only the version number (to try the in-app updater).

WHAT'S NEW IN 1.6.6
  * Includes Starfire Lite 2.8 (faster, lighter scanning). Press INSTALL / UPDATE or START LITE once to put it in place.

WHAT'S NEW IN 1.6.7
  * Fewer antivirus false alarms. Starfire.exe was rebuilt so it no longer looks like a "dropper" to virus scanners:
    - it no longer asks for administrator rights when it starts (only the OCR install asks, when needed);
    - it no longer carries hidden copies of the scripts and no longer unpacks them into a temporary folder - it simply
      opens StarfireHub.ps1 from its own folder (all files are in the zip, readable);
    - it carries normal program information (name, description, version, publisher) and is no longer stripped.
    Nothing else changed: same window, same buttons, same updater.
  * Includes Starfire Lite 2.8.

WHAT'S NEW IN 1.6.8
  * The launcher calls the translation overlay just "Starfire" (START STARFIRE, "Starfire is running", ...); the version
    numbers stay the same.
  * The VPN no longer appears by product name anywhere in the launcher ("VPN / ACCELERATOR", OPEN VPN); it is still found
    by itself in its usual place.
  * New "VPN section" checkbox (top right). Unticked, the whole VPN panel and the VPN parts of LAUNCH ALL disappear and the
    window gets shorter; ticked, they come back. It switches instantly and is remembered until you change it by hand.
    Until you have chosen, the section is shown only when a VPN was found or picked, and hidden otherwise.

WHAT'S NEW IN 1.6.9
  * Fixed cut-off text: the "The Hidden Ones companion" line and the "VPN section" checkbox are no longer clipped at the
    top (the big title and the OCR status line were overlapping them).

WHAT'S NEW IN 1.7.0
  * New "Game section" checkbox next to "VPN section". Unticked, the game panel and the Game box of LAUNCH ALL disappear
    and the panels below move up. Remembered until changed by hand (on by default).
  * With both Game and VPN sections off, the LAUNCH ALL panel disappears and the big button becomes LAUNCH STARFIRE,
    which starts just the Starfire overlay.
  * Switching is instant: each layout's background is drawn once (in the background right after the window opens).
  * The OCR status in the header is shorter ("OCR: installed") to make room for the two switches.

WHAT'S NEW IN 1.7.1
  * New mini loader: "Starfire Overlay.exe", next to Starfire.exe. It is for when you only want the translator:
      - it checks for a Starfire update first (a small window, a few seconds at most);
      - no update (or no internet): it starts the overlay right away - the launcher never opens;
      - an update is waiting: the launcher opens, installs it by itself without asking, then starts the overlay.
  * New MINI LOADER button in the Starfire panel: puts a "Starfire Overlay" icon on the desktop that runs the mini loader.
    (It replaces the old "Desktop shortcut for the Starfire overlay" checkbox; an existing "Starfire Overlay" desktop
    icon is switched over to the mini loader the next time the overlay is installed.)

WHAT'S NEW IN 1.7.2
  * The Windows frame is gone: every Starfire window (launcher, messages, update window, mini loader) is now borderless,
    with rounded corners (Windows 11) and a soft shadow.
  * Animated border: a glowing edge in the Starfire colours flows all the way around each window - two light currents
    chase each other while the colours slowly drift, so it never looks the same twice.
  * Move a window by dragging its header; its own minimize / close buttons are in the top-right corner.

WHAT'S NEW IN 1.7.3
  * Includes the Starfire overlay 2.9: far fewer "ghost" labels (random phrases over shadows / road markings / hair
    where there is no text), and the debug overlay (F7) is switched off. See README-StarfireLite.txt for details.

WHAT'S NEW IN 1.7.4
  * Fix: an older copy of the overlay with the same version number (for example a 2.9 test copy that still had the
    F7 debug overlay) was kept instead of being replaced. Starfire now compares the overlay files themselves and replaces
    any copy that differs (the launcher's START button and the mini loader both do this). Includes the overlay 2.9.1.

WHAT'S NEW IN 1.7.5
  * Includes the overlay 2.9.2: the season menu's 第一章 / 第二章 / 第三章 (Chapter 1 / 2 / 3) are read when not highlighted.

WHAT'S NEW IN 1.7.6
  * Automatic updates: when Starfire finds a new version it installs it right away (progress window, backup of the old
    files, restart) instead of waiting for the UPDATE button. If it fails, nothing is changed and UPDATE tries again.
  * The Starfire overlay updates itself too: when the installed overlay differs from the included one it is replaced as
    soon as the window opens, and restarted if it was running - no need to press INSTALL / UPDATE or START.
  * The mini loader (Starfire Overlay.exe) already worked this way and still does.

WHAT'S NEW IN 1.7.7
  * Includes the overlay 2.9.3: on the duel / loading bars the rank badge and the stage name get separate labels
    (e.g. "Afternoon Court" and "Hundred Rivers II"), and all duel ranks are in the dictionary.

WHAT'S NEW IN 1.7.8
  * No more overlapping overlays: starting Starfire (START STARFIRE, LAUNCH ALL / LAUNCH STARFIRE, the mini loader)
    always starts this copy, and it closes every other Starfire overlay first - other versions, test copies, Project
    Starfire, HanScreen - along with their watchdogs. (Before, a copy that was already running was simply left alone.)

WHAT'S NEW IN 1.7.9  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.5: the tray menu can switch the overlay between the game and the desktop (whole screen or
    an area you choose, for any app), with tick marks showing the current settings; old / unused menu items removed.

WHAT'S NEW IN 1.8.0  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Updates always replace the Starfire.exe / Starfire Overlay.exe you start Starfire with, so after the restart it does
    not offer the same update again:
      - the .exe files are replaced last, after the scripts; one that is still in use or briefly held by antivirus is
        moved aside (Starfire.exe.old, tidied up later) and the new one put in its place, with several retries;
      - the replaced .exe is checked against the downloaded one; if it could not be replaced, the update says so;
      - Starfire's version now comes from its own script, not from the .exe, so even an .exe that could not be replaced
        can never make it think it is still the old version.

WHAT'S NEW IN 1.8.1  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Test builds are now a separate variant that never overwrites the normal Starfire:
      - their programs are "Starfire Test.exe" and "Starfire Overlay Test.exe";
      - own settings, backups (%LOCALAPPDATA%\Starfire-Test), installed overlay (%LOCALAPPDATA%\StarfireLite-Test),
        and desktop icons "Starfire (Test)" / "Starfire Overlay (Test)";
      - the window says TEST; updates come from Starfire-Test.
    Unzip a test build into its own folder (not over the normal Starfire). Only one overlay runs at a time.

WHAT'S NEW IN 1.8.2  (test build - updates come from github.com/jett-black/Starfire-Test)
  * The mini loader updates itself: when it finds a new version it downloads and installs it right in its small window
    (progress bar) - launcher, mini loader, scripts and overlay - then starts again as the new version and starts the
    overlay. The full launcher only opens if that fails.
  * The overlay updates itself too (overlay 2.9.7): while it runs it checks for a new Starfire now and then and, when
    there is one, starts the mini loader to install it and restart the overlay.

WHAT'S NEW IN 1.8.3
  * Sturdier updates:
      - UPDATE (and the automatic update) first reads the latest update notice again and installs exactly what it says
        at that moment - never a notice that was read earlier and may have changed since;
      - every request carries a fresh tag, so GitHub's caches can never hand over an older notice or file;
      - if the downloaded file does not match the notice, Starfire reads the notice again and downloads once more by
        itself before giving up;
      - no 60-second limit on the download any more (slow connections are fine).

WHAT'S NEW IN 1.8.4  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.8: rows of buttons with icons between them (阵容方案, 战斗录像, 切磋排行, 玩法奖励 ...) are
    translated again, one label per button.

WHAT'S NEW IN 1.8.5  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.10: a light-text pass for white text on see-through buttons over busy / moving pictures,
    "第1赛季" -> "Season 1" as one label, no Chinese characters left inside English labels, protection-card terms.

WHAT'S NEW IN 1.8.6  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.11: labels of the game's own text stick over moving backgrounds until the screen changes.

WHAT'S NEW IN 1.8.7  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.12: check boxes no longer read as "7", steadier adventure / event rows, Mode Rewards read
    properly even when part of it is hidden.

WHAT'S NEW IN 1.8.8  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.13: the login screen's legal notice is shown as one clean, fully translated panel.

WHAT'S NEW IN 1.8.9  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.14: no more labels lingering in the old place after a menu slides; menu words over soft
    backgrounds are no longer dropped.

WHAT'S NEW IN 1.9.0  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.15: no more ghost / doubled labels (overlapping readings of the same text, old copies left
    behind after a menu moved), on top of the 1.8.9 fixes for labels lingering after a menu slides.

WHAT'S NEW IN 1.9.1  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.16: character names, currencies, ranks and numbered season / challenge / event words get
    labels of their own, with the numbers beside them left visible.

WHAT'S NEW IN 1.9.2  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.18: bracketed text stays together, 天下会武 is "Martial Tournament", no gold glow peeking
    out under labels.

WHAT'S NEW IN 1.9.3  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.19: win-streak badges ("3连胜") read reliably as "3 Win Streak".

WHAT'S NEW IN 1.9.4  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Every launcher update brings the overlay up to date too: right after the launcher restarts as the new version it
    installs the new overlay and - if an overlay was running (also one running with admin rights, which the launcher
    cannot see directly; it now checks the overlay's heartbeat) - restarts it as the new version.

WHAT'S NEW IN 1.9.5  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.20: fixes the overlay stopping after a while ("GetHicon ... generic error in GDI+").

WHAT'S NEW IN 1.9.6  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.21:
    - The End key now closes the overlay (Ctrl+Shift+Q still works too). F8 still turns it on / off.
    - Ranked screen: a row of rank pips next to a rank name is no longer read as a tier ("Hundred Rivers I"), so the
      badge stays with its text; labels follow moving text faster, so fewer labels hang in the wrong place.
    - "第1 赛季" (Season 1) is read as one phrase.
    - The label's glass now grows to cover gold glow / calligraphy right next to a label (Martial Tournament title).

WHAT'S NEW IN 1.9.7  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.22: labels are no longer laid over icons, check boxes and button edges that sit right next
    to a text (the label's glass stops at them and no longer grows into them).

WHAT'S NEW IN 1.9.8  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.23: speed and steadiness. 2.9.21 / 2.9.22 had a bug that raised an error on every scan on
    screens with "第N" titles (slowing the scan down), and they re-shaped labels every scan, which made text shift and
    load unevenly. Both fixed: the "Season 1" merge is rewritten, and the glow cover is worked out once per label layout.

WHAT'S NEW IN 1.9.9  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.24: the log now says why an established label was dropped or moved
    ("track drop [missed cdm=..]: text", "track move [dx=.. dy=..]: text"), to track down labels that do not stay locked.

WHAT'S NEW IN 1.9.10  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.25: an established label whose picture has not changed at all now stays locked (up to ~40
    missed scans instead of 7) - the log showed real menu text being dropped after the OCR missed it a few times.

WHAT'S NEW IN 1.9.11  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.26:
    - Icons, check boxes and badges beside a text (the gate next to "Room", the "!" box, the card icon) are found in the
      picture itself, and the label's glass and room end before them - also when the OCR never read them.
    - Rank names: a lone digit after the rank (a pip read as "1") is no longer taken as the tier, so "Hundred Rivers I"
      is just "Hundred Rivers". The tier needs the 阶 mark.
    - "第1赛季" now reads "Season 1" (1 - 30).
    - Glass growth around a label is a little wider again (the 2.9.22 limit left a stroke of the original text showing).

WHAT'S NEW IN 1.9.12  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.27: labels follow a menu that glides or sways (the lineup / battle replay / sparring
    buttons moved 12-24 px back and forth). A label now follows as soon as a clear reading is a few pixels away and the
    old spot's text is gone, instead of waiting for the same new spot twice (which never happened while the menu kept
    moving, so the label trailed behind and jumped later). While things move the screen is also checked every 140 ms
    instead of every 300 ms. The "track move" log lines show the box size change and the reading pass as well.

WHAT'S NEW IN 1.9.13  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.28:
    - 玩法奖励 is always "Mode Rewards" - also for slightly misread variants that used to come back from an online
      translator as "Game Mode Rewards".
    - An icon that the OCR box swallowed (the gate in front of "Room") is cut out of the label's area when the box is
      clearly wider than its text needs, so the label no longer sits over the icon.
    - The log also shows the first sighting and the drop of the game's own words that are read only now and then
      ("track new" / "track drop"), to track down words such as 百川 and 3连胜 that do not stay translated.

WHAT'S NEW IN 1.9.14  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.29: labels that sat beside their text instead of on it (found in your recording:
    "Cancel" 75 px above its button, "Doppelganger" / "Battle Outfit" about 30 px above their words, "Martial Tournament"
    flipping to 100 px below its title and back) are fixed. A remembered label position is no longer reused when it would
    not cover its text, and every label is checked after layout: if it is not on its text it is laid out again, and if
    that still misses it is put on the text. The perf log line shows how often this happened ("snapped=").

WHAT'S NEW IN 1.9.15  (test build - updates come from github.com/jett-black/Starfire-Test)
  * Includes the overlay 2.9.30 (found with your second recording of the ranked Martial Tournament menu):
    - The top row of buttons (Lineup Presets / Battle Replays / Sparring Leaderboard / Mode Rewards): their labels were
      sliding 12-30 px off the words because the extra reading pass reports boxes that far off. Those boxes are now put
      on the light text that is really on screen, so the labels sit on the words.
    - That also ends the two labels at "Mode Rewards" ("Mode Rewards" above, "Play for rewards" on the button): the
      misread copy and the real one now land on the same spot and the better one stays.
    - A check box read as a symbol in front of a text ("跨平台匹配") is cut out of the label's area, so the label no
      longer sits on top of the check box.
    The perf log line shows "shifted=" (boxes put on the text).
