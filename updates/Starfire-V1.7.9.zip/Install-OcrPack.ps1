﻿# Starfire - installs the Windows Chinese (Simplified) text-recognition (OCR) language pack if it is missing.
# Run by the installers before the program starts. The pack itself comes from Windows Update (about 30 MB).
param([switch]$Elevated, [string]$App = 'Starfire')
$ErrorActionPreference = 'Stop'
$cap = 'Language.OCR~~~zh-CN~0.0.1.0'

function Test-ChineseOcr {
    try {
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        foreach ($l in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) { $lt = [string]$l.LanguageTag; if ($lt -eq 'zh-Hans' -or $lt -like 'zh-Hans-*' -or $lt -eq 'zh-CN') { return $true } }
    } catch {}
    return $false
}

if (-not $Elevated) {
    if (Test-ChineseOcr) { exit 0 }                      # already there: nothing to do
    Add-Type -AssemblyName System.Windows.Forms
    $q = "$App reads the game's Chinese text with Windows' built-in text recognition, which needs the Chinese (Simplified) " +
         "OCR language pack. It is not installed on this PC yet.`n`nInstall it now from Windows Update (about 30 MB)? " +
         "Windows will ask for administrator permission."
    $r = [System.Windows.Forms.MessageBox]::Show($q, "$App - Chinese text recognition", 'YesNo', 'Question')
    if ([string]$r -ne 'Yes') { exit 1 }
    try {
        $p = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-Elevated', '-App', "`"$App`"")
        if (Test-ChineseOcr) { exit 0 }
        exit [int]$p.ExitCode
    } catch {
        [System.Windows.Forms.MessageBox]::Show("The language pack was not installed: $($_.Exception.Message)`n`nYou can add it later in Settings > Time & language > Language > Chinese (Simplified) > Optical character recognition.", $App, 'OK', 'Warning') | Out-Null
        exit 1
    }
}

# elevated part: visible window with progress
try { $Host.UI.RawUI.WindowTitle = "$App - installing Chinese text recognition" } catch {}
Write-Host ''
Write-Host "  ${App}: installing the Windows Chinese (Simplified) OCR language pack" -ForegroundColor Cyan
Write-Host '  This downloads about 30 MB from Windows Update and can take a minute or two. Please wait...'
Write-Host ''
try {
    $c = Get-WindowsCapability -Online -Name $cap
    if ($c.State -eq 'Installed') { Write-Host '  Already installed.' -ForegroundColor Green }
    else {
        Add-WindowsCapability -Online -Name $cap | Out-Null
        Write-Host '  Installed.' -ForegroundColor Green
    }
    Start-Sleep -Seconds 2
    exit 0
} catch {
    Write-Host ''
    Write-Host "  Could not install it: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host '  You can add it by hand: Settings > Time & language > Language > Chinese (Simplified) > Language options >'
    Write-Host '  Optical character recognition. (On PCs managed by a school / company, Windows Update may block it.)'
    Write-Host ''
    Read-Host '  Press Enter to close'
    exit 2
}
